```python
import numpy as np
import pickle
import matplotlib.pyplot as plt
import csv
import pandas as pd
```


```python
pick = []
team = []
names = []
year = []
vorp = []
winshares = []
bpm = []

with open('draft2012.csv') as file:
    csv_reader = csv.reader(file)
    num = 0
    for line in csv_reader:
        if num >= 1:
            pick.append(line[1])
            team.append(line[2])
            names.append(line[3])
            vorp.append(line[21])
            winshares.append(line[18])
            bpm.append(line[20])
            year.append(2012)
        num += 1

with open('draft2013.csv') as file:
    csv_reader = csv.reader(file)
    num = 0
    for line in csv_reader:
        if num >= 1:
            pick.append(line[1])
            team.append(line[2])
            names.append(line[3])
            vorp.append(line[21])
            winshares.append(line[18])
            bpm.append(line[20])
            year.append(2013)
        num += 1

with open('draft2014.csv') as file:
    csv_reader = csv.reader(file)
    num = 0
    for line in csv_reader:
        if num >= 1:
            pick.append(line[1])
            team.append(line[2])
            names.append(line[3])
            vorp.append(line[21])
            winshares.append(line[18])
            bpm.append(line[20])
            year.append(2014)
        num += 1

with open('draft2015.csv') as file:
    csv_reader = csv.reader(file)
    num = 0
    for line in csv_reader:
        if num >= 1:
            pick.append(line[1])
            team.append(line[2])
            names.append(line[3])
            vorp.append(line[21])
            winshares.append(line[18])
            bpm.append(line[20])
            year.append(2015)
        num += 1

with open('draft2016.csv') as file:
    csv_reader = csv.reader(file)
    num = 0
    for line in csv_reader:
        if num >= 1:
            pick.append(line[1])
            team.append(line[2])
            names.append(line[3])
            vorp.append(line[21])
            winshares.append(line[18])
            bpm.append(line[20])
            year.append(2016)
        num += 1

with open('draft2017.csv') as file:
    csv_reader = csv.reader(file)
    num = 0
    for line in csv_reader:
        if num >= 1:
            pick.append(line[1])
            team.append(line[2])
            names.append(line[3])
            vorp.append(line[21])
            winshares.append(line[18])
            bpm.append(line[20])
            year.append(2017)
        num += 1

with open('draft2018.csv') as file:
    csv_reader = csv.reader(file)
    num = 0
    for line in csv_reader:
        if num >= 1:
            pick.append(line[1])
            team.append(line[2])
            names.append(line[3])
            vorp.append(line[21])
            winshares.append(line[18])
            bpm.append(line[20])
            year.append(2018)
        num += 1

with open('draft2019.csv') as file:
    csv_reader = csv.reader(file)
    num = 0
    for line in csv_reader:
        if num >= 1:
            pick.append(line[1])
            team.append(line[2])
            names.append(line[3])
            vorp.append(line[21])
            winshares.append(line[18])
            bpm.append(line[20])
            year.append(2019)
        num += 1                
        
with open('draft2020.csv') as file:
    csv_reader = csv.reader(file)
    num = 0
    for line in csv_reader:
        if num >= 1:
            pick.append(line[1])
            team.append(line[2])
            names.append(line[3])
            vorp.append(line[21])
            winshares.append(line[18])
            bpm.append(line[20])
            year.append(2020)
        num += 1

with open('draft2021.csv') as file:
    csv_reader = csv.reader(file)
    num = 0
    for line in csv_reader:
        if num >= 1:
            pick.append(line[1])
            team.append(line[2])
            names.append(line[3])
            vorp.append(line[21])
            winshares.append(line[18])
            bpm.append(line[20])
            year.append(2021)
        num += 1  
        
```


```python
num = 0
for x in vorp:
    if (x == ''):
        del vorp[num]
        del names[num]
        del team[num]
        del pick[num]
        del year[num]
        del winshares[num]
        del bpm[num]
    num += 1

num = 0
for x in vorp:
    if (x == ''):
        del vorp[num]
        del names[num]
        del team[num]
        del pick[num]
        del year[num]
        del winshares[num]
        del bpm[num]
    num += 1
  
num = 0
for x in vorp:
    if (x == ''):
        del vorp[num]
        del names[num]
        del team[num]
        del pick[num]
        del year[num]
        del winshares[num]
        del bpm[num]
    num += 1

num = 0
for x in vorp:
    if (x == ''):
        del vorp[num]
        del names[num]
        del team[num]
        del pick[num]
        del year[num]
        del winshares[num]
        del bpm[num]
    num += 1
  
```


```python
num = 0
for i in pick:
    pick[num] = int(i)
    num += 1

num = 0
for i in vorp:
    vorp[num] = float(i)
    num += 1
    
num = 0
for i in winshares:
    winshares[num] = float(i)
    num += 1
    
num = 0
for i in bpm:
    bpm[num] = float(i)
    num += 1

    
```


```python
num = 0
for i in names:
    print(pick[num], year[num], team[num], i, vorp[num], winshares[num], bpm[num])
    num += 1
```

    1 2012 NOH Anthony Davis 44.3 96.3 6.1
    2 2012 CHA Michael Kidd-Gilchrist 0.6 21.0 -1.8
    3 2012 WAS Bradley Beal 21.7 50.4 1.8
    4 2012 CLE Dion Waiters -0.4 8.8 -2.1
    5 2012 SAC Thomas Robinson -1.6 4.6 -3.5
    6 2012 POR Damian Lillard 44.9 96.4 4.7
    7 2012 GSW Harrison Barnes 7.4 47.0 -0.8
    8 2012 TOR Terrence Ross 4.3 23.5 -1.0
    9 2012 DET Andre Drummond 17.8 68.6 1.3
    10 2012 NOH Austin Rivers -4.5 13.9 -3.1
    11 2012 POR Meyers Leonard 1.1 15.5 -1.4
    12 2012 HOU Jeremy Lamb 7.9 26.8 0.6
    13 2012 PHO Kendall Marshall -1.1 1.0 -3.5
    14 2012 MIL John Henson 3.4 20.7 -0.5
    15 2012 PHI Maurice Harkless 4.1 23.0 -0.8
    16 2012 HOU Royce White 0.0 0.0 -16.9
    17 2012 DAL Tyler Zeller 0.0 17.1 -2.0
    18 2012 HOU Terrence Jones 3.6 14.7 0.5
    19 2012 ORL Andrew Nicholson -1.6 3.8 -3.6
    20 2012 DEN Evan Fournier 4.8 30.5 -1.0
    21 2012 BOS Jared Sullinger 2.7 15.3 -0.4
    22 2012 BOS Fab Melo -0.1 0.0 -7.6
    23 2012 ATL John Jenkins 0.1 3.0 -1.9
    24 2012 CLE Jared Cunningham -0.6 0.2 -5.7
    25 2012 MEM Tony Wroten -1.1 -1.3 -3.4
    26 2012 IND Miles Plumlee 0.2 10.6 -1.9
    27 2012 MIA Arnett Moultrie -0.1 1.7 -2.8
    28 2012 OKC Perry Jones -0.6 1.7 -3.5
    29 2012 CHI Marquis Teague -1.0 -0.9 -6.5
    30 2012 GSW Festus Ezeli 0.0 5.9 -2.0
    31 2012 CHA Jeff Taylor -1.5 1.3 -4.2
    32 2012 WAS Tomas Satoransky 2.4 17.9 -0.9
    33 2012 CLE Bernard James 0.0 1.9 -1.8
    34 2012 CLE Jae Crowder 10.9 40.2 0.3
    35 2012 GSW Draymond Green 23.6 54.3 2.6
    36 2012 SAC Orlando Johnson -0.1 1.4 -2.4
    37 2012 TOR Quincy Acy -0.1 8.7 -2.0
    38 2012 DEN Quincy Miller -0.5 -0.1 -3.9
    39 2012 DET Khris Middleton 14.3 50.9 0.7
    40 2012 POR Will Barton 6.9 26.2 -0.4
    41 2012 POR Tyshawn Taylor -0.8 -0.9 -8.1
    42 2012 MIL Doron Lamb -1.2 0.1 -5.8
    43 2012 ATL Mike Scott 0.6 16.8 -1.7
    44 2012 DET Kim English -0.2 0.2 -4.2
    45 2012 PHI Justin Hamilton 0.5 3.7 -0.9
    46 2012 NOH Darius Miller -0.4 6.5 -2.3
    47 2012 UTA Kevin Murphy -0.2 -0.3 -16.8
    48 2012 NYK Kostas Papanikolaou -0.2 0.3 -2.7
    49 2012 ORL Kyle O'Quinn 5.0 17.8 0.9
    51 2012 BOS Kris Joseph -0.1 -0.1 -9.9
    52 2012 GSW Ognjen Kuzmic -0.2 0.2 -5.6
    53 2012 LAC Furkan Aldemir -0.2 1.4 -3.6
    54 2012 PHI Tornike Shengelia -0.3 -0.2 -7.0
    55 2012 DAL Darius Johnson-Odom -0.1 -0.3 -25.5
    58 2012 MIN Robbie Hummel -0.4 1.9 -3.1
    60 2012 LAL Robert Sacre -1.4 2.4 -4.0
    1 2013 CLE Anthony Bennett -1.3 0.5 -4.8
    2 2013 ORL Victor Oladipo 11.0 25.2 0.9
    3 2013 WAS Otto Porter Jr. 12.6 36.5 1.8
    4 2013 CHA Cody Zeller 4.0 32.1 -0.6
    5 2013 PHO Alex Len 0.2 21.7 -1.9
    6 2013 NOH Nerlens Noel 7.5 28.3 0.9
    7 2013 SAC Ben McLemore -3.4 9.0 -3.1
    8 2013 DET Kentavious Caldwell-Pope 6.1 35.9 -0.8
    9 2013 MIN Trey Burke 1.7 12.9 -1.3
    10 2013 POR CJ McCollum 15.9 41.2 1.2
    11 2013 PHI Michael Carter-Williams 1.9 6.6 -1.2
    12 2013 OKC Steven Adams 11.6 57.5 0.5
    13 2013 DAL Kelly Olynyk 10.6 37.8 1.0
    14 2013 UTA Shabazz Muhammad 0.0 8.5 -2.0
    15 2013 MIL Giannis Antetokounmpo 45.1 90.7 6.1
    16 2013 BOS Lucas Nogueira 1.9 6.0 2.3
    17 2013 ATL Dennis Schroder 3.1 23.7 -1.3
    18 2013 ATL Shane Larkin -0.6 4.4 -2.4
    19 2013 CLE Sergey Karasev -0.4 0.8 -3.4
    20 2013 CHI Tony Snell -0.1 18.5 -2.0
    21 2013 UTA Gorgui Dieng 7.3 30.8 0.3
    22 2013 BRK Mason Plumlee 12.7 46.3 1.2
    23 2013 IND Solomon Hill -0.3 11.9 -2.1
    24 2013 NYK Tim Hardaway Jr. 4.9 26.5 -0.8
    25 2013 LAC Reggie Bullock 2.6 18.5 -1.0
    26 2013 MIN Andre Roberson 2.3 12.6 -0.6
    27 2013 DEN Rudy Gobert 28.2 89.7 3.8
    29 2013 OKC Archie Goodwin -0.6 1.1 -3.0
    30 2013 PHO Nemanja Nedovic -0.3 -0.4 -10.0
    31 2013 CLE Allen Crabbe 0.9 13.7 -1.6
    32 2013 OKC Alex Abrines 0.1 5.0 -1.9
    33 2013 CLE Carrick Felix 0.0 0.0 -3.4
    34 2013 HOU Isaiah Canaan -0.5 4.3 -2.4
    35 2013 PHI Glen Rice Jr. -0.2 -0.2 -6.6
    36 2013 SAC Ray McCallum -0.4 2.1 -2.6
    37 2013 DET Tony Mitchell 0.0 0.2 0.4
    38 2013 WAS Nate Wolters -0.2 0.9 -2.6
    39 2013 POR Jeff Withey 1.3 6.8 0.5
    40 2013 POR Grant Jerrett -0.1 -0.1 -10.8
    41 2013 MEM Jamaal Franklin -0.2 0.0 -5.9
    42 2013 PHI Pierre Jackson -0.1 0.0 -4.4
    43 2013 MIL Ricky Ledo -0.4 -0.6 -7.6
    44 2013 DAL Mike Muscala 3.9 17.2 0.2
    46 2013 UTA Erick Green -0.2 0.1 -4.0
    47 2013 ATL Raul Neto 0.7 10.6 -1.6
    48 2013 LAL Ryan Kelly -0.5 3.0 -2.6
    49 2013 CHI Erik Murphy -0.1 -0.1 -8.6
    50 2013 ATL James Ennis III 0.9 16.2 -1.5
    52 2013 MIN Lorenzo Brown -0.5 -0.2 -3.5
    55 2013 MEM Joffrey Lauvergne -0.1 5.2 -2.1
    56 2013 DET Peyton Siva -0.2 -0.2 -6.4
    1 2014 CLE Andrew Wiggins 3.3 26.0 -1.4
    2 2014 MIL Jabari Parker 2.5 13.8 -0.8
    3 2014 PHI Joel Embiid 22.2 47.1 6.1
    4 2014 ORL Aaron Gordon 8.1 31.4 0.0
    5 2014 UTA Dante Exum -1.5 3.1 -3.3
    6 2014 BOS Marcus Smart 7.4 31.4 -0.2
    7 2014 LAL Julius Randle 10.9 34.2 0.5
    8 2014 SAC Nik Stauskas -1.7 3.9 -3.0
    9 2014 CHH Noah Vonleh -0.7 9.4 -2.5
    10 2014 PHI Elfrid Payton 3.7 15.8 -0.9
    11 2014 DEN Doug McDermott 0.3 19.7 -1.9
    12 2014 ORL Dario Saric 2.5 16.6 -0.9
    13 2014 MIN Zach LaVine 9.8 24.8 0.4
    14 2014 PHO T.J. Warren 4.3 19.9 -0.2
    15 2014 ATL Adreian Payne -1.4 -0.6 -5.9
    16 2014 CHI Jusuf Nurkic 6.6 25.4 0.5
    17 2014 BOS James Young -0.3 0.8 -3.4
    18 2014 PHO Tyler Ennis -0.8 1.3 -3.4
    19 2014 CHI Gary Harris 2.1 21.0 -1.4
    20 2014 TOR Bruno Caboclo -0.2 1.5 -2.7
    21 2014 OKC Mitch McGary -0.1 1.3 -2.6
    22 2014 MEM Jordan Adams 0.2 0.4 1.7
    23 2014 UTA Rodney Hood 2.2 17.4 -1.2
    24 2014 CHH Shabazz Napier 2.0 8.1 -0.7
    25 2014 HOU Clint Capela 13.5 55.9 2.0
    26 2014 MIA P.J. Hairston -1.0 0.9 -3.9
    27 2014 PHO Bogdan Bogdanovic 5.6 16.3 0.4
    28 2014 LAC C.J. Wilcox -0.2 0.1 -4.3
    29 2014 OKC Josh Huestis -0.4 0.7 -3.5
    30 2014 SAS Kyle Anderson 10.4 28.1 1.7
    31 2014 MIL Damien Inglis -0.1 -0.1 -5.6
    32 2014 PHI K.J. McDaniels -0.4 1.3 -2.8
    33 2014 CLE Joe Harris 3.8 21.4 -0.7
    34 2014 NYK Cleanthony Early -0.8 -0.6 -5.9
    35 2014 UTA Jarnell Stokes 0.1 0.6 0.1
    36 2014 MIL Johnny O'Bryant -1.8 0.2 -6.2
    38 2014 DET Spencer Dinwiddie 7.0 25.0 0.5
    39 2014 PHI Jerami Grant 6.7 31.0 -0.3
    40 2014 MIN Glenn Robinson III 0.4 7.9 -1.7
    41 2014 DEN Nikola Jokic 46.8 84.5 9.1
    42 2014 HOU Nick Johnson -0.3 -0.1 -6.5
    43 2014 ATL Edy Tavares 0.0 0.2 -0.4
    44 2014 MIN Markel Brown -0.4 1.1 -2.9
    45 2014 CHH Dwight Powell 8.0 39.3 1.1
    46 2014 WAS Jordan Clarkson 6.2 22.7 -0.5
    47 2014 PHI Russ Smith -0.1 -0.2 -5.1
    48 2014 MIL Lamar Patterson -0.4 0.1 -5.7
    49 2014 CHI Cameron Bairstow -0.3 -0.1 -8.1
    51 2014 NYK Thanasis Antetokounmpo -0.5 1.8 -3.6
    55 2014 MIA Semaj Christon -0.8 0.1 -5.1
    56 2014 DEN Devyn Marble -0.4 -0.3 -5.5
    58 2014 SAS Jordan McRae 0.0 1.7 -2.1
    60 2014 SAS Cory Jefferson -0.2 0.9 -3.3
    1 2015 MIN Karl-Anthony Towns 29.2 68.2 4.7
    2 2015 LAL D'Angelo Russell 8.5 15.8 0.5
    3 2015 PHI Jahlil Okafor 0.0 7.2 -2.0
    4 2015 NYK Kristaps Porzingis 10.8 30.0 1.8
    5 2015 ORL Mario Hezonja -1.2 3.2 -2.8
    6 2015 SAC Willie Cauley-Stein 4.4 23.3 -0.1
    7 2015 DEN Emmanuel Mudiay -2.2 -0.2 -3.2
    8 2015 DET Stanley Johnson -1.7 6.2 -2.8
    9 2015 CHO Frank Kaminsky 3.4 15.5 -0.3
    10 2015 MIA Justise Winslow -0.2 8.6 -2.1
    11 2015 IND Myles Turner 9.1 35.2 0.8
    12 2015 UTA Trey Lyles 1.9 14.8 -1.1
    13 2015 PHO Devin Booker 11.7 33.2 0.7
    14 2015 OKC Cameron Payne 2.3 9.2 -0.4
    15 2015 ATL Kelly Oubre Jr. 0.9 19.0 -1.7
    16 2015 BOS Terry Rozier 8.2 24.2 0.5
    17 2015 MIL Rashad Vaughn -1.2 -0.6 -4.7
    18 2015 HOU Sam Dekker 0.5 5.4 -1.4
    19 2015 WAS Jerian Grant 0.5 8.3 -1.6
    20 2015 TOR Delon Wright 9.1 23.0 2.2
    21 2015 DAL Justin Anderson 0.4 4.9 -1.5
    22 2015 CHI Bobby Portis 4.2 23.6 -0.5
    23 2015 POR Rondae Hollis-Jefferson 2.3 12.9 -0.7
    24 2015 CLE Tyus Jones 5.6 21.0 0.4
    25 2015 MEM Jarell Martin -1.7 3.2 -4.3
    27 2015 LAL Larry Nance Jr. 8.1 26.9 1.2
    28 2015 BOS R.J. Hunter 0.0 0.4 -2.0
    29 2015 BRK Chris McCullough -0.1 0.6 -2.5
    30 2015 GSW Kevon Looney 3.4 23.2 0.0
    31 2015 MIN Cedi Osman -0.8 8.4 -2.3
    32 2015 HOU Montrezl Harrell 12.1 41.5 2.7
    33 2015 BOS Jordan Mickey -0.3 0.5 -4.8
    34 2015 LAL Anthony Brown -0.6 -0.2 -5.1
    35 2015 PHI Willy Hernangomez 2.5 15.0 0.1
    36 2015 MIN Rakeem Christmas -0.2 0.5 -4.7
    37 2015 PHI Richaun Holmes 4.8 26.9 0.4
    38 2015 DET Darrun Hilliard -0.6 0.3 -4.7
    40 2015 MIA Josh Richardson 4.9 24.0 -0.6
    41 2015 BRK Pat Connaughton 3.8 18.2 -0.1
    43 2015 IND Joe Young -0.6 0.4 -4.1
    44 2015 PHO Andrew Harrison -0.6 3.2 -2.8
    46 2015 MIL Norman Powell 4.6 20.4 -0.2
    48 2015 OKC Dakari Johnson 0.1 0.6 -0.3
    56 2015 NOP Branden Dawson 0.0 0.0 -5.7
    1 2016 PHI Ben Simmons 13.9 31.7 3.6
    2 2016 LAL Brandon Ingram 5.7 20.0 -0.2
    3 2016 BOS Jaylen Brown 7.1 27.0 0.2
    4 2016 PHO Dragan Bender -1.9 0.5 -3.9
    5 2016 MIN Kris Dunn -0.2 3.9 -2.1
    6 2016 NOP Buddy Hield 7.8 18.2 0.1
    7 2016 DEN Jamal Murray 6.2 21.9 0.2
    8 2016 SAC Marquese Chriss -0.5 6.5 -2.4
    9 2016 TOR Jakob Poeltl 6.8 30.3 1.1
    10 2016 MIL Thon Maker -0.1 6.6 -2.1
    11 2016 ORL Domantas Sabonis 13.0 39.0 2.1
    12 2016 UTA Taurean Prince 0.4 8.7 -1.8
    13 2016 PHO Georgios Papagiannis -0.2 0.4 -3.9
    14 2016 CHI Denzel Valentine 0.2 4.5 -1.9
    15 2016 DEN Juancho Hernangomez 0.3 8.6 -1.7
    16 2016 BOS Guerschon Yabusele 0.0 1.1 -1.9
    17 2016 MEM Wade Baldwin -0.5 -0.3 -5.3
    18 2016 DET Henry Ellenson -0.3 0.4 -3.7
    19 2016 DEN Malik Beasley 2.5 11.9 -0.8
    20 2016 IND Caris LeVert 3.3 13.2 -0.6
    21 2016 ATL DeAndre' Bembry -0.4 4.4 -2.3
    22 2016 CHO Malachi Richardson -0.7 -0.1 -6.1
    23 2016 BOS Ante Zizic -0.2 3.5 -2.6
    24 2016 PHI Timothe Luwawu-Cabarrot -2.7 4.7 -4.0
    25 2016 LAC Brice Johnson 0.0 0.1 -0.6
    26 2016 PHI Furkan Korkmaz 0.2 7.2 -1.9
    27 2016 TOR Pascal Siakam 12.4 35.7 2.0
    28 2016 PHO Skal Labissiere -0.2 4.4 -2.3
    29 2016 SAS Dejounte Murray 8.9 18.2 1.9
    30 2016 GSW Damian Jones 0.8 9.5 -1.0
    31 2016 BOS Deyonta Davis 0.0 3.6 -2.1
    32 2016 LAL Ivica Zubac 4.7 28.6 0.4
    33 2016 LAC Cheick Diallo 0.3 6.3 -1.4
    34 2016 PHO Tyler Ulis -1.1 0.5 -3.6
    36 2016 MIL Malcolm Brogdon 8.6 26.1 1.2
    37 2016 HOU Chinanu Onuaku -0.1 0.1 -5.4
    38 2016 MIL Patrick McCaw -0.6 4.4 -2.8
    40 2016 NOP Diamond Stone -0.1 -0.1 -20.8
    41 2016 ORL Stephen Zimmerman -0.2 0.0 -8.3
    42 2016 UTA Isaiah Whitehead -1.4 -0.9 -5.0
    43 2016 HOU Zhou Qi -0.2 -0.2 -9.6
    45 2016 BOS Demetrius Jackson 0.1 0.2 -0.5
    46 2016 DAL A.J. Hammons -0.2 0.0 -6.6
    47 2016 ORL Jake Layman -0.2 3.8 -2.3
    48 2016 CHI Paul Zipser -1.4 0.0 -5.2
    49 2016 DET Michael Gbinije -0.1 -0.1 -12.1
    50 2016 IND Georges Niang 1.3 9.3 -0.9
    51 2016 BOS Ben Bentil -0.1 -0.1 -25.9
    52 2016 UTA Joel Bolomboy 0.0 0.3 -0.1
    53 2016 DEN Petr Cornelie -0.1 0.0 -8.8
    54 2016 ATL Kay Felder -0.4 -0.4 -4.7
    55 2016 BRK Marcus Paige 0.0 0.0 -8.8
    56 2016 DEN Daniel Hamilton -0.1 0.0 -3.3
    58 2016 BOS Abdel Nader -0.4 2.8 -2.6
    60 2016 UTA Tyrone Wallace -1.4 0.1 -5.2
    1 2017 PHI Markelle Fultz 0.0 3.6 -2.0
    2 2017 LAL Lonzo Ball 6.3 11.4 1.1
    3 2017 BOS Jayson Tatum 16.6 39.0 3.0
    4 2017 PHO Josh Jackson -3.1 -1.7 -3.8
    5 2017 SAC De'Aaron Fox 6.4 17.9 0.3
    6 2017 ORL Jonathan Isaac 2.0 6.7 0.2
    7 2017 MIN Lauri Markkanen 5.2 19.8 0.2
    8 2017 NYK Frank Ntilikina -2.6 0.5 -4.1
    9 2017 DAL Dennis Smith Jr. -0.2 0.1 -2.1
    10 2017 SAC Zach Collins -0.2 5.4 -2.3
    11 2017 CHO Malik Monk 0.6 7.0 -1.6
    12 2017 DET Luke Kennard 3.2 15.1 -0.3
    13 2017 DEN Donovan Mitchell 15.4 33.1 2.8
    14 2017 MIA Bam Adebayo 12.6 37.7 2.7
    15 2017 POR Justin Jackson -1.1 5.2 -2.9
    16 2017 CHI Justin Patton -0.1 0.4 -2.8
    17 2017 MIL D.J. Wilson -0.3 2.8 -2.6
    18 2017 IND T.J. Leaf 0.1 2.7 -1.8
    19 2017 ATL John Collins 7.6 29.5 1.3
    20 2017 POR Harry Giles -0.2 3.0 -2.4
    21 2017 OKC Terrance Ferguson -2.1 4.4 -4.0
    22 2017 BRK Jarrett Allen 9.3 37.9 1.8
    23 2017 TOR OG Anunoby 5.0 19.4 0.2
    24 2017 UTA Tyler Lydon -0.1 0.2 -4.3
    25 2017 ORL Anzejs Pasecniks -0.5 0.4 -6.2
    26 2017 POR Caleb Swanigan -0.7 -0.2 -6.2
    27 2017 BRK Kyle Kuzma 2.8 15.1 -1.0
    28 2017 LAL Tony Bradley 1.1 7.5 0.2
    29 2017 SAS Derrick White 6.0 17.5 1.1
    30 2017 UTA Josh Hart 3.9 17.8 -0.3
    31 2017 CHO Frank Jackson -1.9 2.5 -3.9
    32 2017 PHO Davon Reed -0.3 1.2 -3.2
    33 2017 ORL Wes Iwundu -1.8 4.2 -3.9
    34 2017 SAC Frank Mason III -0.3 1.2 -2.6
    35 2017 ORL Ivan Rabb 0.1 3.2 -1.7
    36 2017 PHI Jonah Bolden 0.1 1.4 -1.3
    37 2017 BOS Semi Ojeleye -1.5 5.2 -3.4
    38 2017 CHI Jordan Bell 1.1 4.9 0.2
    39 2017 PHI Jawun Evans -0.7 -0.4 -5.4
    40 2017 NOP Dwayne Bacon -3.1 0.8 -5.1
    41 2017 ATL Tyler Dorsey -0.4 1.1 -3.0
    42 2017 UTA Thomas Bryant 3.3 12.6 1.6
    43 2017 HOU Isaiah Hartenstein 2.5 10.4 1.5
    44 2017 NYK Damyean Dotson -0.9 3.0 -2.8
    45 2017 HOU Dillon Brooks -3.7 6.1 -3.7
    46 2017 PHI Sterling Brown -0.1 6.5 -2.1
    47 2017 IND Ike Anigbogu 0.0 0.0 -1.1
    48 2017 MIL Sindarius Thornwell -0.5 1.1 -3.1
    49 2017 DEN Vlatko Cancar 0.0 1.1 -2.3
    51 2017 DEN Monte Morris 4.4 19.9 0.3
    52 2017 NOP Edmond Sumner -0.4 2.6 -2.9
    53 2017 BOS Kadeem Allen 0.1 1.0 -1.2
    54 2017 PHO Alec Peters 0.0 0.3 -2.8
    55 2017 UTA Nigel Williams-Goss 0.0 0.0 -3.9
    56 2017 BOS Jabari Bird 0.0 0.2 -3.1
    59 2017 SAS Jaron Blossomgame -0.2 0.3 -3.8
    1 2018 PHO Deandre Ayton 6.5 27.3 1.2
    2 2018 SAC Marvin Bagley III 0.0 8.2 -2.0
    3 2018 ATL Luka Doncic 22.8 33.9 7.2
    4 2018 MEM Jaren Jackson Jr. 3.3 14.1 0.3
    5 2018 DAL Trae Young 12.9 28.3 3.0
    6 2018 ORL Mo Bamba 2.6 11.6 0.2
    7 2018 CHI Wendell Carter Jr. 2.2 14.8 -0.5
    8 2018 CLE Collin Sexton -0.8 7.0 -2.4
    9 2018 NYK Kevin Knox -2.7 0.2 -4.4
    10 2018 PHI Mikal Bridges 8.4 27.4 1.1
    11 2018 CHO Shai Gilgeous-Alexander 9.5 21.7 2.4
    12 2018 LAC Miles Bridges 3.8 16.0 -0.2
    13 2018 LAC Jerome Robinson -1.1 -0.1 -4.7
    14 2018 DEN Michael Porter Jr. 3.3 10.6 1.8
    15 2018 WAS Troy Brown Jr. -0.2 5.4 -2.1
    16 2018 PHO Zhaire Smith -0.1 0.0 -6.1
    17 2018 MIL Donte DiVincenzo 2.3 9.7 -0.2
    18 2018 SAS Lonnie Walker IV -1.1 3.2 -2.9
    19 2018 ATL Kevin Huerter 1.9 11.1 -1.2
    20 2018 MIN Josh Okogie -1.0 5.9 -2.7
    21 2018 UTA Grayson Allen 2.0 10.3 -0.4
    22 2018 CHI Chandler Hutchison -0.9 1.1 -3.9
    23 2018 IND Aaron Holiday -0.4 5.2 -2.3
    24 2018 POR Anfernee Simons 0.5 6.1 -1.7
    25 2018 LAL Moritz Wagner 0.4 6.5 -1.5
    26 2018 PHI Landry Shamet 0.3 11.1 -1.8
    27 2018 BOS Robert Williams 6.3 18.4 5.3
    28 2018 GSW Jacob Evans -0.8 -0.6 -7.4
    29 2018 BRK Dzanan Musa -0.4 0.0 -4.6
    30 2018 ATL Omari Spellman 0.2 2.4 -1.5
    31 2018 PHO Elie Okobo -0.9 0.5 -4.1
    32 2018 MEM Jevon Carter 1.2 6.2 -0.8
    33 2018 DAL Jalen Brunson 4.7 20.3 0.4
    34 2018 ATL Devonte' Graham 2.9 11.0 -0.3
    35 2018 ORL Melvin Frazier -0.6 -0.4 -10.0
    36 2018 NYK Mitchell Robinson 6.5 26.9 2.3
    37 2018 SAC Gary Trent Jr. 1.8 10.9 -0.9
    38 2018 PHI Khyri Thomas -0.1 0.5 -2.7
    39 2018 PHI Isaac Bonga -0.7 1.7 -3.6
    40 2018 BRK Rodions Kurucs -0.4 2.3 -2.8
    41 2018 ORL Jarred Vanderbilt 2.3 11.6 0.4
    42 2018 DET Bruce Brown 2.0 14.2 -0.9
    45 2018 BRK Hamidou Diallo -0.5 5.2 -2.4
    46 2018 HOU De'Anthony Melton 3.8 9.1 0.7
    47 2018 LAL Svi Mykhailiuk -0.6 2.6 -2.7
    48 2018 MIN Keita Bates-Diop -0.2 4.2 -2.3
    49 2018 SAS Chimezie Metu 0.0 2.8 -2.0
    50 2018 IND Alize Johnson -0.1 1.3 -2.4
    52 2018 UTA Vince Edwards 0.0 0.0 -6.4
    53 2018 OKC Devon Hall -0.1 -0.2 -6.7
    54 2018 DAL Shake Milton 0.3 8.2 -1.7
    55 2018 CHO Arnoldas Kulboka 0.0 0.0 -21.8
    56 2018 PHI Ray Spalding -0.2 0.1 -6.2
    57 2018 OKC Kevin Hervey 0.0 -0.1 -5.1
    58 2018 DEN Thomas Welsh 0.0 0.1 1.2
    59 2018 PHO George King -0.1 -0.1 -17.2
    60 2018 PHI Kostas Antetokounmpo -0.2 -0.2 -9.9
    1 2019 NOP Zion Williamson 6.2 13.9 5.2
    2 2019 MEM Ja Morant 7.4 16.2 2.3
    3 2019 NYK RJ Barrett -0.3 6.7 -2.2
    4 2019 LAL De'Andre Hunter -1.9 3.7 -3.5
    5 2019 CLE Darius Garland 1.9 8.4 -0.9
    6 2019 PHO Jarrett Culver -1.6 0.0 -4.5
    7 2019 CHI Coby White -0.7 6.0 -2.5
    8 2019 ATL Jaxson Hayes 1.7 12.4 0.0
    9 2019 WAS Rui Hachimura -1.0 5.5 -2.8
    10 2019 ATL Cam Reddish -1.0 1.7 -3.0
    11 2019 MIN Cameron Johnson 3.8 11.5 1.2
    12 2019 CHO P.J. Washington 1.5 8.6 -1.1
    13 2019 MIA Tyler Herro 2.7 8.4 -0.3
    14 2019 BOS Romeo Langford -0.4 1.8 -3.0
    15 2019 DET Sekou Doumbouya -1.8 -0.4 -6.5
    16 2019 ORL Chuma Okeke 1.1 4.1 -0.7
    17 2019 BRK Nickeil Alexander-Walker -0.4 1.1 -2.4
    18 2019 IND Goga Bitadze 0.4 4.4 -1.2
    19 2019 SAS Luka Samanic -0.3 0.1 -4.8
    20 2019 BOS Matisse Thybulle 3.4 9.2 0.9
    21 2019 OKC Brandon Clarke 5.3 17.2 2.6
    22 2019 BOS Grant Williams 0.7 10.1 -1.4
    23 2019 UTA Darius Bazley -0.7 2.4 -2.5
    24 2019 PHI Ty Jerome 0.0 2.3 -1.9
    25 2019 POR Nassir Little -0.1 3.8 -2.2
    26 2019 CLE Dylan Windler 0.1 1.3 -1.7
    27 2019 BRK Mfiondu Kabengele -0.1 0.4 -3.1
    28 2019 GSW Jordan Poole 0.5 7.3 -1.6
    29 2019 SAS Keldon Johnson 1.1 9.2 -1.2
    30 2019 MIL Kevin Porter Jr. -0.5 1.9 -2.4
    31 2019 BRK Nic Claxton 1.7 8.6 0.7
    32 2019 PHO KZ Okpala -0.6 1.0 -4.7
    33 2019 PHI Carsen Edwards -0.5 0.3 -5.1
    34 2019 PHI Bruno Fernando -0.4 1.7 -3.3
    35 2019 ATL Didi Louzada -0.3 -0.1 -8.1
    36 2019 CHO Cody Martin 0.7 6.0 -1.3
    37 2019 DAL Deividas Sirvydis -0.2 -0.1 -5.9
    38 2019 CHI Daniel Gafford 2.5 12.7 1.0
    39 2019 NOP Alen Smailagic -0.1 0.3 -3.3
    40 2019 SAC Justin James -0.2 0.3 -3.1
    41 2019 GSW Eric Paschall -0.1 5.0 -2.2
    42 2019 PHI Admiral Schofield -0.8 0.8 -5.0
    43 2019 MIN Jaylen Nowell 0.5 4.2 -1.2
    44 2019 MIA Bol Bol 0.6 2.1 0.3
    45 2019 DET Isaiah Roby 0.1 4.3 -1.9
    46 2019 ORL Talen Horton-Tucker -0.2 3.5 -2.3
    47 2019 SAC Ignas Brazdeikis -0.6 0.4 -4.9
    48 2019 LAC Terance Mann 1.7 11.6 -0.5
    49 2019 SAS Quinndary Weatherspoon -0.2 0.2 -5.5
    50 2019 IND Jarrell Brantley 0.1 0.5 -0.6
    51 2019 BOS Tremont Waters -0.1 0.1 -3.0
    52 2019 CHO Jalen McDaniels -0.3 4.7 -2.4
    53 2019 UTA Justin Wright-Foreman -0.1 0.0 -9.0
    54 2019 PHI Marial Shayok -0.1 -0.1 -13.0
    55 2019 NYK Kyle Guy -0.3 0.1 -4.9
    57 2019 NOP Jordan Bone -0.2 0.1 -5.9
    58 2019 GSW Miye Oni -0.1 1.0 -2.5
    59 2019 TOR Dewan Hernandez -0.1 0.0 -9.6
    1 2020 MIN Anthony Edwards 2.2 6.4 -0.5
    2 2020 GSW James Wiseman -0.7 1.2 -4.6
    3 2020 CHO LaMelo Ball 4.8 8.9 2.7
    4 2020 CHI Patrick Williams -0.1 4.2 -2.1
    5 2020 CLE Isaac Okoro -1.7 5.8 -3.4
    6 2020 ATL Onyeka Okongwu 1.0 8.1 -0.3
    7 2020 DET Killian Hayes -1.7 -0.6 -4.1
    8 2020 NYK Obi Toppin 1.6 6.1 0.8
    9 2020 WAS Deni Avdija -0.4 4.3 -2.4
    10 2020 PHO Jalen Smith 0.1 3.7 -1.8
    11 2020 SAS Devin Vassell 1.5 6.0 -0.4
    12 2020 SAC Tyrese Haliburton 6.6 14.2 2.9
    13 2020 NOP Kira Lewis Jr. -0.5 0.7 -3.6
    14 2020 BOS Aaron Nesmith -0.7 1.9 -3.6
    15 2020 ORL Cole Anthony 0.2 2.3 -1.8
    16 2020 POR Isaiah Stewart 0.0 9.0 -2.0
    17 2020 MIN Aleksej Pokusevski -1.1 -0.8 -3.5
    18 2020 DAL Josh Green 0.3 4.4 -1.3
    19 2020 BRK Saddiq Bey 2.0 8.3 -0.5
    20 2020 MIA Precious Achiuwa -0.8 4.1 -3.1
    21 2020 PHI Tyrese Maxey 2.2 10.4 0.1
    22 2020 DEN Zeke Nnaji -0.1 3.0 -2.4
    23 2020 NYK Leandro Bolmaro -0.3 -0.1 -6.2
    24 2020 MIL R.J. Hampton -1.0 0.8 -3.6
    25 2020 OKC Immanuel Quickley 2.2 8.7 0.3
    26 2020 BOS Payton Pritchard 1.3 5.7 0.1
    27 2020 UTA Udoka Azubuike 0.1 1.0 -0.9
    28 2020 LAL Jaden McDaniels -1.0 5.0 -2.9
    29 2020 TOR Malachi Flynn 0.0 2.2 -2.1
    30 2020 BOS Desmond Bane 3.9 11.8 1.7
    31 2020 DAL Tyrell Terry 0.0 0.0 -4.8
    32 2020 CHO Vernon Carey Jr. -0.2 0.1 -7.6
    33 2020 MIN Daniel Oturu -0.2 0.3 -5.2
    34 2020 PHI Theo Maledon -1.8 0.2 -4.3
    35 2020 SAC Xavier Tillman Sr. 1.0 5.0 0.1
    36 2020 PHI Tyler Bey -0.1 0.0 -9.5
    37 2020 WAS Vit Krejci -0.6 0.7 -5.0
    38 2020 UTA Saben Lee 0.2 2.4 -1.3
    39 2020 NOP Elijah Hughes -0.5 -0.4 -6.4
    40 2020 MEM Robert Woodard II -0.1 -0.1 -7.7
    41 2020 SAS Tre Jones 0.4 4.4 -1.3
    42 2020 NOP Nick Richards -0.1 2.9 -2.3
    43 2020 SAC Jahmi'us Ramsey -0.2 -0.1 -5.9
    44 2020 CHI Marko Simonovic -0.1 0.0 -12.3
    45 2020 MIL Jordan Nwora -0.7 1.5 -3.4
    46 2020 POR CJ Elleby -1.1 0.5 -5.2
    48 2020 GSW Nico Mannion -0.2 0.2 -3.9
    49 2020 PHI Isaiah Joe -0.1 1.9 -2.3
    50 2020 ATL Skylar Mays 0.3 1.1 0.1
    52 2020 SAC Kenyon Martin Jr. 0.7 6.5 -1.2
    53 2020 OKC Cassius Winston -0.1 0.1 -4.9
    54 2020 IND Cassius Stanley -0.4 0.0 -7.9
    55 2020 BRK Jay Scrubb -0.3 -0.1 -7.3
    56 2020 CHO Grant Riller 0.0 0.1 5.1
    57 2020 LAC Reggie Perry -0.3 0.4 -5.5
    58 2020 PHI Paul Reed 0.4 2.8 0.2
    59 2020 TOR Jalen Harris 0.1 0.3 0.3
    60 2020 NOP Sam Merrill 0.0 0.5 -1.9
    1 2021 DET Cade Cunningham 0.3 -0.5 -1.5
    2 2021 HOU Jalen Green -0.5 1.5 -2.6
    3 2021 CLE Evan Mobley 2.5 8.6 1.0
    4 2021 TOR Scottie Barnes 2.3 7.7 0.6
    5 2021 ORL Jalen Suggs -1.2 -1.6 -4.9
    6 2021 OKC Josh Giddey 0.5 0.7 -1.2
    7 2021 GSW Jonathan Kuminga -0.1 3.4 -2.2
    8 2021 ORL Franz Wagner 1.2 6.0 -0.7
    9 2021 SAC Davion Mitchell -1.1 0.4 -3.7
    10 2021 NOP Ziaire Williams -0.5 2.1 -3.4
    11 2021 CHO James Bouknight -0.8 -0.2 -6.7
    12 2021 SAS Joshua Primo -0.8 -0.1 -5.1
    13 2021 IND Chris Duarte -0.2 1.0 -2.5
    14 2021 GSW Moses Moody -0.2 1.6 -2.8
    15 2021 WAS Corey Kispert -0.1 3.4 -2.2
    16 2021 OKC Alperen Sengun 0.7 3.8 -0.8
    17 2021 MEM Trey Murphy III 0.9 4.1 0.3
    18 2021 OKC Tre Mann -1.2 0.1 -4.4
    19 2021 NYK Kai Jones -0.2 0.2 -5.5
    20 2021 ATL Jalen Johnson -0.1 0.6 -2.6
    21 2021 NYK Keon Johnson -0.8 -0.7 -6.1
    22 2021 LAL Isaiah Jackson 0.1 2.5 -1.3
    23 2021 HOU Usman Garuba 0.4 1.5 0.5
    24 2021 HOU Josh Christopher -0.6 0.2 -3.7
    25 2021 LAC Quentin Grimes 0.5 2.2 -0.3
    26 2021 DEN Bones Hyland 0.9 3.1 0.0
    27 2021 BRK Cam Thomas -0.6 1.1 -3.5
    28 2021 PHI Jaden Springer 0.0 0.0 2.1
    29 2021 PHO Day'Ron Sharpe -0.1 1.7 -2.8
    30 2021 UTA Santi Aldama 0.3 2.5 -0.9
    31 2021 MIL Isaiah Todd -0.1 -0.2 -7.9
    32 2021 NYK Jeremiah Robinson-Earl 0.2 3.0 -1.5
    33 2021 ORL Jason Preston 0.0 0.0 -1.2
    35 2021 NOP Herbert Jones 1.0 5.7 -0.6
    36 2021 OKC Miles McBride -0.2 0.4 -3.7
    37 2021 DET JT Thor -0.2 0.2 -4.2
    38 2021 CHI Ayo Dosunmu 0.0 4.1 -2.0
    39 2021 SAC Neemias Queta -0.1 0.1 -5.1
    40 2021 NOP Jared Butler 0.0 0.4 -1.6
    41 2021 SAS Joe Wieskamp -0.1 0.1 -3.9
    42 2021 DET Isaiah Livers 0.0 1.0 -1.9
    43 2021 NOP Greg Brown III -0.5 0.4 -4.7
    44 2021 BRK Kessler Edwards -0.6 0.5 -4.2
    46 2021 TOR Dalano Banton 0.0 0.9 -2.0
    47 2021 TOR David Johnson 0.0 0.0 -27.7
    48 2021 ATL Sharife Cooper -0.1 -0.2 -16.3
    51 2021 MEM Brandon Boston Jr. -0.3 0.5 -3.2
    52 2021 DET Luka Garza -0.1 0.8 -2.6
    53 2021 PHI Charles Bassey 0.4 1.6 1.1
    54 2021 IND Sandro Mamukelashvili 0.1 1.2 -1.2
    55 2021 OKC Aaron Wiggins -0.6 2.0 -3.6
    56 2021 CHO Scottie Lewis 0.0 0.0 6.0
    58 2021 NYK Jericho Sims 0.2 2.6 -0.8
    60 2021 IND Georgios Kalaitzakis -0.3 -0.1 -7.0
    


```python
ratings = []
raw_ratings = []


for x in range (0, len(names)):
    raw_rating = vorp[x] + 5
    pick_rating = (raw_rating  * pick[x]/60)
    ratings.append(pick_rating)
    raw_ratings.append(raw_rating)

num = 0
for i in names:
    print(i)
    print(raw_ratings[num])
    print(ratings[num])
    num += 1
    
```

    Anthony Davis
    49.3
    0.8216666666666667
    Michael Kidd-Gilchrist
    5.6
    0.18666666666666665
    Bradley Beal
    26.7
    1.335
    Dion Waiters
    4.6
    0.30666666666666664
    Thomas Robinson
    3.4
    0.2833333333333333
    Damian Lillard
    49.9
    4.989999999999999
    Harrison Barnes
    12.4
    1.4466666666666665
    Terrence Ross
    9.3
    1.24
    Andre Drummond
    22.8
    3.4200000000000004
    Austin Rivers
    0.5
    0.08333333333333333
    Meyers Leonard
    6.1
    1.1183333333333332
    Jeremy Lamb
    12.9
    2.58
    Kendall Marshall
    3.9
    0.845
    John Henson
    8.4
    1.9600000000000002
    Maurice Harkless
    9.1
    2.275
    Royce White
    5.0
    1.3333333333333333
    Tyler Zeller
    5.0
    1.4166666666666667
    Terrence Jones
    8.6
    2.5799999999999996
    Andrew Nicholson
    3.4
    1.0766666666666667
    Evan Fournier
    9.8
    3.2666666666666666
    Jared Sullinger
    7.7
    2.6950000000000003
    Fab Melo
    4.9
    1.7966666666666669
    John Jenkins
    5.1
    1.9549999999999998
    Jared Cunningham
    4.4
    1.7600000000000002
    Tony Wroten
    3.9
    1.625
    Miles Plumlee
    5.2
    2.2533333333333334
    Arnett Moultrie
    4.9
    2.205
    Perry Jones
    4.4
    2.0533333333333337
    Marquis Teague
    4.0
    1.9333333333333333
    Festus Ezeli
    5.0
    2.5
    Jeff Taylor
    3.5
    1.8083333333333333
    Tomas Satoransky
    7.4
    3.9466666666666668
    Bernard James
    5.0
    2.75
    Jae Crowder
    15.9
    9.01
    Draymond Green
    28.6
    16.683333333333334
    Orlando Johnson
    4.9
    2.94
    Quincy Acy
    4.9
    3.021666666666667
    Quincy Miller
    4.5
    2.85
    Khris Middleton
    19.3
    12.545
    Will Barton
    11.9
    7.933333333333334
    Tyshawn Taylor
    4.2
    2.87
    Doron Lamb
    3.8
    2.6599999999999997
    Mike Scott
    5.6
    4.013333333333333
    Kim English
    4.8
    3.52
    Justin Hamilton
    5.5
    4.125
    Darius Miller
    4.6
    3.5266666666666664
    Kevin Murphy
    4.8
    3.76
    Kostas Papanikolaou
    4.8
    3.8399999999999994
    Kyle O'Quinn
    10.0
    8.166666666666666
    Kris Joseph
    4.9
    4.165
    Ognjen Kuzmic
    4.8
    4.16
    Furkan Aldemir
    4.8
    4.239999999999999
    Tornike Shengelia
    4.7
    4.23
    Darius Johnson-Odom
    4.9
    4.491666666666666
    Robbie Hummel
    4.6
    4.446666666666666
    Robert Sacre
    3.6
    3.6
    Anthony Bennett
    3.7
    0.06166666666666667
    Victor Oladipo
    16.0
    0.5333333333333333
    Otto Porter Jr.
    17.6
    0.8800000000000001
    Cody Zeller
    9.0
    0.6
    Alex Len
    5.2
    0.43333333333333335
    Nerlens Noel
    12.5
    1.25
    Ben McLemore
    1.6
    0.18666666666666668
    Kentavious Caldwell-Pope
    11.1
    1.48
    Trey Burke
    6.7
    1.0050000000000001
    CJ McCollum
    20.9
    3.4833333333333334
    Michael Carter-Williams
    6.9
    1.2650000000000001
    Steven Adams
    16.6
    3.3200000000000003
    Kelly Olynyk
    15.6
    3.38
    Shabazz Muhammad
    5.0
    1.1666666666666667
    Giannis Antetokounmpo
    50.1
    12.525
    Lucas Nogueira
    6.9
    1.84
    Dennis Schroder
    8.1
    2.295
    Shane Larkin
    4.4
    1.32
    Sergey Karasev
    4.6
    1.4566666666666666
    Tony Snell
    4.9
    1.6333333333333333
    Gorgui Dieng
    12.3
    4.305000000000001
    Mason Plumlee
    17.7
    6.489999999999999
    Solomon Hill
    4.7
    1.8016666666666667
    Tim Hardaway Jr.
    9.9
    3.9600000000000004
    Reggie Bullock
    7.6
    3.1666666666666665
    Andre Roberson
    7.3
    3.163333333333333
    Rudy Gobert
    33.2
    14.940000000000001
    Archie Goodwin
    4.4
    2.126666666666667
    Nemanja Nedovic
    4.7
    2.35
    Allen Crabbe
    5.9
    3.0483333333333333
    Alex Abrines
    5.1
    2.7199999999999998
    Carrick Felix
    5.0
    2.75
    Isaiah Canaan
    4.5
    2.55
    Glen Rice Jr.
    4.8
    2.8
    Ray McCallum
    4.6
    2.76
    Tony Mitchell
    5.0
    3.0833333333333335
    Nate Wolters
    4.8
    3.04
    Jeff Withey
    6.3
    4.095
    Grant Jerrett
    4.9
    3.2666666666666666
    Jamaal Franklin
    4.8
    3.28
    Pierre Jackson
    4.9
    3.43
    Ricky Ledo
    4.6
    3.2966666666666664
    Mike Muscala
    8.9
    6.526666666666667
    Erick Green
    4.8
    3.6799999999999997
    Raul Neto
    5.7
    4.465000000000001
    Ryan Kelly
    4.5
    3.6
    Erik Murphy
    4.9
    4.001666666666667
    James Ennis III
    5.9
    4.916666666666667
    Lorenzo Brown
    4.5
    3.9
    Joffrey Lauvergne
    4.9
    4.491666666666666
    Peyton Siva
    4.8
    4.48
    Andrew Wiggins
    8.3
    0.13833333333333334
    Jabari Parker
    7.5
    0.25
    Joel Embiid
    27.2
    1.3599999999999999
    Aaron Gordon
    13.1
    0.8733333333333333
    Dante Exum
    3.5
    0.2916666666666667
    Marcus Smart
    12.4
    1.24
    Julius Randle
    15.9
    1.855
    Nik Stauskas
    3.3
    0.44
    Noah Vonleh
    4.3
    0.6449999999999999
    Elfrid Payton
    8.7
    1.45
    Doug McDermott
    5.3
    0.9716666666666666
    Dario Saric
    7.5
    1.5
    Zach LaVine
    14.8
    3.2066666666666666
    T.J. Warren
    9.3
    2.1700000000000004
    Adreian Payne
    3.6
    0.9
    Jusuf Nurkic
    11.6
    3.0933333333333333
    James Young
    4.7
    1.3316666666666668
    Tyler Ennis
    4.2
    1.2600000000000002
    Gary Harris
    7.1
    2.2483333333333335
    Bruno Caboclo
    4.8
    1.6
    Mitch McGary
    4.9
    1.715
    Jordan Adams
    5.2
    1.9066666666666667
    Rodney Hood
    7.2
    2.76
    Shabazz Napier
    7.0
    2.8
    Clint Capela
    18.5
    7.708333333333333
    P.J. Hairston
    4.0
    1.7333333333333334
    Bogdan Bogdanovic
    10.6
    4.77
    C.J. Wilcox
    4.8
    2.24
    Josh Huestis
    4.6
    2.223333333333333
    Kyle Anderson
    15.4
    7.7
    Damien Inglis
    4.9
    2.5316666666666667
    K.J. McDaniels
    4.6
    2.453333333333333
    Joe Harris
    8.8
    4.840000000000001
    Cleanthony Early
    4.2
    2.3800000000000003
    Jarnell Stokes
    5.1
    2.975
    Johnny O'Bryant
    3.2
    1.9200000000000002
    Spencer Dinwiddie
    12.0
    7.6
    Jerami Grant
    11.7
    7.6049999999999995
    Glenn Robinson III
    5.4
    3.6
    Nikola Jokic
    51.8
    35.39666666666666
    Nick Johnson
    4.7
    3.29
    Edy Tavares
    5.0
    3.5833333333333335
    Markel Brown
    4.6
    3.373333333333333
    Dwight Powell
    13.0
    9.75
    Jordan Clarkson
    11.2
    8.586666666666666
    Russ Smith
    4.9
    3.8383333333333334
    Lamar Patterson
    4.6
    3.6799999999999997
    Cameron Bairstow
    4.7
    3.8383333333333334
    Thanasis Antetokounmpo
    4.5
    3.825
    Semaj Christon
    4.2
    3.85
    Devyn Marble
    4.6
    4.293333333333333
    Jordan McRae
    5.0
    4.833333333333333
    Cory Jefferson
    4.8
    4.8
    Karl-Anthony Towns
    34.2
    0.5700000000000001
    D'Angelo Russell
    13.5
    0.45
    Jahlil Okafor
    5.0
    0.25
    Kristaps Porzingis
    15.8
    1.0533333333333335
    Mario Hezonja
    3.8
    0.31666666666666665
    Willie Cauley-Stein
    9.4
    0.9400000000000001
    Emmanuel Mudiay
    2.8
    0.3266666666666666
    Stanley Johnson
    3.3
    0.44
    Frank Kaminsky
    8.4
    1.2600000000000002
    Justise Winslow
    4.8
    0.8
    Myles Turner
    14.1
    2.585
    Trey Lyles
    6.9
    1.3800000000000001
    Devin Booker
    16.7
    3.618333333333333
    Cameron Payne
    7.3
    1.7033333333333334
    Kelly Oubre Jr.
    5.9
    1.475
    Terry Rozier
    13.2
    3.52
    Rashad Vaughn
    3.8
    1.0766666666666667
    Sam Dekker
    5.5
    1.65
    Jerian Grant
    5.5
    1.7416666666666667
    Delon Wright
    14.1
    4.7
    Justin Anderson
    5.4
    1.8900000000000001
    Bobby Portis
    9.2
    3.373333333333333
    Rondae Hollis-Jefferson
    7.3
    2.7983333333333333
    Tyus Jones
    10.6
    4.239999999999999
    Jarell Martin
    3.3
    1.375
    Larry Nance Jr.
    13.1
    5.895
    R.J. Hunter
    5.0
    2.3333333333333335
    Chris McCullough
    4.9
    2.3683333333333336
    Kevon Looney
    8.4
    4.2
    Cedi Osman
    4.2
    2.1700000000000004
    Montrezl Harrell
    17.1
    9.120000000000001
    Jordan Mickey
    4.7
    2.585
    Anthony Brown
    4.4
    2.4933333333333336
    Willy Hernangomez
    7.5
    4.375
    Rakeem Christmas
    4.8
    2.88
    Richaun Holmes
    9.8
    6.043333333333334
    Darrun Hilliard
    4.4
    2.786666666666667
    Josh Richardson
    9.9
    6.6
    Pat Connaughton
    8.8
    6.013333333333334
    Joe Young
    4.4
    3.1533333333333338
    Andrew Harrison
    4.4
    3.226666666666667
    Norman Powell
    9.6
    7.359999999999999
    Dakari Johnson
    5.1
    4.08
    Branden Dawson
    5.0
    4.666666666666667
    Ben Simmons
    18.9
    0.315
    Brandon Ingram
    10.7
    0.35666666666666663
    Jaylen Brown
    12.1
    0.605
    Dragan Bender
    3.1
    0.20666666666666667
    Kris Dunn
    4.8
    0.4
    Buddy Hield
    12.8
    1.2800000000000002
    Jamal Murray
    11.2
    1.3066666666666664
    Marquese Chriss
    4.5
    0.6
    Jakob Poeltl
    11.8
    1.77
    Thon Maker
    4.9
    0.8166666666666667
    Domantas Sabonis
    18.0
    3.3
    Taurean Prince
    5.4
    1.0800000000000003
    Georgios Papagiannis
    4.8
    1.04
    Denzel Valentine
    5.2
    1.2133333333333334
    Juancho Hernangomez
    5.3
    1.325
    Guerschon Yabusele
    5.0
    1.3333333333333333
    Wade Baldwin
    4.5
    1.275
    Henry Ellenson
    4.7
    1.4100000000000001
    Malik Beasley
    7.5
    2.375
    Caris LeVert
    8.3
    2.7666666666666666
    DeAndre' Bembry
    4.6
    1.6099999999999999
    Malachi Richardson
    4.3
    1.5766666666666667
    Ante Zizic
    4.8
    1.8399999999999999
    Timothe Luwawu-Cabarrot
    2.3
    0.9199999999999999
    Brice Johnson
    5.0
    2.0833333333333335
    Furkan Korkmaz
    5.2
    2.2533333333333334
    Pascal Siakam
    17.4
    7.829999999999999
    Skal Labissiere
    4.8
    2.24
    Dejounte Murray
    13.9
    6.718333333333334
    Damian Jones
    5.8
    2.9
    Deyonta Davis
    5.0
    2.5833333333333335
    Ivica Zubac
    9.7
    5.173333333333333
    Cheick Diallo
    5.3
    2.915
    Tyler Ulis
    3.9
    2.21
    Malcolm Brogdon
    13.6
    8.16
    Chinanu Onuaku
    4.9
    3.021666666666667
    Patrick McCaw
    4.4
    2.786666666666667
    Diamond Stone
    4.9
    3.2666666666666666
    Stephen Zimmerman
    4.8
    3.28
    Isaiah Whitehead
    3.6
    2.5200000000000005
    Zhou Qi
    4.8
    3.44
    Demetrius Jackson
    5.1
    3.8249999999999997
    A.J. Hammons
    4.8
    3.6799999999999997
    Jake Layman
    4.8
    3.76
    Paul Zipser
    3.6
    2.8800000000000003
    Michael Gbinije
    4.9
    4.001666666666667
    Georges Niang
    6.3
    5.25
    Ben Bentil
    4.9
    4.165
    Joel Bolomboy
    5.0
    4.333333333333333
    Petr Cornelie
    4.9
    4.328333333333334
    Kay Felder
    4.6
    4.14
    Marcus Paige
    5.0
    4.583333333333333
    Daniel Hamilton
    4.9
    4.573333333333334
    Abdel Nader
    4.6
    4.446666666666666
    Tyrone Wallace
    3.6
    3.6
    Markelle Fultz
    5.0
    0.08333333333333333
    Lonzo Ball
    11.3
    0.3766666666666667
    Jayson Tatum
    21.6
    1.0800000000000003
    Josh Jackson
    1.9
    0.12666666666666665
    De'Aaron Fox
    11.4
    0.95
    Jonathan Isaac
    7.0
    0.7
    Lauri Markkanen
    10.2
    1.19
    Frank Ntilikina
    2.4
    0.32
    Dennis Smith Jr.
    4.8
    0.72
    Zach Collins
    4.8
    0.8
    Malik Monk
    5.6
    1.0266666666666666
    Luke Kennard
    8.2
    1.64
    Donovan Mitchell
    20.4
    4.42
    Bam Adebayo
    17.6
    4.106666666666667
    Justin Jackson
    3.9
    0.975
    Justin Patton
    4.9
    1.3066666666666669
    D.J. Wilson
    4.7
    1.3316666666666668
    T.J. Leaf
    5.1
    1.53
    John Collins
    12.6
    3.99
    Harry Giles
    4.8
    1.6
    Terrance Ferguson
    2.9
    1.015
    Jarrett Allen
    14.3
    5.243333333333334
    OG Anunoby
    10.0
    3.8333333333333335
    Tyler Lydon
    4.9
    1.9600000000000002
    Anzejs Pasecniks
    4.5
    1.875
    Caleb Swanigan
    4.3
    1.8633333333333333
    Kyle Kuzma
    7.8
    3.51
    Tony Bradley
    6.1
    2.8466666666666662
    Derrick White
    11.0
    5.316666666666666
    Josh Hart
    8.9
    4.45
    Frank Jackson
    3.1
    1.6016666666666668
    Davon Reed
    4.7
    2.506666666666667
    Wes Iwundu
    3.2
    1.7600000000000002
    Frank Mason III
    4.7
    2.6633333333333336
    Ivan Rabb
    5.1
    2.975
    Jonah Bolden
    5.1
    3.06
    Semi Ojeleye
    3.5
    2.158333333333333
    Jordan Bell
    6.1
    3.863333333333333
    Jawun Evans
    4.3
    2.795
    Dwayne Bacon
    1.9
    1.2666666666666666
    Tyler Dorsey
    4.6
    3.143333333333333
    Thomas Bryant
    8.3
    5.8100000000000005
    Isaiah Hartenstein
    7.5
    5.375
    Damyean Dotson
    4.1
    3.0066666666666664
    Dillon Brooks
    1.2999999999999998
    0.9749999999999999
    Sterling Brown
    4.9
    3.756666666666667
    Ike Anigbogu
    5.0
    3.9166666666666665
    Sindarius Thornwell
    4.5
    3.6
    Vlatko Cancar
    5.0
    4.083333333333333
    Monte Morris
    9.4
    7.99
    Edmond Sumner
    4.6
    3.9866666666666664
    Kadeem Allen
    5.1
    4.504999999999999
    Alec Peters
    5.0
    4.5
    Nigel Williams-Goss
    5.0
    4.583333333333333
    Jabari Bird
    5.0
    4.666666666666667
    Jaron Blossomgame
    4.8
    4.72
    Deandre Ayton
    11.5
    0.19166666666666668
    Marvin Bagley III
    5.0
    0.16666666666666666
    Luka Doncic
    27.8
    1.3900000000000001
    Jaren Jackson Jr.
    8.3
    0.5533333333333333
    Trae Young
    17.9
    1.4916666666666667
    Mo Bamba
    7.6
    0.7599999999999999
    Wendell Carter Jr.
    7.2
    0.84
    Collin Sexton
    4.2
    0.56
    Kevin Knox
    2.3
    0.345
    Mikal Bridges
    13.4
    2.2333333333333334
    Shai Gilgeous-Alexander
    14.5
    2.658333333333333
    Miles Bridges
    8.8
    1.7600000000000002
    Jerome Robinson
    3.9
    0.845
    Michael Porter Jr.
    8.3
    1.936666666666667
    Troy Brown Jr.
    4.8
    1.2
    Zhaire Smith
    4.9
    1.3066666666666669
    Donte DiVincenzo
    7.3
    2.0683333333333334
    Lonnie Walker IV
    3.9
    1.1700000000000002
    Kevin Huerter
    6.9
    2.185
    Josh Okogie
    4.0
    1.3333333333333333
    Grayson Allen
    7.0
    2.45
    Chandler Hutchison
    4.1
    1.5033333333333332
    Aaron Holiday
    4.6
    1.7633333333333332
    Anfernee Simons
    5.5
    2.2
    Moritz Wagner
    5.4
    2.25
    Landry Shamet
    5.3
    2.2966666666666664
    Robert Williams
    11.3
    5.085
    Jacob Evans
    4.2
    1.9600000000000002
    Dzanan Musa
    4.6
    2.223333333333333
    Omari Spellman
    5.2
    2.6
    Elie Okobo
    4.1
    2.118333333333333
    Jevon Carter
    6.2
    3.3066666666666666
    Jalen Brunson
    9.7
    5.334999999999999
    Devonte' Graham
    7.9
    4.4766666666666675
    Melvin Frazier
    4.4
    2.566666666666667
    Mitchell Robinson
    11.5
    6.9
    Gary Trent Jr.
    6.8
    4.193333333333333
    Khyri Thomas
    4.9
    3.1033333333333335
    Isaac Bonga
    4.3
    2.795
    Rodions Kurucs
    4.6
    3.066666666666667
    Jarred Vanderbilt
    7.3
    4.988333333333333
    Bruce Brown
    7.0
    4.9
    Hamidou Diallo
    4.5
    3.375
    De'Anthony Melton
    8.8
    6.746666666666667
    Svi Mykhailiuk
    4.4
    3.4466666666666668
    Keita Bates-Diop
    4.8
    3.8399999999999994
    Chimezie Metu
    5.0
    4.083333333333333
    Alize Johnson
    4.9
    4.083333333333334
    Vince Edwards
    5.0
    4.333333333333333
    Devon Hall
    4.9
    4.328333333333334
    Shake Milton
    5.3
    4.77
    Arnoldas Kulboka
    5.0
    4.583333333333333
    Ray Spalding
    4.8
    4.48
    Kevin Hervey
    5.0
    4.75
    Thomas Welsh
    5.0
    4.833333333333333
    George King
    4.9
    4.818333333333333
    Kostas Antetokounmpo
    4.8
    4.8
    Zion Williamson
    11.2
    0.18666666666666665
    Ja Morant
    12.4
    0.41333333333333333
    RJ Barrett
    4.7
    0.23500000000000001
    De'Andre Hunter
    3.1
    0.20666666666666667
    Darius Garland
    6.9
    0.575
    Jarrett Culver
    3.4
    0.33999999999999997
    Coby White
    4.3
    0.5016666666666666
    Jaxson Hayes
    6.7
    0.8933333333333333
    Rui Hachimura
    4.0
    0.6
    Cam Reddish
    4.0
    0.6666666666666666
    Cameron Johnson
    8.8
    1.6133333333333335
    P.J. Washington
    6.5
    1.3
    Tyler Herro
    7.7
    1.6683333333333334
    Romeo Langford
    4.6
    1.0733333333333333
    Sekou Doumbouya
    3.2
    0.8
    Chuma Okeke
    6.1
    1.6266666666666665
    Nickeil Alexander-Walker
    4.6
    1.3033333333333332
    Goga Bitadze
    5.4
    1.62
    Luka Samanic
    4.7
    1.4883333333333333
    Matisse Thybulle
    8.4
    2.8
    Brandon Clarke
    10.3
    3.605
    Grant Williams
    5.7
    2.0900000000000003
    Darius Bazley
    4.3
    1.6483333333333332
    Ty Jerome
    5.0
    2.0
    Nassir Little
    4.9
    2.041666666666667
    Dylan Windler
    5.1
    2.21
    Mfiondu Kabengele
    4.9
    2.205
    Jordan Poole
    5.5
    2.566666666666667
    Keldon Johnson
    6.1
    2.948333333333333
    Kevin Porter Jr.
    4.5
    2.25
    Nic Claxton
    6.7
    3.461666666666667
    KZ Okpala
    4.4
    2.3466666666666667
    Carsen Edwards
    4.5
    2.475
    Bruno Fernando
    4.6
    2.6066666666666665
    Didi Louzada
    4.7
    2.7416666666666667
    Cody Martin
    5.7
    3.4200000000000004
    Deividas Sirvydis
    4.8
    2.96
    Daniel Gafford
    7.5
    4.75
    Alen Smailagic
    4.9
    3.1850000000000005
    Justin James
    4.8
    3.2
    Eric Paschall
    4.9
    3.3483333333333336
    Admiral Schofield
    4.2
    2.94
    Jaylen Nowell
    5.5
    3.941666666666667
    Bol Bol
    5.6
    4.1066666666666665
    Isaiah Roby
    5.1
    3.8249999999999997
    Talen Horton-Tucker
    4.8
    3.6799999999999997
    Ignas Brazdeikis
    4.4
    3.4466666666666668
    Terance Mann
    6.7
    5.36
    Quinndary Weatherspoon
    4.8
    3.92
    Jarrell Brantley
    5.1
    4.249999999999999
    Tremont Waters
    4.9
    4.165
    Jalen McDaniels
    4.7
    4.073333333333333
    Justin Wright-Foreman
    4.9
    4.328333333333334
    Marial Shayok
    4.9
    4.41
    Kyle Guy
    4.7
    4.308333333333334
    Jordan Bone
    4.8
    4.56
    Miye Oni
    4.9
    4.736666666666667
    Dewan Hernandez
    4.9
    4.818333333333333
    Anthony Edwards
    7.2
    0.12000000000000001
    James Wiseman
    4.3
    0.14333333333333334
    LaMelo Ball
    9.8
    0.49000000000000005
    Patrick Williams
    4.9
    0.3266666666666667
    Isaac Okoro
    3.3
    0.275
    Onyeka Okongwu
    6.0
    0.6
    Killian Hayes
    3.3
    0.38499999999999995
    Obi Toppin
    6.6
    0.88
    Deni Avdija
    4.6
    0.69
    Jalen Smith
    5.1
    0.85
    Devin Vassell
    6.5
    1.1916666666666667
    Tyrese Haliburton
    11.6
    2.32
    Kira Lewis Jr.
    4.5
    0.975
    Aaron Nesmith
    4.3
    1.0033333333333332
    Cole Anthony
    5.2
    1.3
    Isaiah Stewart
    5.0
    1.3333333333333333
    Aleksej Pokusevski
    3.9
    1.105
    Josh Green
    5.3
    1.5899999999999999
    Saddiq Bey
    7.0
    2.216666666666667
    Precious Achiuwa
    4.2
    1.4
    Tyrese Maxey
    7.2
    2.5200000000000005
    Zeke Nnaji
    4.9
    1.7966666666666669
    Leandro Bolmaro
    4.7
    1.8016666666666667
    R.J. Hampton
    4.0
    1.6
    Immanuel Quickley
    7.2
    3.0
    Payton Pritchard
    6.3
    2.7299999999999995
    Udoka Azubuike
    5.1
    2.295
    Jaden McDaniels
    4.0
    1.8666666666666667
    Malachi Flynn
    5.0
    2.4166666666666665
    Desmond Bane
    8.9
    4.45
    Tyrell Terry
    5.0
    2.5833333333333335
    Vernon Carey Jr.
    4.8
    2.56
    Daniel Oturu
    4.8
    2.64
    Theo Maledon
    3.2
    1.8133333333333335
    Xavier Tillman Sr.
    6.0
    3.5
    Tyler Bey
    4.9
    2.94
    Vit Krejci
    4.4
    2.7133333333333334
    Saben Lee
    5.2
    3.2933333333333334
    Elijah Hughes
    4.5
    2.925
    Robert Woodard II
    4.9
    3.2666666666666666
    Tre Jones
    5.4
    3.69
    Nick Richards
    4.9
    3.43
    Jahmi'us Ramsey
    4.8
    3.44
    Marko Simonovic
    4.9
    3.5933333333333337
    Jordan Nwora
    4.3
    3.225
    CJ Elleby
    3.9
    2.99
    Nico Mannion
    4.8
    3.8399999999999994
    Isaiah Joe
    4.9
    4.001666666666667
    Skylar Mays
    5.3
    4.416666666666667
    Kenyon Martin Jr.
    5.7
    4.94
    Cassius Winston
    4.9
    4.328333333333334
    Cassius Stanley
    4.6
    4.14
    Jay Scrubb
    4.7
    4.308333333333334
    Grant Riller
    5.0
    4.666666666666667
    Reggie Perry
    4.7
    4.465000000000001
    Paul Reed
    5.4
    5.220000000000001
    Jalen Harris
    5.1
    5.015
    Sam Merrill
    5.0
    5.0
    Cade Cunningham
    5.3
    0.08833333333333333
    Jalen Green
    4.5
    0.15
    Evan Mobley
    7.5
    0.375
    Scottie Barnes
    7.3
    0.48666666666666664
    Jalen Suggs
    3.8
    0.31666666666666665
    Josh Giddey
    5.5
    0.55
    Jonathan Kuminga
    4.9
    0.5716666666666668
    Franz Wagner
    6.2
    0.8266666666666667
    Davion Mitchell
    3.9
    0.5850000000000001
    Ziaire Williams
    4.5
    0.75
    James Bouknight
    4.2
    0.77
    Joshua Primo
    4.2
    0.8400000000000001
    Chris Duarte
    4.8
    1.04
    Moses Moody
    4.8
    1.12
    Corey Kispert
    4.9
    1.225
    Alperen Sengun
    5.7
    1.52
    Trey Murphy III
    5.9
    1.6716666666666669
    Tre Mann
    3.8
    1.14
    Kai Jones
    4.8
    1.52
    Jalen Johnson
    4.9
    1.6333333333333333
    Keon Johnson
    4.2
    1.47
    Isaiah Jackson
    5.1
    1.8699999999999999
    Usman Garuba
    5.4
    2.07
    Josh Christopher
    4.4
    1.7600000000000002
    Quentin Grimes
    5.5
    2.2916666666666665
    Bones Hyland
    5.9
    2.5566666666666666
    Cam Thomas
    4.4
    1.9800000000000002
    Jaden Springer
    5.0
    2.3333333333333335
    Day'Ron Sharpe
    4.9
    2.3683333333333336
    Santi Aldama
    5.3
    2.65
    Isaiah Todd
    4.9
    2.5316666666666667
    Jeremiah Robinson-Earl
    5.2
    2.7733333333333334
    Jason Preston
    5.0
    2.75
    Herbert Jones
    6.0
    3.5
    Miles McBride
    4.8
    2.88
    JT Thor
    4.8
    2.96
    Ayo Dosunmu
    5.0
    3.1666666666666665
    Neemias Queta
    4.9
    3.1850000000000005
    Jared Butler
    5.0
    3.3333333333333335
    Joe Wieskamp
    4.9
    3.3483333333333336
    Isaiah Livers
    5.0
    3.5
    Greg Brown III
    4.5
    3.225
    Kessler Edwards
    4.4
    3.226666666666667
    Dalano Banton
    5.0
    3.8333333333333335
    David Johnson
    5.0
    3.9166666666666665
    Sharife Cooper
    4.9
    3.9200000000000004
    Brandon Boston Jr.
    4.7
    3.995
    Luka Garza
    4.9
    4.246666666666667
    Charles Bassey
    5.4
    4.7700000000000005
    Sandro Mamukelashvili
    5.1
    4.59
    Aaron Wiggins
    4.4
    4.033333333333334
    Scottie Lewis
    5.0
    4.666666666666667
    Jericho Sims
    5.2
    5.026666666666667
    Georgios Kalaitzakis
    4.7
    4.7
    


```python
unique_teams2 = []
for x in team:
    if x not in unique_teams2:
        unique_teams2.append(x)
print(unique_teams2)
```

    ['NOP', 'CHO', 'WAS', 'CLE', 'SAC', 'POR', 'GSW', 'TOR', 'DET', 'HOU', 'PHO', 'MIL', 'PHI', 'DAL', 'ORL', 'DEN', 'BOS', 'ATL', 'MEM', 'IND', 'MIA', 'OKC', 'CHI', 'UTA', 'NYK', 'LAC', 'MIN', 'LAL', 'BRK', 'SAS']
    


```python
for i in range(len(unique_teams2)):
    if unique_teams2[i] == 'NOH':
        unique_teams2[i] = 'NOP'  
    if unique_teams2[i] == 'CHA':
        unique_teams2[i] = 'CHO' 
    if unique_teams2[i] == 'CHH':
        unique_teams2[i] = 'CHO' 
    
for i in range(len(team)):
    if team[i] == 'NOH':
        team[i] = 'NOP'
    if team[i] == 'CHA':
        team[i] = 'CHO'
    if team[i] == 'CHH':
        team[i] = 'CHO'
    
unique_teams = []    
for i in unique_teams2:
    if i not in unique_teams:
        unique_teams.append(i)
```


```python
averages = []
for x in unique_teams:
    num = 0
    total = 0
    count = 0
    average = 0
    for y in ratings:
        if x == team[num]:
            total += ratings[num]
            count += 1
        num += 1
    average = total/count
    averages.append(average)
    print(x, average)
    
        
```

    NOP 2.560916666666667
    CHO 2.5221666666666667
    WAS 2.3598484848484853
    CLE 2.1472916666666664
    SAC 2.077
    POR 2.9038888888888885
    GSW 3.584047619047618
    TOR 3.4216666666666664
    DET 3.355583333333333
    HOU 3.3968749999999996
    PHO 1.9931884057971014
    MIL 3.281500000000001
    PHI 2.98517094017094
    DAL 3.141153846153846
    ORL 2.224166666666667
    DEN 5.451052631578947
    BOS 2.7182738095238093
    ATL 2.63875
    MEM 2.263333333333333
    IND 3.090208333333333
    MIA 2.941111111111111
    OKC 2.6890350877192986
    CHI 2.448148148148148
    UTA 3.02840579710145
    NYK 2.56735294117647
    LAC 2.9366666666666665
    MIN 2.342017543859649
    LAL 2.41911111111111
    BRK 3.4734374999999993
    SAS 3.784555555555556
    


```python
tuples = []
for i in range(len(names)):
    thistuple = (names[i], ratings[i], team[i], pick[i], year[i])
    tuples.append(thistuple)
print(tuples)
```

    [('Anthony Davis', 0.8216666666666667, 'NOP', 1, 2012), ('Michael Kidd-Gilchrist', 0.18666666666666665, 'CHO', 2, 2012), ('Bradley Beal', 1.335, 'WAS', 3, 2012), ('Dion Waiters', 0.30666666666666664, 'CLE', 4, 2012), ('Thomas Robinson', 0.2833333333333333, 'SAC', 5, 2012), ('Damian Lillard', 4.989999999999999, 'POR', 6, 2012), ('Harrison Barnes', 1.4466666666666665, 'GSW', 7, 2012), ('Terrence Ross', 1.24, 'TOR', 8, 2012), ('Andre Drummond', 3.4200000000000004, 'DET', 9, 2012), ('Austin Rivers', 0.08333333333333333, 'NOP', 10, 2012), ('Meyers Leonard', 1.1183333333333332, 'POR', 11, 2012), ('Jeremy Lamb', 2.58, 'HOU', 12, 2012), ('Kendall Marshall', 0.845, 'PHO', 13, 2012), ('John Henson', 1.9600000000000002, 'MIL', 14, 2012), ('Maurice Harkless', 2.275, 'PHI', 15, 2012), ('Royce White', 1.3333333333333333, 'HOU', 16, 2012), ('Tyler Zeller', 1.4166666666666667, 'DAL', 17, 2012), ('Terrence Jones', 2.5799999999999996, 'HOU', 18, 2012), ('Andrew Nicholson', 1.0766666666666667, 'ORL', 19, 2012), ('Evan Fournier', 3.2666666666666666, 'DEN', 20, 2012), ('Jared Sullinger', 2.6950000000000003, 'BOS', 21, 2012), ('Fab Melo', 1.7966666666666669, 'BOS', 22, 2012), ('John Jenkins', 1.9549999999999998, 'ATL', 23, 2012), ('Jared Cunningham', 1.7600000000000002, 'CLE', 24, 2012), ('Tony Wroten', 1.625, 'MEM', 25, 2012), ('Miles Plumlee', 2.2533333333333334, 'IND', 26, 2012), ('Arnett Moultrie', 2.205, 'MIA', 27, 2012), ('Perry Jones', 2.0533333333333337, 'OKC', 28, 2012), ('Marquis Teague', 1.9333333333333333, 'CHI', 29, 2012), ('Festus Ezeli', 2.5, 'GSW', 30, 2012), ('Jeff Taylor', 1.8083333333333333, 'CHO', 31, 2012), ('Tomas Satoransky', 3.9466666666666668, 'WAS', 32, 2012), ('Bernard James', 2.75, 'CLE', 33, 2012), ('Jae Crowder', 9.01, 'CLE', 34, 2012), ('Draymond Green', 16.683333333333334, 'GSW', 35, 2012), ('Orlando Johnson', 2.94, 'SAC', 36, 2012), ('Quincy Acy', 3.021666666666667, 'TOR', 37, 2012), ('Quincy Miller', 2.85, 'DEN', 38, 2012), ('Khris Middleton', 12.545, 'DET', 39, 2012), ('Will Barton', 7.933333333333334, 'POR', 40, 2012), ('Tyshawn Taylor', 2.87, 'POR', 41, 2012), ('Doron Lamb', 2.6599999999999997, 'MIL', 42, 2012), ('Mike Scott', 4.013333333333333, 'ATL', 43, 2012), ('Kim English', 3.52, 'DET', 44, 2012), ('Justin Hamilton', 4.125, 'PHI', 45, 2012), ('Darius Miller', 3.5266666666666664, 'NOP', 46, 2012), ('Kevin Murphy', 3.76, 'UTA', 47, 2012), ('Kostas Papanikolaou', 3.8399999999999994, 'NYK', 48, 2012), ("Kyle O'Quinn", 8.166666666666666, 'ORL', 49, 2012), ('Kris Joseph', 4.165, 'BOS', 51, 2012), ('Ognjen Kuzmic', 4.16, 'GSW', 52, 2012), ('Furkan Aldemir', 4.239999999999999, 'LAC', 53, 2012), ('Tornike Shengelia', 4.23, 'PHI', 54, 2012), ('Darius Johnson-Odom', 4.491666666666666, 'DAL', 55, 2012), ('Robbie Hummel', 4.446666666666666, 'MIN', 58, 2012), ('Robert Sacre', 3.6, 'LAL', 60, 2012), ('Anthony Bennett', 0.06166666666666667, 'CLE', 1, 2013), ('Victor Oladipo', 0.5333333333333333, 'ORL', 2, 2013), ('Otto Porter Jr.', 0.8800000000000001, 'WAS', 3, 2013), ('Cody Zeller', 0.6, 'CHO', 4, 2013), ('Alex Len', 0.43333333333333335, 'PHO', 5, 2013), ('Nerlens Noel', 1.25, 'NOP', 6, 2013), ('Ben McLemore', 0.18666666666666668, 'SAC', 7, 2013), ('Kentavious Caldwell-Pope', 1.48, 'DET', 8, 2013), ('Trey Burke', 1.0050000000000001, 'MIN', 9, 2013), ('CJ McCollum', 3.4833333333333334, 'POR', 10, 2013), ('Michael Carter-Williams', 1.2650000000000001, 'PHI', 11, 2013), ('Steven Adams', 3.3200000000000003, 'OKC', 12, 2013), ('Kelly Olynyk', 3.38, 'DAL', 13, 2013), ('Shabazz Muhammad', 1.1666666666666667, 'UTA', 14, 2013), ('Giannis Antetokounmpo', 12.525, 'MIL', 15, 2013), ('Lucas Nogueira', 1.84, 'BOS', 16, 2013), ('Dennis Schroder', 2.295, 'ATL', 17, 2013), ('Shane Larkin', 1.32, 'ATL', 18, 2013), ('Sergey Karasev', 1.4566666666666666, 'CLE', 19, 2013), ('Tony Snell', 1.6333333333333333, 'CHI', 20, 2013), ('Gorgui Dieng', 4.305000000000001, 'UTA', 21, 2013), ('Mason Plumlee', 6.489999999999999, 'BRK', 22, 2013), ('Solomon Hill', 1.8016666666666667, 'IND', 23, 2013), ('Tim Hardaway Jr.', 3.9600000000000004, 'NYK', 24, 2013), ('Reggie Bullock', 3.1666666666666665, 'LAC', 25, 2013), ('Andre Roberson', 3.163333333333333, 'MIN', 26, 2013), ('Rudy Gobert', 14.940000000000001, 'DEN', 27, 2013), ('Archie Goodwin', 2.126666666666667, 'OKC', 29, 2013), ('Nemanja Nedovic', 2.35, 'PHO', 30, 2013), ('Allen Crabbe', 3.0483333333333333, 'CLE', 31, 2013), ('Alex Abrines', 2.7199999999999998, 'OKC', 32, 2013), ('Carrick Felix', 2.75, 'CLE', 33, 2013), ('Isaiah Canaan', 2.55, 'HOU', 34, 2013), ('Glen Rice Jr.', 2.8, 'PHI', 35, 2013), ('Ray McCallum', 2.76, 'SAC', 36, 2013), ('Tony Mitchell', 3.0833333333333335, 'DET', 37, 2013), ('Nate Wolters', 3.04, 'WAS', 38, 2013), ('Jeff Withey', 4.095, 'POR', 39, 2013), ('Grant Jerrett', 3.2666666666666666, 'POR', 40, 2013), ('Jamaal Franklin', 3.28, 'MEM', 41, 2013), ('Pierre Jackson', 3.43, 'PHI', 42, 2013), ('Ricky Ledo', 3.2966666666666664, 'MIL', 43, 2013), ('Mike Muscala', 6.526666666666667, 'DAL', 44, 2013), ('Erick Green', 3.6799999999999997, 'UTA', 46, 2013), ('Raul Neto', 4.465000000000001, 'ATL', 47, 2013), ('Ryan Kelly', 3.6, 'LAL', 48, 2013), ('Erik Murphy', 4.001666666666667, 'CHI', 49, 2013), ('James Ennis III', 4.916666666666667, 'ATL', 50, 2013), ('Lorenzo Brown', 3.9, 'MIN', 52, 2013), ('Joffrey Lauvergne', 4.491666666666666, 'MEM', 55, 2013), ('Peyton Siva', 4.48, 'DET', 56, 2013), ('Andrew Wiggins', 0.13833333333333334, 'CLE', 1, 2014), ('Jabari Parker', 0.25, 'MIL', 2, 2014), ('Joel Embiid', 1.3599999999999999, 'PHI', 3, 2014), ('Aaron Gordon', 0.8733333333333333, 'ORL', 4, 2014), ('Dante Exum', 0.2916666666666667, 'UTA', 5, 2014), ('Marcus Smart', 1.24, 'BOS', 6, 2014), ('Julius Randle', 1.855, 'LAL', 7, 2014), ('Nik Stauskas', 0.44, 'SAC', 8, 2014), ('Noah Vonleh', 0.6449999999999999, 'CHO', 9, 2014), ('Elfrid Payton', 1.45, 'PHI', 10, 2014), ('Doug McDermott', 0.9716666666666666, 'DEN', 11, 2014), ('Dario Saric', 1.5, 'ORL', 12, 2014), ('Zach LaVine', 3.2066666666666666, 'MIN', 13, 2014), ('T.J. Warren', 2.1700000000000004, 'PHO', 14, 2014), ('Adreian Payne', 0.9, 'ATL', 15, 2014), ('Jusuf Nurkic', 3.0933333333333333, 'CHI', 16, 2014), ('James Young', 1.3316666666666668, 'BOS', 17, 2014), ('Tyler Ennis', 1.2600000000000002, 'PHO', 18, 2014), ('Gary Harris', 2.2483333333333335, 'CHI', 19, 2014), ('Bruno Caboclo', 1.6, 'TOR', 20, 2014), ('Mitch McGary', 1.715, 'OKC', 21, 2014), ('Jordan Adams', 1.9066666666666667, 'MEM', 22, 2014), ('Rodney Hood', 2.76, 'UTA', 23, 2014), ('Shabazz Napier', 2.8, 'CHO', 24, 2014), ('Clint Capela', 7.708333333333333, 'HOU', 25, 2014), ('P.J. Hairston', 1.7333333333333334, 'MIA', 26, 2014), ('Bogdan Bogdanovic', 4.77, 'PHO', 27, 2014), ('C.J. Wilcox', 2.24, 'LAC', 28, 2014), ('Josh Huestis', 2.223333333333333, 'OKC', 29, 2014), ('Kyle Anderson', 7.7, 'SAS', 30, 2014), ('Damien Inglis', 2.5316666666666667, 'MIL', 31, 2014), ('K.J. McDaniels', 2.453333333333333, 'PHI', 32, 2014), ('Joe Harris', 4.840000000000001, 'CLE', 33, 2014), ('Cleanthony Early', 2.3800000000000003, 'NYK', 34, 2014), ('Jarnell Stokes', 2.975, 'UTA', 35, 2014), ("Johnny O'Bryant", 1.9200000000000002, 'MIL', 36, 2014), ('Spencer Dinwiddie', 7.6, 'DET', 38, 2014), ('Jerami Grant', 7.6049999999999995, 'PHI', 39, 2014), ('Glenn Robinson III', 3.6, 'MIN', 40, 2014), ('Nikola Jokic', 35.39666666666666, 'DEN', 41, 2014), ('Nick Johnson', 3.29, 'HOU', 42, 2014), ('Edy Tavares', 3.5833333333333335, 'ATL', 43, 2014), ('Markel Brown', 3.373333333333333, 'MIN', 44, 2014), ('Dwight Powell', 9.75, 'CHO', 45, 2014), ('Jordan Clarkson', 8.586666666666666, 'WAS', 46, 2014), ('Russ Smith', 3.8383333333333334, 'PHI', 47, 2014), ('Lamar Patterson', 3.6799999999999997, 'MIL', 48, 2014), ('Cameron Bairstow', 3.8383333333333334, 'CHI', 49, 2014), ('Thanasis Antetokounmpo', 3.825, 'NYK', 51, 2014), ('Semaj Christon', 3.85, 'MIA', 55, 2014), ('Devyn Marble', 4.293333333333333, 'DEN', 56, 2014), ('Jordan McRae', 4.833333333333333, 'SAS', 58, 2014), ('Cory Jefferson', 4.8, 'SAS', 60, 2014), ('Karl-Anthony Towns', 0.5700000000000001, 'MIN', 1, 2015), ("D'Angelo Russell", 0.45, 'LAL', 2, 2015), ('Jahlil Okafor', 0.25, 'PHI', 3, 2015), ('Kristaps Porzingis', 1.0533333333333335, 'NYK', 4, 2015), ('Mario Hezonja', 0.31666666666666665, 'ORL', 5, 2015), ('Willie Cauley-Stein', 0.9400000000000001, 'SAC', 6, 2015), ('Emmanuel Mudiay', 0.3266666666666666, 'DEN', 7, 2015), ('Stanley Johnson', 0.44, 'DET', 8, 2015), ('Frank Kaminsky', 1.2600000000000002, 'CHO', 9, 2015), ('Justise Winslow', 0.8, 'MIA', 10, 2015), ('Myles Turner', 2.585, 'IND', 11, 2015), ('Trey Lyles', 1.3800000000000001, 'UTA', 12, 2015), ('Devin Booker', 3.618333333333333, 'PHO', 13, 2015), ('Cameron Payne', 1.7033333333333334, 'OKC', 14, 2015), ('Kelly Oubre Jr.', 1.475, 'ATL', 15, 2015), ('Terry Rozier', 3.52, 'BOS', 16, 2015), ('Rashad Vaughn', 1.0766666666666667, 'MIL', 17, 2015), ('Sam Dekker', 1.65, 'HOU', 18, 2015), ('Jerian Grant', 1.7416666666666667, 'WAS', 19, 2015), ('Delon Wright', 4.7, 'TOR', 20, 2015), ('Justin Anderson', 1.8900000000000001, 'DAL', 21, 2015), ('Bobby Portis', 3.373333333333333, 'CHI', 22, 2015), ('Rondae Hollis-Jefferson', 2.7983333333333333, 'POR', 23, 2015), ('Tyus Jones', 4.239999999999999, 'CLE', 24, 2015), ('Jarell Martin', 1.375, 'MEM', 25, 2015), ('Larry Nance Jr.', 5.895, 'LAL', 27, 2015), ('R.J. Hunter', 2.3333333333333335, 'BOS', 28, 2015), ('Chris McCullough', 2.3683333333333336, 'BRK', 29, 2015), ('Kevon Looney', 4.2, 'GSW', 30, 2015), ('Cedi Osman', 2.1700000000000004, 'MIN', 31, 2015), ('Montrezl Harrell', 9.120000000000001, 'HOU', 32, 2015), ('Jordan Mickey', 2.585, 'BOS', 33, 2015), ('Anthony Brown', 2.4933333333333336, 'LAL', 34, 2015), ('Willy Hernangomez', 4.375, 'PHI', 35, 2015), ('Rakeem Christmas', 2.88, 'MIN', 36, 2015), ('Richaun Holmes', 6.043333333333334, 'PHI', 37, 2015), ('Darrun Hilliard', 2.786666666666667, 'DET', 38, 2015), ('Josh Richardson', 6.6, 'MIA', 40, 2015), ('Pat Connaughton', 6.013333333333334, 'BRK', 41, 2015), ('Joe Young', 3.1533333333333338, 'IND', 43, 2015), ('Andrew Harrison', 3.226666666666667, 'PHO', 44, 2015), ('Norman Powell', 7.359999999999999, 'MIL', 46, 2015), ('Dakari Johnson', 4.08, 'OKC', 48, 2015), ('Branden Dawson', 4.666666666666667, 'NOP', 56, 2015), ('Ben Simmons', 0.315, 'PHI', 1, 2016), ('Brandon Ingram', 0.35666666666666663, 'LAL', 2, 2016), ('Jaylen Brown', 0.605, 'BOS', 3, 2016), ('Dragan Bender', 0.20666666666666667, 'PHO', 4, 2016), ('Kris Dunn', 0.4, 'MIN', 5, 2016), ('Buddy Hield', 1.2800000000000002, 'NOP', 6, 2016), ('Jamal Murray', 1.3066666666666664, 'DEN', 7, 2016), ('Marquese Chriss', 0.6, 'SAC', 8, 2016), ('Jakob Poeltl', 1.77, 'TOR', 9, 2016), ('Thon Maker', 0.8166666666666667, 'MIL', 10, 2016), ('Domantas Sabonis', 3.3, 'ORL', 11, 2016), ('Taurean Prince', 1.0800000000000003, 'UTA', 12, 2016), ('Georgios Papagiannis', 1.04, 'PHO', 13, 2016), ('Denzel Valentine', 1.2133333333333334, 'CHI', 14, 2016), ('Juancho Hernangomez', 1.325, 'DEN', 15, 2016), ('Guerschon Yabusele', 1.3333333333333333, 'BOS', 16, 2016), ('Wade Baldwin', 1.275, 'MEM', 17, 2016), ('Henry Ellenson', 1.4100000000000001, 'DET', 18, 2016), ('Malik Beasley', 2.375, 'DEN', 19, 2016), ('Caris LeVert', 2.7666666666666666, 'IND', 20, 2016), ("DeAndre' Bembry", 1.6099999999999999, 'ATL', 21, 2016), ('Malachi Richardson', 1.5766666666666667, 'CHO', 22, 2016), ('Ante Zizic', 1.8399999999999999, 'BOS', 23, 2016), ('Timothe Luwawu-Cabarrot', 0.9199999999999999, 'PHI', 24, 2016), ('Brice Johnson', 2.0833333333333335, 'LAC', 25, 2016), ('Furkan Korkmaz', 2.2533333333333334, 'PHI', 26, 2016), ('Pascal Siakam', 7.829999999999999, 'TOR', 27, 2016), ('Skal Labissiere', 2.24, 'PHO', 28, 2016), ('Dejounte Murray', 6.718333333333334, 'SAS', 29, 2016), ('Damian Jones', 2.9, 'GSW', 30, 2016), ('Deyonta Davis', 2.5833333333333335, 'BOS', 31, 2016), ('Ivica Zubac', 5.173333333333333, 'LAL', 32, 2016), ('Cheick Diallo', 2.915, 'LAC', 33, 2016), ('Tyler Ulis', 2.21, 'PHO', 34, 2016), ('Malcolm Brogdon', 8.16, 'MIL', 36, 2016), ('Chinanu Onuaku', 3.021666666666667, 'HOU', 37, 2016), ('Patrick McCaw', 2.786666666666667, 'MIL', 38, 2016), ('Diamond Stone', 3.2666666666666666, 'NOP', 40, 2016), ('Stephen Zimmerman', 3.28, 'ORL', 41, 2016), ('Isaiah Whitehead', 2.5200000000000005, 'UTA', 42, 2016), ('Zhou Qi', 3.44, 'HOU', 43, 2016), ('Demetrius Jackson', 3.8249999999999997, 'BOS', 45, 2016), ('A.J. Hammons', 3.6799999999999997, 'DAL', 46, 2016), ('Jake Layman', 3.76, 'ORL', 47, 2016), ('Paul Zipser', 2.8800000000000003, 'CHI', 48, 2016), ('Michael Gbinije', 4.001666666666667, 'DET', 49, 2016), ('Georges Niang', 5.25, 'IND', 50, 2016), ('Ben Bentil', 4.165, 'BOS', 51, 2016), ('Joel Bolomboy', 4.333333333333333, 'UTA', 52, 2016), ('Petr Cornelie', 4.328333333333334, 'DEN', 53, 2016), ('Kay Felder', 4.14, 'ATL', 54, 2016), ('Marcus Paige', 4.583333333333333, 'BRK', 55, 2016), ('Daniel Hamilton', 4.573333333333334, 'DEN', 56, 2016), ('Abdel Nader', 4.446666666666666, 'BOS', 58, 2016), ('Tyrone Wallace', 3.6, 'UTA', 60, 2016), ('Markelle Fultz', 0.08333333333333333, 'PHI', 1, 2017), ('Lonzo Ball', 0.3766666666666667, 'LAL', 2, 2017), ('Jayson Tatum', 1.0800000000000003, 'BOS', 3, 2017), ('Josh Jackson', 0.12666666666666665, 'PHO', 4, 2017), ("De'Aaron Fox", 0.95, 'SAC', 5, 2017), ('Jonathan Isaac', 0.7, 'ORL', 6, 2017), ('Lauri Markkanen', 1.19, 'MIN', 7, 2017), ('Frank Ntilikina', 0.32, 'NYK', 8, 2017), ('Dennis Smith Jr.', 0.72, 'DAL', 9, 2017), ('Zach Collins', 0.8, 'SAC', 10, 2017), ('Malik Monk', 1.0266666666666666, 'CHO', 11, 2017), ('Luke Kennard', 1.64, 'DET', 12, 2017), ('Donovan Mitchell', 4.42, 'DEN', 13, 2017), ('Bam Adebayo', 4.106666666666667, 'MIA', 14, 2017), ('Justin Jackson', 0.975, 'POR', 15, 2017), ('Justin Patton', 1.3066666666666669, 'CHI', 16, 2017), ('D.J. Wilson', 1.3316666666666668, 'MIL', 17, 2017), ('T.J. Leaf', 1.53, 'IND', 18, 2017), ('John Collins', 3.99, 'ATL', 19, 2017), ('Harry Giles', 1.6, 'POR', 20, 2017), ('Terrance Ferguson', 1.015, 'OKC', 21, 2017), ('Jarrett Allen', 5.243333333333334, 'BRK', 22, 2017), ('OG Anunoby', 3.8333333333333335, 'TOR', 23, 2017), ('Tyler Lydon', 1.9600000000000002, 'UTA', 24, 2017), ('Anzejs Pasecniks', 1.875, 'ORL', 25, 2017), ('Caleb Swanigan', 1.8633333333333333, 'POR', 26, 2017), ('Kyle Kuzma', 3.51, 'BRK', 27, 2017), ('Tony Bradley', 2.8466666666666662, 'LAL', 28, 2017), ('Derrick White', 5.316666666666666, 'SAS', 29, 2017), ('Josh Hart', 4.45, 'UTA', 30, 2017), ('Frank Jackson', 1.6016666666666668, 'CHO', 31, 2017), ('Davon Reed', 2.506666666666667, 'PHO', 32, 2017), ('Wes Iwundu', 1.7600000000000002, 'ORL', 33, 2017), ('Frank Mason III', 2.6633333333333336, 'SAC', 34, 2017), ('Ivan Rabb', 2.975, 'ORL', 35, 2017), ('Jonah Bolden', 3.06, 'PHI', 36, 2017), ('Semi Ojeleye', 2.158333333333333, 'BOS', 37, 2017), ('Jordan Bell', 3.863333333333333, 'CHI', 38, 2017), ('Jawun Evans', 2.795, 'PHI', 39, 2017), ('Dwayne Bacon', 1.2666666666666666, 'NOP', 40, 2017), ('Tyler Dorsey', 3.143333333333333, 'ATL', 41, 2017), ('Thomas Bryant', 5.8100000000000005, 'UTA', 42, 2017), ('Isaiah Hartenstein', 5.375, 'HOU', 43, 2017), ('Damyean Dotson', 3.0066666666666664, 'NYK', 44, 2017), ('Dillon Brooks', 0.9749999999999999, 'HOU', 45, 2017), ('Sterling Brown', 3.756666666666667, 'PHI', 46, 2017), ('Ike Anigbogu', 3.9166666666666665, 'IND', 47, 2017), ('Sindarius Thornwell', 3.6, 'MIL', 48, 2017), ('Vlatko Cancar', 4.083333333333333, 'DEN', 49, 2017), ('Monte Morris', 7.99, 'DEN', 51, 2017), ('Edmond Sumner', 3.9866666666666664, 'NOP', 52, 2017), ('Kadeem Allen', 4.504999999999999, 'BOS', 53, 2017), ('Alec Peters', 4.5, 'PHO', 54, 2017), ('Nigel Williams-Goss', 4.583333333333333, 'UTA', 55, 2017), ('Jabari Bird', 4.666666666666667, 'BOS', 56, 2017), ('Jaron Blossomgame', 4.72, 'SAS', 59, 2017), ('Deandre Ayton', 0.19166666666666668, 'PHO', 1, 2018), ('Marvin Bagley III', 0.16666666666666666, 'SAC', 2, 2018), ('Luka Doncic', 1.3900000000000001, 'ATL', 3, 2018), ('Jaren Jackson Jr.', 0.5533333333333333, 'MEM', 4, 2018), ('Trae Young', 1.4916666666666667, 'DAL', 5, 2018), ('Mo Bamba', 0.7599999999999999, 'ORL', 6, 2018), ('Wendell Carter Jr.', 0.84, 'CHI', 7, 2018), ('Collin Sexton', 0.56, 'CLE', 8, 2018), ('Kevin Knox', 0.345, 'NYK', 9, 2018), ('Mikal Bridges', 2.2333333333333334, 'PHI', 10, 2018), ('Shai Gilgeous-Alexander', 2.658333333333333, 'CHO', 11, 2018), ('Miles Bridges', 1.7600000000000002, 'LAC', 12, 2018), ('Jerome Robinson', 0.845, 'LAC', 13, 2018), ('Michael Porter Jr.', 1.936666666666667, 'DEN', 14, 2018), ('Troy Brown Jr.', 1.2, 'WAS', 15, 2018), ('Zhaire Smith', 1.3066666666666669, 'PHO', 16, 2018), ('Donte DiVincenzo', 2.0683333333333334, 'MIL', 17, 2018), ('Lonnie Walker IV', 1.1700000000000002, 'SAS', 18, 2018), ('Kevin Huerter', 2.185, 'ATL', 19, 2018), ('Josh Okogie', 1.3333333333333333, 'MIN', 20, 2018), ('Grayson Allen', 2.45, 'UTA', 21, 2018), ('Chandler Hutchison', 1.5033333333333332, 'CHI', 22, 2018), ('Aaron Holiday', 1.7633333333333332, 'IND', 23, 2018), ('Anfernee Simons', 2.2, 'POR', 24, 2018), ('Moritz Wagner', 2.25, 'LAL', 25, 2018), ('Landry Shamet', 2.2966666666666664, 'PHI', 26, 2018), ('Robert Williams', 5.085, 'BOS', 27, 2018), ('Jacob Evans', 1.9600000000000002, 'GSW', 28, 2018), ('Dzanan Musa', 2.223333333333333, 'BRK', 29, 2018), ('Omari Spellman', 2.6, 'ATL', 30, 2018), ('Elie Okobo', 2.118333333333333, 'PHO', 31, 2018), ('Jevon Carter', 3.3066666666666666, 'MEM', 32, 2018), ('Jalen Brunson', 5.334999999999999, 'DAL', 33, 2018), ("Devonte' Graham", 4.4766666666666675, 'ATL', 34, 2018), ('Melvin Frazier', 2.566666666666667, 'ORL', 35, 2018), ('Mitchell Robinson', 6.9, 'NYK', 36, 2018), ('Gary Trent Jr.', 4.193333333333333, 'SAC', 37, 2018), ('Khyri Thomas', 3.1033333333333335, 'PHI', 38, 2018), ('Isaac Bonga', 2.795, 'PHI', 39, 2018), ('Rodions Kurucs', 3.066666666666667, 'BRK', 40, 2018), ('Jarred Vanderbilt', 4.988333333333333, 'ORL', 41, 2018), ('Bruce Brown', 4.9, 'DET', 42, 2018), ('Hamidou Diallo', 3.375, 'BRK', 45, 2018), ("De'Anthony Melton", 6.746666666666667, 'HOU', 46, 2018), ('Svi Mykhailiuk', 3.4466666666666668, 'LAL', 47, 2018), ('Keita Bates-Diop', 3.8399999999999994, 'MIN', 48, 2018), ('Chimezie Metu', 4.083333333333333, 'SAS', 49, 2018), ('Alize Johnson', 4.083333333333334, 'IND', 50, 2018), ('Vince Edwards', 4.333333333333333, 'UTA', 52, 2018), ('Devon Hall', 4.328333333333334, 'OKC', 53, 2018), ('Shake Milton', 4.77, 'DAL', 54, 2018), ('Arnoldas Kulboka', 4.583333333333333, 'CHO', 55, 2018), ('Ray Spalding', 4.48, 'PHI', 56, 2018), ('Kevin Hervey', 4.75, 'OKC', 57, 2018), ('Thomas Welsh', 4.833333333333333, 'DEN', 58, 2018), ('George King', 4.818333333333333, 'PHO', 59, 2018), ('Kostas Antetokounmpo', 4.8, 'PHI', 60, 2018), ('Zion Williamson', 0.18666666666666665, 'NOP', 1, 2019), ('Ja Morant', 0.41333333333333333, 'MEM', 2, 2019), ('RJ Barrett', 0.23500000000000001, 'NYK', 3, 2019), ("De'Andre Hunter", 0.20666666666666667, 'LAL', 4, 2019), ('Darius Garland', 0.575, 'CLE', 5, 2019), ('Jarrett Culver', 0.33999999999999997, 'PHO', 6, 2019), ('Coby White', 0.5016666666666666, 'CHI', 7, 2019), ('Jaxson Hayes', 0.8933333333333333, 'ATL', 8, 2019), ('Rui Hachimura', 0.6, 'WAS', 9, 2019), ('Cam Reddish', 0.6666666666666666, 'ATL', 10, 2019), ('Cameron Johnson', 1.6133333333333335, 'MIN', 11, 2019), ('P.J. Washington', 1.3, 'CHO', 12, 2019), ('Tyler Herro', 1.6683333333333334, 'MIA', 13, 2019), ('Romeo Langford', 1.0733333333333333, 'BOS', 14, 2019), ('Sekou Doumbouya', 0.8, 'DET', 15, 2019), ('Chuma Okeke', 1.6266666666666665, 'ORL', 16, 2019), ('Nickeil Alexander-Walker', 1.3033333333333332, 'BRK', 17, 2019), ('Goga Bitadze', 1.62, 'IND', 18, 2019), ('Luka Samanic', 1.4883333333333333, 'SAS', 19, 2019), ('Matisse Thybulle', 2.8, 'BOS', 20, 2019), ('Brandon Clarke', 3.605, 'OKC', 21, 2019), ('Grant Williams', 2.0900000000000003, 'BOS', 22, 2019), ('Darius Bazley', 1.6483333333333332, 'UTA', 23, 2019), ('Ty Jerome', 2.0, 'PHI', 24, 2019), ('Nassir Little', 2.041666666666667, 'POR', 25, 2019), ('Dylan Windler', 2.21, 'CLE', 26, 2019), ('Mfiondu Kabengele', 2.205, 'BRK', 27, 2019), ('Jordan Poole', 2.566666666666667, 'GSW', 28, 2019), ('Keldon Johnson', 2.948333333333333, 'SAS', 29, 2019), ('Kevin Porter Jr.', 2.25, 'MIL', 30, 2019), ('Nic Claxton', 3.461666666666667, 'BRK', 31, 2019), ('KZ Okpala', 2.3466666666666667, 'PHO', 32, 2019), ('Carsen Edwards', 2.475, 'PHI', 33, 2019), ('Bruno Fernando', 2.6066666666666665, 'PHI', 34, 2019), ('Didi Louzada', 2.7416666666666667, 'ATL', 35, 2019), ('Cody Martin', 3.4200000000000004, 'CHO', 36, 2019), ('Deividas Sirvydis', 2.96, 'DAL', 37, 2019), ('Daniel Gafford', 4.75, 'CHI', 38, 2019), ('Alen Smailagic', 3.1850000000000005, 'NOP', 39, 2019), ('Justin James', 3.2, 'SAC', 40, 2019), ('Eric Paschall', 3.3483333333333336, 'GSW', 41, 2019), ('Admiral Schofield', 2.94, 'PHI', 42, 2019), ('Jaylen Nowell', 3.941666666666667, 'MIN', 43, 2019), ('Bol Bol', 4.1066666666666665, 'MIA', 44, 2019), ('Isaiah Roby', 3.8249999999999997, 'DET', 45, 2019), ('Talen Horton-Tucker', 3.6799999999999997, 'ORL', 46, 2019), ('Ignas Brazdeikis', 3.4466666666666668, 'SAC', 47, 2019), ('Terance Mann', 5.36, 'LAC', 48, 2019), ('Quinndary Weatherspoon', 3.92, 'SAS', 49, 2019), ('Jarrell Brantley', 4.249999999999999, 'IND', 50, 2019), ('Tremont Waters', 4.165, 'BOS', 51, 2019), ('Jalen McDaniels', 4.073333333333333, 'CHO', 52, 2019), ('Justin Wright-Foreman', 4.328333333333334, 'UTA', 53, 2019), ('Marial Shayok', 4.41, 'PHI', 54, 2019), ('Kyle Guy', 4.308333333333334, 'NYK', 55, 2019), ('Jordan Bone', 4.56, 'NOP', 57, 2019), ('Miye Oni', 4.736666666666667, 'GSW', 58, 2019), ('Dewan Hernandez', 4.818333333333333, 'TOR', 59, 2019), ('Anthony Edwards', 0.12000000000000001, 'MIN', 1, 2020), ('James Wiseman', 0.14333333333333334, 'GSW', 2, 2020), ('LaMelo Ball', 0.49000000000000005, 'CHO', 3, 2020), ('Patrick Williams', 0.3266666666666667, 'CHI', 4, 2020), ('Isaac Okoro', 0.275, 'CLE', 5, 2020), ('Onyeka Okongwu', 0.6, 'ATL', 6, 2020), ('Killian Hayes', 0.38499999999999995, 'DET', 7, 2020), ('Obi Toppin', 0.88, 'NYK', 8, 2020), ('Deni Avdija', 0.69, 'WAS', 9, 2020), ('Jalen Smith', 0.85, 'PHO', 10, 2020), ('Devin Vassell', 1.1916666666666667, 'SAS', 11, 2020), ('Tyrese Haliburton', 2.32, 'SAC', 12, 2020), ('Kira Lewis Jr.', 0.975, 'NOP', 13, 2020), ('Aaron Nesmith', 1.0033333333333332, 'BOS', 14, 2020), ('Cole Anthony', 1.3, 'ORL', 15, 2020), ('Isaiah Stewart', 1.3333333333333333, 'POR', 16, 2020), ('Aleksej Pokusevski', 1.105, 'MIN', 17, 2020), ('Josh Green', 1.5899999999999999, 'DAL', 18, 2020), ('Saddiq Bey', 2.216666666666667, 'BRK', 19, 2020), ('Precious Achiuwa', 1.4, 'MIA', 20, 2020), ('Tyrese Maxey', 2.5200000000000005, 'PHI', 21, 2020), ('Zeke Nnaji', 1.7966666666666669, 'DEN', 22, 2020), ('Leandro Bolmaro', 1.8016666666666667, 'NYK', 23, 2020), ('R.J. Hampton', 1.6, 'MIL', 24, 2020), ('Immanuel Quickley', 3.0, 'OKC', 25, 2020), ('Payton Pritchard', 2.7299999999999995, 'BOS', 26, 2020), ('Udoka Azubuike', 2.295, 'UTA', 27, 2020), ('Jaden McDaniels', 1.8666666666666667, 'LAL', 28, 2020), ('Malachi Flynn', 2.4166666666666665, 'TOR', 29, 2020), ('Desmond Bane', 4.45, 'BOS', 30, 2020), ('Tyrell Terry', 2.5833333333333335, 'DAL', 31, 2020), ('Vernon Carey Jr.', 2.56, 'CHO', 32, 2020), ('Daniel Oturu', 2.64, 'MIN', 33, 2020), ('Theo Maledon', 1.8133333333333335, 'PHI', 34, 2020), ('Xavier Tillman Sr.', 3.5, 'SAC', 35, 2020), ('Tyler Bey', 2.94, 'PHI', 36, 2020), ('Vit Krejci', 2.7133333333333334, 'WAS', 37, 2020), ('Saben Lee', 3.2933333333333334, 'UTA', 38, 2020), ('Elijah Hughes', 2.925, 'NOP', 39, 2020), ('Robert Woodard II', 3.2666666666666666, 'MEM', 40, 2020), ('Tre Jones', 3.69, 'SAS', 41, 2020), ('Nick Richards', 3.43, 'NOP', 42, 2020), ("Jahmi'us Ramsey", 3.44, 'SAC', 43, 2020), ('Marko Simonovic', 3.5933333333333337, 'CHI', 44, 2020), ('Jordan Nwora', 3.225, 'MIL', 45, 2020), ('CJ Elleby', 2.99, 'POR', 46, 2020), ('Nico Mannion', 3.8399999999999994, 'GSW', 48, 2020), ('Isaiah Joe', 4.001666666666667, 'PHI', 49, 2020), ('Skylar Mays', 4.416666666666667, 'ATL', 50, 2020), ('Kenyon Martin Jr.', 4.94, 'SAC', 52, 2020), ('Cassius Winston', 4.328333333333334, 'OKC', 53, 2020), ('Cassius Stanley', 4.14, 'IND', 54, 2020), ('Jay Scrubb', 4.308333333333334, 'BRK', 55, 2020), ('Grant Riller', 4.666666666666667, 'CHO', 56, 2020), ('Reggie Perry', 4.465000000000001, 'LAC', 57, 2020), ('Paul Reed', 5.220000000000001, 'PHI', 58, 2020), ('Jalen Harris', 5.015, 'TOR', 59, 2020), ('Sam Merrill', 5.0, 'NOP', 60, 2020), ('Cade Cunningham', 0.08833333333333333, 'DET', 1, 2021), ('Jalen Green', 0.15, 'HOU', 2, 2021), ('Evan Mobley', 0.375, 'CLE', 3, 2021), ('Scottie Barnes', 0.48666666666666664, 'TOR', 4, 2021), ('Jalen Suggs', 0.31666666666666665, 'ORL', 5, 2021), ('Josh Giddey', 0.55, 'OKC', 6, 2021), ('Jonathan Kuminga', 0.5716666666666668, 'GSW', 7, 2021), ('Franz Wagner', 0.8266666666666667, 'ORL', 8, 2021), ('Davion Mitchell', 0.5850000000000001, 'SAC', 9, 2021), ('Ziaire Williams', 0.75, 'NOP', 10, 2021), ('James Bouknight', 0.77, 'CHO', 11, 2021), ('Joshua Primo', 0.8400000000000001, 'SAS', 12, 2021), ('Chris Duarte', 1.04, 'IND', 13, 2021), ('Moses Moody', 1.12, 'GSW', 14, 2021), ('Corey Kispert', 1.225, 'WAS', 15, 2021), ('Alperen Sengun', 1.52, 'OKC', 16, 2021), ('Trey Murphy III', 1.6716666666666669, 'MEM', 17, 2021), ('Tre Mann', 1.14, 'OKC', 18, 2021), ('Kai Jones', 1.52, 'NYK', 19, 2021), ('Jalen Johnson', 1.6333333333333333, 'ATL', 20, 2021), ('Keon Johnson', 1.47, 'NYK', 21, 2021), ('Isaiah Jackson', 1.8699999999999999, 'LAL', 22, 2021), ('Usman Garuba', 2.07, 'HOU', 23, 2021), ('Josh Christopher', 1.7600000000000002, 'HOU', 24, 2021), ('Quentin Grimes', 2.2916666666666665, 'LAC', 25, 2021), ('Bones Hyland', 2.5566666666666666, 'DEN', 26, 2021), ('Cam Thomas', 1.9800000000000002, 'BRK', 27, 2021), ('Jaden Springer', 2.3333333333333335, 'PHI', 28, 2021), ("Day'Ron Sharpe", 2.3683333333333336, 'PHO', 29, 2021), ('Santi Aldama', 2.65, 'UTA', 30, 2021), ('Isaiah Todd', 2.5316666666666667, 'MIL', 31, 2021), ('Jeremiah Robinson-Earl', 2.7733333333333334, 'NYK', 32, 2021), ('Jason Preston', 2.75, 'ORL', 33, 2021), ('Herbert Jones', 3.5, 'NOP', 35, 2021), ('Miles McBride', 2.88, 'OKC', 36, 2021), ('JT Thor', 2.96, 'DET', 37, 2021), ('Ayo Dosunmu', 3.1666666666666665, 'CHI', 38, 2021), ('Neemias Queta', 3.1850000000000005, 'SAC', 39, 2021), ('Jared Butler', 3.3333333333333335, 'NOP', 40, 2021), ('Joe Wieskamp', 3.3483333333333336, 'SAS', 41, 2021), ('Isaiah Livers', 3.5, 'DET', 42, 2021), ('Greg Brown III', 3.225, 'NOP', 43, 2021), ('Kessler Edwards', 3.226666666666667, 'BRK', 44, 2021), ('Dalano Banton', 3.8333333333333335, 'TOR', 46, 2021), ('David Johnson', 3.9166666666666665, 'TOR', 47, 2021), ('Sharife Cooper', 3.9200000000000004, 'ATL', 48, 2021), ('Brandon Boston Jr.', 3.995, 'MEM', 51, 2021), ('Luka Garza', 4.246666666666667, 'DET', 52, 2021), ('Charles Bassey', 4.7700000000000005, 'PHI', 53, 2021), ('Sandro Mamukelashvili', 4.59, 'IND', 54, 2021), ('Aaron Wiggins', 4.033333333333334, 'OKC', 55, 2021), ('Scottie Lewis', 4.666666666666667, 'CHO', 56, 2021), ('Jericho Sims', 5.026666666666667, 'NYK', 58, 2021), ('Georgios Kalaitzakis', 4.7, 'IND', 60, 2021)]
    


```python
rawtuples = []
for i in range(len(names)):
    thistuple = (names[i], raw_ratings[i], team[i], pick[i], year[i])
    rawtuples.append(thistuple)
print(rawtuples)
```

    [('Anthony Davis', 49.3, 'NOP', 1, 2012), ('Michael Kidd-Gilchrist', 5.6, 'CHO', 2, 2012), ('Bradley Beal', 26.7, 'WAS', 3, 2012), ('Dion Waiters', 4.6, 'CLE', 4, 2012), ('Thomas Robinson', 3.4, 'SAC', 5, 2012), ('Damian Lillard', 49.9, 'POR', 6, 2012), ('Harrison Barnes', 12.4, 'GSW', 7, 2012), ('Terrence Ross', 9.3, 'TOR', 8, 2012), ('Andre Drummond', 22.8, 'DET', 9, 2012), ('Austin Rivers', 0.5, 'NOP', 10, 2012), ('Meyers Leonard', 6.1, 'POR', 11, 2012), ('Jeremy Lamb', 12.9, 'HOU', 12, 2012), ('Kendall Marshall', 3.9, 'PHO', 13, 2012), ('John Henson', 8.4, 'MIL', 14, 2012), ('Maurice Harkless', 9.1, 'PHI', 15, 2012), ('Royce White', 5.0, 'HOU', 16, 2012), ('Tyler Zeller', 5.0, 'DAL', 17, 2012), ('Terrence Jones', 8.6, 'HOU', 18, 2012), ('Andrew Nicholson', 3.4, 'ORL', 19, 2012), ('Evan Fournier', 9.8, 'DEN', 20, 2012), ('Jared Sullinger', 7.7, 'BOS', 21, 2012), ('Fab Melo', 4.9, 'BOS', 22, 2012), ('John Jenkins', 5.1, 'ATL', 23, 2012), ('Jared Cunningham', 4.4, 'CLE', 24, 2012), ('Tony Wroten', 3.9, 'MEM', 25, 2012), ('Miles Plumlee', 5.2, 'IND', 26, 2012), ('Arnett Moultrie', 4.9, 'MIA', 27, 2012), ('Perry Jones', 4.4, 'OKC', 28, 2012), ('Marquis Teague', 4.0, 'CHI', 29, 2012), ('Festus Ezeli', 5.0, 'GSW', 30, 2012), ('Jeff Taylor', 3.5, 'CHO', 31, 2012), ('Tomas Satoransky', 7.4, 'WAS', 32, 2012), ('Bernard James', 5.0, 'CLE', 33, 2012), ('Jae Crowder', 15.9, 'CLE', 34, 2012), ('Draymond Green', 28.6, 'GSW', 35, 2012), ('Orlando Johnson', 4.9, 'SAC', 36, 2012), ('Quincy Acy', 4.9, 'TOR', 37, 2012), ('Quincy Miller', 4.5, 'DEN', 38, 2012), ('Khris Middleton', 19.3, 'DET', 39, 2012), ('Will Barton', 11.9, 'POR', 40, 2012), ('Tyshawn Taylor', 4.2, 'POR', 41, 2012), ('Doron Lamb', 3.8, 'MIL', 42, 2012), ('Mike Scott', 5.6, 'ATL', 43, 2012), ('Kim English', 4.8, 'DET', 44, 2012), ('Justin Hamilton', 5.5, 'PHI', 45, 2012), ('Darius Miller', 4.6, 'NOP', 46, 2012), ('Kevin Murphy', 4.8, 'UTA', 47, 2012), ('Kostas Papanikolaou', 4.8, 'NYK', 48, 2012), ("Kyle O'Quinn", 10.0, 'ORL', 49, 2012), ('Kris Joseph', 4.9, 'BOS', 51, 2012), ('Ognjen Kuzmic', 4.8, 'GSW', 52, 2012), ('Furkan Aldemir', 4.8, 'LAC', 53, 2012), ('Tornike Shengelia', 4.7, 'PHI', 54, 2012), ('Darius Johnson-Odom', 4.9, 'DAL', 55, 2012), ('Robbie Hummel', 4.6, 'MIN', 58, 2012), ('Robert Sacre', 3.6, 'LAL', 60, 2012), ('Anthony Bennett', 3.7, 'CLE', 1, 2013), ('Victor Oladipo', 16.0, 'ORL', 2, 2013), ('Otto Porter Jr.', 17.6, 'WAS', 3, 2013), ('Cody Zeller', 9.0, 'CHO', 4, 2013), ('Alex Len', 5.2, 'PHO', 5, 2013), ('Nerlens Noel', 12.5, 'NOP', 6, 2013), ('Ben McLemore', 1.6, 'SAC', 7, 2013), ('Kentavious Caldwell-Pope', 11.1, 'DET', 8, 2013), ('Trey Burke', 6.7, 'MIN', 9, 2013), ('CJ McCollum', 20.9, 'POR', 10, 2013), ('Michael Carter-Williams', 6.9, 'PHI', 11, 2013), ('Steven Adams', 16.6, 'OKC', 12, 2013), ('Kelly Olynyk', 15.6, 'DAL', 13, 2013), ('Shabazz Muhammad', 5.0, 'UTA', 14, 2013), ('Giannis Antetokounmpo', 50.1, 'MIL', 15, 2013), ('Lucas Nogueira', 6.9, 'BOS', 16, 2013), ('Dennis Schroder', 8.1, 'ATL', 17, 2013), ('Shane Larkin', 4.4, 'ATL', 18, 2013), ('Sergey Karasev', 4.6, 'CLE', 19, 2013), ('Tony Snell', 4.9, 'CHI', 20, 2013), ('Gorgui Dieng', 12.3, 'UTA', 21, 2013), ('Mason Plumlee', 17.7, 'BRK', 22, 2013), ('Solomon Hill', 4.7, 'IND', 23, 2013), ('Tim Hardaway Jr.', 9.9, 'NYK', 24, 2013), ('Reggie Bullock', 7.6, 'LAC', 25, 2013), ('Andre Roberson', 7.3, 'MIN', 26, 2013), ('Rudy Gobert', 33.2, 'DEN', 27, 2013), ('Archie Goodwin', 4.4, 'OKC', 29, 2013), ('Nemanja Nedovic', 4.7, 'PHO', 30, 2013), ('Allen Crabbe', 5.9, 'CLE', 31, 2013), ('Alex Abrines', 5.1, 'OKC', 32, 2013), ('Carrick Felix', 5.0, 'CLE', 33, 2013), ('Isaiah Canaan', 4.5, 'HOU', 34, 2013), ('Glen Rice Jr.', 4.8, 'PHI', 35, 2013), ('Ray McCallum', 4.6, 'SAC', 36, 2013), ('Tony Mitchell', 5.0, 'DET', 37, 2013), ('Nate Wolters', 4.8, 'WAS', 38, 2013), ('Jeff Withey', 6.3, 'POR', 39, 2013), ('Grant Jerrett', 4.9, 'POR', 40, 2013), ('Jamaal Franklin', 4.8, 'MEM', 41, 2013), ('Pierre Jackson', 4.9, 'PHI', 42, 2013), ('Ricky Ledo', 4.6, 'MIL', 43, 2013), ('Mike Muscala', 8.9, 'DAL', 44, 2013), ('Erick Green', 4.8, 'UTA', 46, 2013), ('Raul Neto', 5.7, 'ATL', 47, 2013), ('Ryan Kelly', 4.5, 'LAL', 48, 2013), ('Erik Murphy', 4.9, 'CHI', 49, 2013), ('James Ennis III', 5.9, 'ATL', 50, 2013), ('Lorenzo Brown', 4.5, 'MIN', 52, 2013), ('Joffrey Lauvergne', 4.9, 'MEM', 55, 2013), ('Peyton Siva', 4.8, 'DET', 56, 2013), ('Andrew Wiggins', 8.3, 'CLE', 1, 2014), ('Jabari Parker', 7.5, 'MIL', 2, 2014), ('Joel Embiid', 27.2, 'PHI', 3, 2014), ('Aaron Gordon', 13.1, 'ORL', 4, 2014), ('Dante Exum', 3.5, 'UTA', 5, 2014), ('Marcus Smart', 12.4, 'BOS', 6, 2014), ('Julius Randle', 15.9, 'LAL', 7, 2014), ('Nik Stauskas', 3.3, 'SAC', 8, 2014), ('Noah Vonleh', 4.3, 'CHO', 9, 2014), ('Elfrid Payton', 8.7, 'PHI', 10, 2014), ('Doug McDermott', 5.3, 'DEN', 11, 2014), ('Dario Saric', 7.5, 'ORL', 12, 2014), ('Zach LaVine', 14.8, 'MIN', 13, 2014), ('T.J. Warren', 9.3, 'PHO', 14, 2014), ('Adreian Payne', 3.6, 'ATL', 15, 2014), ('Jusuf Nurkic', 11.6, 'CHI', 16, 2014), ('James Young', 4.7, 'BOS', 17, 2014), ('Tyler Ennis', 4.2, 'PHO', 18, 2014), ('Gary Harris', 7.1, 'CHI', 19, 2014), ('Bruno Caboclo', 4.8, 'TOR', 20, 2014), ('Mitch McGary', 4.9, 'OKC', 21, 2014), ('Jordan Adams', 5.2, 'MEM', 22, 2014), ('Rodney Hood', 7.2, 'UTA', 23, 2014), ('Shabazz Napier', 7.0, 'CHO', 24, 2014), ('Clint Capela', 18.5, 'HOU', 25, 2014), ('P.J. Hairston', 4.0, 'MIA', 26, 2014), ('Bogdan Bogdanovic', 10.6, 'PHO', 27, 2014), ('C.J. Wilcox', 4.8, 'LAC', 28, 2014), ('Josh Huestis', 4.6, 'OKC', 29, 2014), ('Kyle Anderson', 15.4, 'SAS', 30, 2014), ('Damien Inglis', 4.9, 'MIL', 31, 2014), ('K.J. McDaniels', 4.6, 'PHI', 32, 2014), ('Joe Harris', 8.8, 'CLE', 33, 2014), ('Cleanthony Early', 4.2, 'NYK', 34, 2014), ('Jarnell Stokes', 5.1, 'UTA', 35, 2014), ("Johnny O'Bryant", 3.2, 'MIL', 36, 2014), ('Spencer Dinwiddie', 12.0, 'DET', 38, 2014), ('Jerami Grant', 11.7, 'PHI', 39, 2014), ('Glenn Robinson III', 5.4, 'MIN', 40, 2014), ('Nikola Jokic', 51.8, 'DEN', 41, 2014), ('Nick Johnson', 4.7, 'HOU', 42, 2014), ('Edy Tavares', 5.0, 'ATL', 43, 2014), ('Markel Brown', 4.6, 'MIN', 44, 2014), ('Dwight Powell', 13.0, 'CHO', 45, 2014), ('Jordan Clarkson', 11.2, 'WAS', 46, 2014), ('Russ Smith', 4.9, 'PHI', 47, 2014), ('Lamar Patterson', 4.6, 'MIL', 48, 2014), ('Cameron Bairstow', 4.7, 'CHI', 49, 2014), ('Thanasis Antetokounmpo', 4.5, 'NYK', 51, 2014), ('Semaj Christon', 4.2, 'MIA', 55, 2014), ('Devyn Marble', 4.6, 'DEN', 56, 2014), ('Jordan McRae', 5.0, 'SAS', 58, 2014), ('Cory Jefferson', 4.8, 'SAS', 60, 2014), ('Karl-Anthony Towns', 34.2, 'MIN', 1, 2015), ("D'Angelo Russell", 13.5, 'LAL', 2, 2015), ('Jahlil Okafor', 5.0, 'PHI', 3, 2015), ('Kristaps Porzingis', 15.8, 'NYK', 4, 2015), ('Mario Hezonja', 3.8, 'ORL', 5, 2015), ('Willie Cauley-Stein', 9.4, 'SAC', 6, 2015), ('Emmanuel Mudiay', 2.8, 'DEN', 7, 2015), ('Stanley Johnson', 3.3, 'DET', 8, 2015), ('Frank Kaminsky', 8.4, 'CHO', 9, 2015), ('Justise Winslow', 4.8, 'MIA', 10, 2015), ('Myles Turner', 14.1, 'IND', 11, 2015), ('Trey Lyles', 6.9, 'UTA', 12, 2015), ('Devin Booker', 16.7, 'PHO', 13, 2015), ('Cameron Payne', 7.3, 'OKC', 14, 2015), ('Kelly Oubre Jr.', 5.9, 'ATL', 15, 2015), ('Terry Rozier', 13.2, 'BOS', 16, 2015), ('Rashad Vaughn', 3.8, 'MIL', 17, 2015), ('Sam Dekker', 5.5, 'HOU', 18, 2015), ('Jerian Grant', 5.5, 'WAS', 19, 2015), ('Delon Wright', 14.1, 'TOR', 20, 2015), ('Justin Anderson', 5.4, 'DAL', 21, 2015), ('Bobby Portis', 9.2, 'CHI', 22, 2015), ('Rondae Hollis-Jefferson', 7.3, 'POR', 23, 2015), ('Tyus Jones', 10.6, 'CLE', 24, 2015), ('Jarell Martin', 3.3, 'MEM', 25, 2015), ('Larry Nance Jr.', 13.1, 'LAL', 27, 2015), ('R.J. Hunter', 5.0, 'BOS', 28, 2015), ('Chris McCullough', 4.9, 'BRK', 29, 2015), ('Kevon Looney', 8.4, 'GSW', 30, 2015), ('Cedi Osman', 4.2, 'MIN', 31, 2015), ('Montrezl Harrell', 17.1, 'HOU', 32, 2015), ('Jordan Mickey', 4.7, 'BOS', 33, 2015), ('Anthony Brown', 4.4, 'LAL', 34, 2015), ('Willy Hernangomez', 7.5, 'PHI', 35, 2015), ('Rakeem Christmas', 4.8, 'MIN', 36, 2015), ('Richaun Holmes', 9.8, 'PHI', 37, 2015), ('Darrun Hilliard', 4.4, 'DET', 38, 2015), ('Josh Richardson', 9.9, 'MIA', 40, 2015), ('Pat Connaughton', 8.8, 'BRK', 41, 2015), ('Joe Young', 4.4, 'IND', 43, 2015), ('Andrew Harrison', 4.4, 'PHO', 44, 2015), ('Norman Powell', 9.6, 'MIL', 46, 2015), ('Dakari Johnson', 5.1, 'OKC', 48, 2015), ('Branden Dawson', 5.0, 'NOP', 56, 2015), ('Ben Simmons', 18.9, 'PHI', 1, 2016), ('Brandon Ingram', 10.7, 'LAL', 2, 2016), ('Jaylen Brown', 12.1, 'BOS', 3, 2016), ('Dragan Bender', 3.1, 'PHO', 4, 2016), ('Kris Dunn', 4.8, 'MIN', 5, 2016), ('Buddy Hield', 12.8, 'NOP', 6, 2016), ('Jamal Murray', 11.2, 'DEN', 7, 2016), ('Marquese Chriss', 4.5, 'SAC', 8, 2016), ('Jakob Poeltl', 11.8, 'TOR', 9, 2016), ('Thon Maker', 4.9, 'MIL', 10, 2016), ('Domantas Sabonis', 18.0, 'ORL', 11, 2016), ('Taurean Prince', 5.4, 'UTA', 12, 2016), ('Georgios Papagiannis', 4.8, 'PHO', 13, 2016), ('Denzel Valentine', 5.2, 'CHI', 14, 2016), ('Juancho Hernangomez', 5.3, 'DEN', 15, 2016), ('Guerschon Yabusele', 5.0, 'BOS', 16, 2016), ('Wade Baldwin', 4.5, 'MEM', 17, 2016), ('Henry Ellenson', 4.7, 'DET', 18, 2016), ('Malik Beasley', 7.5, 'DEN', 19, 2016), ('Caris LeVert', 8.3, 'IND', 20, 2016), ("DeAndre' Bembry", 4.6, 'ATL', 21, 2016), ('Malachi Richardson', 4.3, 'CHO', 22, 2016), ('Ante Zizic', 4.8, 'BOS', 23, 2016), ('Timothe Luwawu-Cabarrot', 2.3, 'PHI', 24, 2016), ('Brice Johnson', 5.0, 'LAC', 25, 2016), ('Furkan Korkmaz', 5.2, 'PHI', 26, 2016), ('Pascal Siakam', 17.4, 'TOR', 27, 2016), ('Skal Labissiere', 4.8, 'PHO', 28, 2016), ('Dejounte Murray', 13.9, 'SAS', 29, 2016), ('Damian Jones', 5.8, 'GSW', 30, 2016), ('Deyonta Davis', 5.0, 'BOS', 31, 2016), ('Ivica Zubac', 9.7, 'LAL', 32, 2016), ('Cheick Diallo', 5.3, 'LAC', 33, 2016), ('Tyler Ulis', 3.9, 'PHO', 34, 2016), ('Malcolm Brogdon', 13.6, 'MIL', 36, 2016), ('Chinanu Onuaku', 4.9, 'HOU', 37, 2016), ('Patrick McCaw', 4.4, 'MIL', 38, 2016), ('Diamond Stone', 4.9, 'NOP', 40, 2016), ('Stephen Zimmerman', 4.8, 'ORL', 41, 2016), ('Isaiah Whitehead', 3.6, 'UTA', 42, 2016), ('Zhou Qi', 4.8, 'HOU', 43, 2016), ('Demetrius Jackson', 5.1, 'BOS', 45, 2016), ('A.J. Hammons', 4.8, 'DAL', 46, 2016), ('Jake Layman', 4.8, 'ORL', 47, 2016), ('Paul Zipser', 3.6, 'CHI', 48, 2016), ('Michael Gbinije', 4.9, 'DET', 49, 2016), ('Georges Niang', 6.3, 'IND', 50, 2016), ('Ben Bentil', 4.9, 'BOS', 51, 2016), ('Joel Bolomboy', 5.0, 'UTA', 52, 2016), ('Petr Cornelie', 4.9, 'DEN', 53, 2016), ('Kay Felder', 4.6, 'ATL', 54, 2016), ('Marcus Paige', 5.0, 'BRK', 55, 2016), ('Daniel Hamilton', 4.9, 'DEN', 56, 2016), ('Abdel Nader', 4.6, 'BOS', 58, 2016), ('Tyrone Wallace', 3.6, 'UTA', 60, 2016), ('Markelle Fultz', 5.0, 'PHI', 1, 2017), ('Lonzo Ball', 11.3, 'LAL', 2, 2017), ('Jayson Tatum', 21.6, 'BOS', 3, 2017), ('Josh Jackson', 1.9, 'PHO', 4, 2017), ("De'Aaron Fox", 11.4, 'SAC', 5, 2017), ('Jonathan Isaac', 7.0, 'ORL', 6, 2017), ('Lauri Markkanen', 10.2, 'MIN', 7, 2017), ('Frank Ntilikina', 2.4, 'NYK', 8, 2017), ('Dennis Smith Jr.', 4.8, 'DAL', 9, 2017), ('Zach Collins', 4.8, 'SAC', 10, 2017), ('Malik Monk', 5.6, 'CHO', 11, 2017), ('Luke Kennard', 8.2, 'DET', 12, 2017), ('Donovan Mitchell', 20.4, 'DEN', 13, 2017), ('Bam Adebayo', 17.6, 'MIA', 14, 2017), ('Justin Jackson', 3.9, 'POR', 15, 2017), ('Justin Patton', 4.9, 'CHI', 16, 2017), ('D.J. Wilson', 4.7, 'MIL', 17, 2017), ('T.J. Leaf', 5.1, 'IND', 18, 2017), ('John Collins', 12.6, 'ATL', 19, 2017), ('Harry Giles', 4.8, 'POR', 20, 2017), ('Terrance Ferguson', 2.9, 'OKC', 21, 2017), ('Jarrett Allen', 14.3, 'BRK', 22, 2017), ('OG Anunoby', 10.0, 'TOR', 23, 2017), ('Tyler Lydon', 4.9, 'UTA', 24, 2017), ('Anzejs Pasecniks', 4.5, 'ORL', 25, 2017), ('Caleb Swanigan', 4.3, 'POR', 26, 2017), ('Kyle Kuzma', 7.8, 'BRK', 27, 2017), ('Tony Bradley', 6.1, 'LAL', 28, 2017), ('Derrick White', 11.0, 'SAS', 29, 2017), ('Josh Hart', 8.9, 'UTA', 30, 2017), ('Frank Jackson', 3.1, 'CHO', 31, 2017), ('Davon Reed', 4.7, 'PHO', 32, 2017), ('Wes Iwundu', 3.2, 'ORL', 33, 2017), ('Frank Mason III', 4.7, 'SAC', 34, 2017), ('Ivan Rabb', 5.1, 'ORL', 35, 2017), ('Jonah Bolden', 5.1, 'PHI', 36, 2017), ('Semi Ojeleye', 3.5, 'BOS', 37, 2017), ('Jordan Bell', 6.1, 'CHI', 38, 2017), ('Jawun Evans', 4.3, 'PHI', 39, 2017), ('Dwayne Bacon', 1.9, 'NOP', 40, 2017), ('Tyler Dorsey', 4.6, 'ATL', 41, 2017), ('Thomas Bryant', 8.3, 'UTA', 42, 2017), ('Isaiah Hartenstein', 7.5, 'HOU', 43, 2017), ('Damyean Dotson', 4.1, 'NYK', 44, 2017), ('Dillon Brooks', 1.2999999999999998, 'HOU', 45, 2017), ('Sterling Brown', 4.9, 'PHI', 46, 2017), ('Ike Anigbogu', 5.0, 'IND', 47, 2017), ('Sindarius Thornwell', 4.5, 'MIL', 48, 2017), ('Vlatko Cancar', 5.0, 'DEN', 49, 2017), ('Monte Morris', 9.4, 'DEN', 51, 2017), ('Edmond Sumner', 4.6, 'NOP', 52, 2017), ('Kadeem Allen', 5.1, 'BOS', 53, 2017), ('Alec Peters', 5.0, 'PHO', 54, 2017), ('Nigel Williams-Goss', 5.0, 'UTA', 55, 2017), ('Jabari Bird', 5.0, 'BOS', 56, 2017), ('Jaron Blossomgame', 4.8, 'SAS', 59, 2017), ('Deandre Ayton', 11.5, 'PHO', 1, 2018), ('Marvin Bagley III', 5.0, 'SAC', 2, 2018), ('Luka Doncic', 27.8, 'ATL', 3, 2018), ('Jaren Jackson Jr.', 8.3, 'MEM', 4, 2018), ('Trae Young', 17.9, 'DAL', 5, 2018), ('Mo Bamba', 7.6, 'ORL', 6, 2018), ('Wendell Carter Jr.', 7.2, 'CHI', 7, 2018), ('Collin Sexton', 4.2, 'CLE', 8, 2018), ('Kevin Knox', 2.3, 'NYK', 9, 2018), ('Mikal Bridges', 13.4, 'PHI', 10, 2018), ('Shai Gilgeous-Alexander', 14.5, 'CHO', 11, 2018), ('Miles Bridges', 8.8, 'LAC', 12, 2018), ('Jerome Robinson', 3.9, 'LAC', 13, 2018), ('Michael Porter Jr.', 8.3, 'DEN', 14, 2018), ('Troy Brown Jr.', 4.8, 'WAS', 15, 2018), ('Zhaire Smith', 4.9, 'PHO', 16, 2018), ('Donte DiVincenzo', 7.3, 'MIL', 17, 2018), ('Lonnie Walker IV', 3.9, 'SAS', 18, 2018), ('Kevin Huerter', 6.9, 'ATL', 19, 2018), ('Josh Okogie', 4.0, 'MIN', 20, 2018), ('Grayson Allen', 7.0, 'UTA', 21, 2018), ('Chandler Hutchison', 4.1, 'CHI', 22, 2018), ('Aaron Holiday', 4.6, 'IND', 23, 2018), ('Anfernee Simons', 5.5, 'POR', 24, 2018), ('Moritz Wagner', 5.4, 'LAL', 25, 2018), ('Landry Shamet', 5.3, 'PHI', 26, 2018), ('Robert Williams', 11.3, 'BOS', 27, 2018), ('Jacob Evans', 4.2, 'GSW', 28, 2018), ('Dzanan Musa', 4.6, 'BRK', 29, 2018), ('Omari Spellman', 5.2, 'ATL', 30, 2018), ('Elie Okobo', 4.1, 'PHO', 31, 2018), ('Jevon Carter', 6.2, 'MEM', 32, 2018), ('Jalen Brunson', 9.7, 'DAL', 33, 2018), ("Devonte' Graham", 7.9, 'ATL', 34, 2018), ('Melvin Frazier', 4.4, 'ORL', 35, 2018), ('Mitchell Robinson', 11.5, 'NYK', 36, 2018), ('Gary Trent Jr.', 6.8, 'SAC', 37, 2018), ('Khyri Thomas', 4.9, 'PHI', 38, 2018), ('Isaac Bonga', 4.3, 'PHI', 39, 2018), ('Rodions Kurucs', 4.6, 'BRK', 40, 2018), ('Jarred Vanderbilt', 7.3, 'ORL', 41, 2018), ('Bruce Brown', 7.0, 'DET', 42, 2018), ('Hamidou Diallo', 4.5, 'BRK', 45, 2018), ("De'Anthony Melton", 8.8, 'HOU', 46, 2018), ('Svi Mykhailiuk', 4.4, 'LAL', 47, 2018), ('Keita Bates-Diop', 4.8, 'MIN', 48, 2018), ('Chimezie Metu', 5.0, 'SAS', 49, 2018), ('Alize Johnson', 4.9, 'IND', 50, 2018), ('Vince Edwards', 5.0, 'UTA', 52, 2018), ('Devon Hall', 4.9, 'OKC', 53, 2018), ('Shake Milton', 5.3, 'DAL', 54, 2018), ('Arnoldas Kulboka', 5.0, 'CHO', 55, 2018), ('Ray Spalding', 4.8, 'PHI', 56, 2018), ('Kevin Hervey', 5.0, 'OKC', 57, 2018), ('Thomas Welsh', 5.0, 'DEN', 58, 2018), ('George King', 4.9, 'PHO', 59, 2018), ('Kostas Antetokounmpo', 4.8, 'PHI', 60, 2018), ('Zion Williamson', 11.2, 'NOP', 1, 2019), ('Ja Morant', 12.4, 'MEM', 2, 2019), ('RJ Barrett', 4.7, 'NYK', 3, 2019), ("De'Andre Hunter", 3.1, 'LAL', 4, 2019), ('Darius Garland', 6.9, 'CLE', 5, 2019), ('Jarrett Culver', 3.4, 'PHO', 6, 2019), ('Coby White', 4.3, 'CHI', 7, 2019), ('Jaxson Hayes', 6.7, 'ATL', 8, 2019), ('Rui Hachimura', 4.0, 'WAS', 9, 2019), ('Cam Reddish', 4.0, 'ATL', 10, 2019), ('Cameron Johnson', 8.8, 'MIN', 11, 2019), ('P.J. Washington', 6.5, 'CHO', 12, 2019), ('Tyler Herro', 7.7, 'MIA', 13, 2019), ('Romeo Langford', 4.6, 'BOS', 14, 2019), ('Sekou Doumbouya', 3.2, 'DET', 15, 2019), ('Chuma Okeke', 6.1, 'ORL', 16, 2019), ('Nickeil Alexander-Walker', 4.6, 'BRK', 17, 2019), ('Goga Bitadze', 5.4, 'IND', 18, 2019), ('Luka Samanic', 4.7, 'SAS', 19, 2019), ('Matisse Thybulle', 8.4, 'BOS', 20, 2019), ('Brandon Clarke', 10.3, 'OKC', 21, 2019), ('Grant Williams', 5.7, 'BOS', 22, 2019), ('Darius Bazley', 4.3, 'UTA', 23, 2019), ('Ty Jerome', 5.0, 'PHI', 24, 2019), ('Nassir Little', 4.9, 'POR', 25, 2019), ('Dylan Windler', 5.1, 'CLE', 26, 2019), ('Mfiondu Kabengele', 4.9, 'BRK', 27, 2019), ('Jordan Poole', 5.5, 'GSW', 28, 2019), ('Keldon Johnson', 6.1, 'SAS', 29, 2019), ('Kevin Porter Jr.', 4.5, 'MIL', 30, 2019), ('Nic Claxton', 6.7, 'BRK', 31, 2019), ('KZ Okpala', 4.4, 'PHO', 32, 2019), ('Carsen Edwards', 4.5, 'PHI', 33, 2019), ('Bruno Fernando', 4.6, 'PHI', 34, 2019), ('Didi Louzada', 4.7, 'ATL', 35, 2019), ('Cody Martin', 5.7, 'CHO', 36, 2019), ('Deividas Sirvydis', 4.8, 'DAL', 37, 2019), ('Daniel Gafford', 7.5, 'CHI', 38, 2019), ('Alen Smailagic', 4.9, 'NOP', 39, 2019), ('Justin James', 4.8, 'SAC', 40, 2019), ('Eric Paschall', 4.9, 'GSW', 41, 2019), ('Admiral Schofield', 4.2, 'PHI', 42, 2019), ('Jaylen Nowell', 5.5, 'MIN', 43, 2019), ('Bol Bol', 5.6, 'MIA', 44, 2019), ('Isaiah Roby', 5.1, 'DET', 45, 2019), ('Talen Horton-Tucker', 4.8, 'ORL', 46, 2019), ('Ignas Brazdeikis', 4.4, 'SAC', 47, 2019), ('Terance Mann', 6.7, 'LAC', 48, 2019), ('Quinndary Weatherspoon', 4.8, 'SAS', 49, 2019), ('Jarrell Brantley', 5.1, 'IND', 50, 2019), ('Tremont Waters', 4.9, 'BOS', 51, 2019), ('Jalen McDaniels', 4.7, 'CHO', 52, 2019), ('Justin Wright-Foreman', 4.9, 'UTA', 53, 2019), ('Marial Shayok', 4.9, 'PHI', 54, 2019), ('Kyle Guy', 4.7, 'NYK', 55, 2019), ('Jordan Bone', 4.8, 'NOP', 57, 2019), ('Miye Oni', 4.9, 'GSW', 58, 2019), ('Dewan Hernandez', 4.9, 'TOR', 59, 2019), ('Anthony Edwards', 7.2, 'MIN', 1, 2020), ('James Wiseman', 4.3, 'GSW', 2, 2020), ('LaMelo Ball', 9.8, 'CHO', 3, 2020), ('Patrick Williams', 4.9, 'CHI', 4, 2020), ('Isaac Okoro', 3.3, 'CLE', 5, 2020), ('Onyeka Okongwu', 6.0, 'ATL', 6, 2020), ('Killian Hayes', 3.3, 'DET', 7, 2020), ('Obi Toppin', 6.6, 'NYK', 8, 2020), ('Deni Avdija', 4.6, 'WAS', 9, 2020), ('Jalen Smith', 5.1, 'PHO', 10, 2020), ('Devin Vassell', 6.5, 'SAS', 11, 2020), ('Tyrese Haliburton', 11.6, 'SAC', 12, 2020), ('Kira Lewis Jr.', 4.5, 'NOP', 13, 2020), ('Aaron Nesmith', 4.3, 'BOS', 14, 2020), ('Cole Anthony', 5.2, 'ORL', 15, 2020), ('Isaiah Stewart', 5.0, 'POR', 16, 2020), ('Aleksej Pokusevski', 3.9, 'MIN', 17, 2020), ('Josh Green', 5.3, 'DAL', 18, 2020), ('Saddiq Bey', 7.0, 'BRK', 19, 2020), ('Precious Achiuwa', 4.2, 'MIA', 20, 2020), ('Tyrese Maxey', 7.2, 'PHI', 21, 2020), ('Zeke Nnaji', 4.9, 'DEN', 22, 2020), ('Leandro Bolmaro', 4.7, 'NYK', 23, 2020), ('R.J. Hampton', 4.0, 'MIL', 24, 2020), ('Immanuel Quickley', 7.2, 'OKC', 25, 2020), ('Payton Pritchard', 6.3, 'BOS', 26, 2020), ('Udoka Azubuike', 5.1, 'UTA', 27, 2020), ('Jaden McDaniels', 4.0, 'LAL', 28, 2020), ('Malachi Flynn', 5.0, 'TOR', 29, 2020), ('Desmond Bane', 8.9, 'BOS', 30, 2020), ('Tyrell Terry', 5.0, 'DAL', 31, 2020), ('Vernon Carey Jr.', 4.8, 'CHO', 32, 2020), ('Daniel Oturu', 4.8, 'MIN', 33, 2020), ('Theo Maledon', 3.2, 'PHI', 34, 2020), ('Xavier Tillman Sr.', 6.0, 'SAC', 35, 2020), ('Tyler Bey', 4.9, 'PHI', 36, 2020), ('Vit Krejci', 4.4, 'WAS', 37, 2020), ('Saben Lee', 5.2, 'UTA', 38, 2020), ('Elijah Hughes', 4.5, 'NOP', 39, 2020), ('Robert Woodard II', 4.9, 'MEM', 40, 2020), ('Tre Jones', 5.4, 'SAS', 41, 2020), ('Nick Richards', 4.9, 'NOP', 42, 2020), ("Jahmi'us Ramsey", 4.8, 'SAC', 43, 2020), ('Marko Simonovic', 4.9, 'CHI', 44, 2020), ('Jordan Nwora', 4.3, 'MIL', 45, 2020), ('CJ Elleby', 3.9, 'POR', 46, 2020), ('Nico Mannion', 4.8, 'GSW', 48, 2020), ('Isaiah Joe', 4.9, 'PHI', 49, 2020), ('Skylar Mays', 5.3, 'ATL', 50, 2020), ('Kenyon Martin Jr.', 5.7, 'SAC', 52, 2020), ('Cassius Winston', 4.9, 'OKC', 53, 2020), ('Cassius Stanley', 4.6, 'IND', 54, 2020), ('Jay Scrubb', 4.7, 'BRK', 55, 2020), ('Grant Riller', 5.0, 'CHO', 56, 2020), ('Reggie Perry', 4.7, 'LAC', 57, 2020), ('Paul Reed', 5.4, 'PHI', 58, 2020), ('Jalen Harris', 5.1, 'TOR', 59, 2020), ('Sam Merrill', 5.0, 'NOP', 60, 2020), ('Cade Cunningham', 5.3, 'DET', 1, 2021), ('Jalen Green', 4.5, 'HOU', 2, 2021), ('Evan Mobley', 7.5, 'CLE', 3, 2021), ('Scottie Barnes', 7.3, 'TOR', 4, 2021), ('Jalen Suggs', 3.8, 'ORL', 5, 2021), ('Josh Giddey', 5.5, 'OKC', 6, 2021), ('Jonathan Kuminga', 4.9, 'GSW', 7, 2021), ('Franz Wagner', 6.2, 'ORL', 8, 2021), ('Davion Mitchell', 3.9, 'SAC', 9, 2021), ('Ziaire Williams', 4.5, 'NOP', 10, 2021), ('James Bouknight', 4.2, 'CHO', 11, 2021), ('Joshua Primo', 4.2, 'SAS', 12, 2021), ('Chris Duarte', 4.8, 'IND', 13, 2021), ('Moses Moody', 4.8, 'GSW', 14, 2021), ('Corey Kispert', 4.9, 'WAS', 15, 2021), ('Alperen Sengun', 5.7, 'OKC', 16, 2021), ('Trey Murphy III', 5.9, 'MEM', 17, 2021), ('Tre Mann', 3.8, 'OKC', 18, 2021), ('Kai Jones', 4.8, 'NYK', 19, 2021), ('Jalen Johnson', 4.9, 'ATL', 20, 2021), ('Keon Johnson', 4.2, 'NYK', 21, 2021), ('Isaiah Jackson', 5.1, 'LAL', 22, 2021), ('Usman Garuba', 5.4, 'HOU', 23, 2021), ('Josh Christopher', 4.4, 'HOU', 24, 2021), ('Quentin Grimes', 5.5, 'LAC', 25, 2021), ('Bones Hyland', 5.9, 'DEN', 26, 2021), ('Cam Thomas', 4.4, 'BRK', 27, 2021), ('Jaden Springer', 5.0, 'PHI', 28, 2021), ("Day'Ron Sharpe", 4.9, 'PHO', 29, 2021), ('Santi Aldama', 5.3, 'UTA', 30, 2021), ('Isaiah Todd', 4.9, 'MIL', 31, 2021), ('Jeremiah Robinson-Earl', 5.2, 'NYK', 32, 2021), ('Jason Preston', 5.0, 'ORL', 33, 2021), ('Herbert Jones', 6.0, 'NOP', 35, 2021), ('Miles McBride', 4.8, 'OKC', 36, 2021), ('JT Thor', 4.8, 'DET', 37, 2021), ('Ayo Dosunmu', 5.0, 'CHI', 38, 2021), ('Neemias Queta', 4.9, 'SAC', 39, 2021), ('Jared Butler', 5.0, 'NOP', 40, 2021), ('Joe Wieskamp', 4.9, 'SAS', 41, 2021), ('Isaiah Livers', 5.0, 'DET', 42, 2021), ('Greg Brown III', 4.5, 'NOP', 43, 2021), ('Kessler Edwards', 4.4, 'BRK', 44, 2021), ('Dalano Banton', 5.0, 'TOR', 46, 2021), ('David Johnson', 5.0, 'TOR', 47, 2021), ('Sharife Cooper', 4.9, 'ATL', 48, 2021), ('Brandon Boston Jr.', 4.7, 'MEM', 51, 2021), ('Luka Garza', 4.9, 'DET', 52, 2021), ('Charles Bassey', 5.4, 'PHI', 53, 2021), ('Sandro Mamukelashvili', 5.1, 'IND', 54, 2021), ('Aaron Wiggins', 4.4, 'OKC', 55, 2021), ('Scottie Lewis', 5.0, 'CHO', 56, 2021), ('Jericho Sims', 5.2, 'NYK', 58, 2021), ('Georgios Kalaitzakis', 4.7, 'IND', 60, 2021)]
    


```python
team_tuples = []
for i in range(len(unique_teams)):
    print(unique_teams[i])
    print(averages[i])
    thistuple = (unique_teams[i], averages[i])
    team_tuples.append(thistuple)
print(team_tuples)
```

    NOP
    2.560916666666667
    CHO
    2.5221666666666667
    WAS
    2.3598484848484853
    CLE
    2.1472916666666664
    SAC
    2.077
    POR
    2.9038888888888885
    GSW
    3.584047619047618
    TOR
    3.4216666666666664
    DET
    3.355583333333333
    HOU
    3.3968749999999996
    PHO
    1.9931884057971014
    MIL
    3.281500000000001
    PHI
    2.98517094017094
    DAL
    3.141153846153846
    ORL
    2.224166666666667
    DEN
    5.451052631578947
    BOS
    2.7182738095238093
    ATL
    2.63875
    MEM
    2.263333333333333
    IND
    3.090208333333333
    MIA
    2.941111111111111
    OKC
    2.6890350877192986
    CHI
    2.448148148148148
    UTA
    3.02840579710145
    NYK
    2.56735294117647
    LAC
    2.9366666666666665
    MIN
    2.342017543859649
    LAL
    2.41911111111111
    BRK
    3.4734374999999993
    SAS
    3.784555555555556
    [('NOP', 2.560916666666667), ('CHO', 2.5221666666666667), ('WAS', 2.3598484848484853), ('CLE', 2.1472916666666664), ('SAC', 2.077), ('POR', 2.9038888888888885), ('GSW', 3.584047619047618), ('TOR', 3.4216666666666664), ('DET', 3.355583333333333), ('HOU', 3.3968749999999996), ('PHO', 1.9931884057971014), ('MIL', 3.281500000000001), ('PHI', 2.98517094017094), ('DAL', 3.141153846153846), ('ORL', 2.224166666666667), ('DEN', 5.451052631578947), ('BOS', 2.7182738095238093), ('ATL', 2.63875), ('MEM', 2.263333333333333), ('IND', 3.090208333333333), ('MIA', 2.941111111111111), ('OKC', 2.6890350877192986), ('CHI', 2.448148148148148), ('UTA', 3.02840579710145), ('NYK', 2.56735294117647), ('LAC', 2.9366666666666665), ('MIN', 2.342017543859649), ('LAL', 2.41911111111111), ('BRK', 3.4734374999999993), ('SAS', 3.784555555555556)]
    


```python
sorted_by_average = sorted(team_tuples, key=lambda tup: tup[1])
print(sorted_by_average)
```

    [('PHO', 1.9931884057971014), ('SAC', 2.077), ('CLE', 2.1472916666666664), ('ORL', 2.224166666666667), ('MEM', 2.263333333333333), ('MIN', 2.342017543859649), ('WAS', 2.3598484848484853), ('LAL', 2.41911111111111), ('CHI', 2.448148148148148), ('CHO', 2.5221666666666667), ('NOP', 2.560916666666667), ('NYK', 2.56735294117647), ('ATL', 2.63875), ('OKC', 2.6890350877192986), ('BOS', 2.7182738095238093), ('POR', 2.9038888888888885), ('LAC', 2.9366666666666665), ('MIA', 2.941111111111111), ('PHI', 2.98517094017094), ('UTA', 3.02840579710145), ('IND', 3.090208333333333), ('DAL', 3.141153846153846), ('MIL', 3.281500000000001), ('DET', 3.355583333333333), ('HOU', 3.3968749999999996), ('TOR', 3.4216666666666664), ('BRK', 3.4734374999999993), ('GSW', 3.584047619047618), ('SAS', 3.784555555555556), ('DEN', 5.451052631578947)]
    


```python
sorted_by_rating = sorted(tuples, key=lambda tup: tup[1])
print(sorted_by_rating)
```

    [('Anthony Bennett', 0.06166666666666667, 'CLE', 1, 2013), ('Austin Rivers', 0.08333333333333333, 'NOP', 10, 2012), ('Markelle Fultz', 0.08333333333333333, 'PHI', 1, 2017), ('Cade Cunningham', 0.08833333333333333, 'DET', 1, 2021), ('Anthony Edwards', 0.12000000000000001, 'MIN', 1, 2020), ('Josh Jackson', 0.12666666666666665, 'PHO', 4, 2017), ('Andrew Wiggins', 0.13833333333333334, 'CLE', 1, 2014), ('James Wiseman', 0.14333333333333334, 'GSW', 2, 2020), ('Jalen Green', 0.15, 'HOU', 2, 2021), ('Marvin Bagley III', 0.16666666666666666, 'SAC', 2, 2018), ('Michael Kidd-Gilchrist', 0.18666666666666665, 'CHO', 2, 2012), ('Zion Williamson', 0.18666666666666665, 'NOP', 1, 2019), ('Ben McLemore', 0.18666666666666668, 'SAC', 7, 2013), ('Deandre Ayton', 0.19166666666666668, 'PHO', 1, 2018), ('Dragan Bender', 0.20666666666666667, 'PHO', 4, 2016), ("De'Andre Hunter", 0.20666666666666667, 'LAL', 4, 2019), ('RJ Barrett', 0.23500000000000001, 'NYK', 3, 2019), ('Jabari Parker', 0.25, 'MIL', 2, 2014), ('Jahlil Okafor', 0.25, 'PHI', 3, 2015), ('Isaac Okoro', 0.275, 'CLE', 5, 2020), ('Thomas Robinson', 0.2833333333333333, 'SAC', 5, 2012), ('Dante Exum', 0.2916666666666667, 'UTA', 5, 2014), ('Dion Waiters', 0.30666666666666664, 'CLE', 4, 2012), ('Ben Simmons', 0.315, 'PHI', 1, 2016), ('Mario Hezonja', 0.31666666666666665, 'ORL', 5, 2015), ('Jalen Suggs', 0.31666666666666665, 'ORL', 5, 2021), ('Frank Ntilikina', 0.32, 'NYK', 8, 2017), ('Emmanuel Mudiay', 0.3266666666666666, 'DEN', 7, 2015), ('Patrick Williams', 0.3266666666666667, 'CHI', 4, 2020), ('Jarrett Culver', 0.33999999999999997, 'PHO', 6, 2019), ('Kevin Knox', 0.345, 'NYK', 9, 2018), ('Brandon Ingram', 0.35666666666666663, 'LAL', 2, 2016), ('Evan Mobley', 0.375, 'CLE', 3, 2021), ('Lonzo Ball', 0.3766666666666667, 'LAL', 2, 2017), ('Killian Hayes', 0.38499999999999995, 'DET', 7, 2020), ('Kris Dunn', 0.4, 'MIN', 5, 2016), ('Ja Morant', 0.41333333333333333, 'MEM', 2, 2019), ('Alex Len', 0.43333333333333335, 'PHO', 5, 2013), ('Nik Stauskas', 0.44, 'SAC', 8, 2014), ('Stanley Johnson', 0.44, 'DET', 8, 2015), ("D'Angelo Russell", 0.45, 'LAL', 2, 2015), ('Scottie Barnes', 0.48666666666666664, 'TOR', 4, 2021), ('LaMelo Ball', 0.49000000000000005, 'CHO', 3, 2020), ('Coby White', 0.5016666666666666, 'CHI', 7, 2019), ('Victor Oladipo', 0.5333333333333333, 'ORL', 2, 2013), ('Josh Giddey', 0.55, 'OKC', 6, 2021), ('Jaren Jackson Jr.', 0.5533333333333333, 'MEM', 4, 2018), ('Collin Sexton', 0.56, 'CLE', 8, 2018), ('Karl-Anthony Towns', 0.5700000000000001, 'MIN', 1, 2015), ('Jonathan Kuminga', 0.5716666666666668, 'GSW', 7, 2021), ('Darius Garland', 0.575, 'CLE', 5, 2019), ('Davion Mitchell', 0.5850000000000001, 'SAC', 9, 2021), ('Cody Zeller', 0.6, 'CHO', 4, 2013), ('Marquese Chriss', 0.6, 'SAC', 8, 2016), ('Rui Hachimura', 0.6, 'WAS', 9, 2019), ('Onyeka Okongwu', 0.6, 'ATL', 6, 2020), ('Jaylen Brown', 0.605, 'BOS', 3, 2016), ('Noah Vonleh', 0.6449999999999999, 'CHO', 9, 2014), ('Cam Reddish', 0.6666666666666666, 'ATL', 10, 2019), ('Deni Avdija', 0.69, 'WAS', 9, 2020), ('Jonathan Isaac', 0.7, 'ORL', 6, 2017), ('Dennis Smith Jr.', 0.72, 'DAL', 9, 2017), ('Ziaire Williams', 0.75, 'NOP', 10, 2021), ('Mo Bamba', 0.7599999999999999, 'ORL', 6, 2018), ('James Bouknight', 0.77, 'CHO', 11, 2021), ('Justise Winslow', 0.8, 'MIA', 10, 2015), ('Zach Collins', 0.8, 'SAC', 10, 2017), ('Sekou Doumbouya', 0.8, 'DET', 15, 2019), ('Thon Maker', 0.8166666666666667, 'MIL', 10, 2016), ('Anthony Davis', 0.8216666666666667, 'NOP', 1, 2012), ('Franz Wagner', 0.8266666666666667, 'ORL', 8, 2021), ('Wendell Carter Jr.', 0.84, 'CHI', 7, 2018), ('Joshua Primo', 0.8400000000000001, 'SAS', 12, 2021), ('Kendall Marshall', 0.845, 'PHO', 13, 2012), ('Jerome Robinson', 0.845, 'LAC', 13, 2018), ('Jalen Smith', 0.85, 'PHO', 10, 2020), ('Aaron Gordon', 0.8733333333333333, 'ORL', 4, 2014), ('Obi Toppin', 0.88, 'NYK', 8, 2020), ('Otto Porter Jr.', 0.8800000000000001, 'WAS', 3, 2013), ('Jaxson Hayes', 0.8933333333333333, 'ATL', 8, 2019), ('Adreian Payne', 0.9, 'ATL', 15, 2014), ('Timothe Luwawu-Cabarrot', 0.9199999999999999, 'PHI', 24, 2016), ('Willie Cauley-Stein', 0.9400000000000001, 'SAC', 6, 2015), ("De'Aaron Fox", 0.95, 'SAC', 5, 2017), ('Doug McDermott', 0.9716666666666666, 'DEN', 11, 2014), ('Dillon Brooks', 0.9749999999999999, 'HOU', 45, 2017), ('Justin Jackson', 0.975, 'POR', 15, 2017), ('Kira Lewis Jr.', 0.975, 'NOP', 13, 2020), ('Aaron Nesmith', 1.0033333333333332, 'BOS', 14, 2020), ('Trey Burke', 1.0050000000000001, 'MIN', 9, 2013), ('Terrance Ferguson', 1.015, 'OKC', 21, 2017), ('Malik Monk', 1.0266666666666666, 'CHO', 11, 2017), ('Georgios Papagiannis', 1.04, 'PHO', 13, 2016), ('Chris Duarte', 1.04, 'IND', 13, 2021), ('Kristaps Porzingis', 1.0533333333333335, 'NYK', 4, 2015), ('Romeo Langford', 1.0733333333333333, 'BOS', 14, 2019), ('Andrew Nicholson', 1.0766666666666667, 'ORL', 19, 2012), ('Rashad Vaughn', 1.0766666666666667, 'MIL', 17, 2015), ('Taurean Prince', 1.0800000000000003, 'UTA', 12, 2016), ('Jayson Tatum', 1.0800000000000003, 'BOS', 3, 2017), ('Aleksej Pokusevski', 1.105, 'MIN', 17, 2020), ('Meyers Leonard', 1.1183333333333332, 'POR', 11, 2012), ('Moses Moody', 1.12, 'GSW', 14, 2021), ('Tre Mann', 1.14, 'OKC', 18, 2021), ('Shabazz Muhammad', 1.1666666666666667, 'UTA', 14, 2013), ('Lonnie Walker IV', 1.1700000000000002, 'SAS', 18, 2018), ('Lauri Markkanen', 1.19, 'MIN', 7, 2017), ('Devin Vassell', 1.1916666666666667, 'SAS', 11, 2020), ('Troy Brown Jr.', 1.2, 'WAS', 15, 2018), ('Denzel Valentine', 1.2133333333333334, 'CHI', 14, 2016), ('Corey Kispert', 1.225, 'WAS', 15, 2021), ('Terrence Ross', 1.24, 'TOR', 8, 2012), ('Marcus Smart', 1.24, 'BOS', 6, 2014), ('Nerlens Noel', 1.25, 'NOP', 6, 2013), ('Tyler Ennis', 1.2600000000000002, 'PHO', 18, 2014), ('Frank Kaminsky', 1.2600000000000002, 'CHO', 9, 2015), ('Michael Carter-Williams', 1.2650000000000001, 'PHI', 11, 2013), ('Dwayne Bacon', 1.2666666666666666, 'NOP', 40, 2017), ('Wade Baldwin', 1.275, 'MEM', 17, 2016), ('Buddy Hield', 1.2800000000000002, 'NOP', 6, 2016), ('P.J. Washington', 1.3, 'CHO', 12, 2019), ('Cole Anthony', 1.3, 'ORL', 15, 2020), ('Nickeil Alexander-Walker', 1.3033333333333332, 'BRK', 17, 2019), ('Jamal Murray', 1.3066666666666664, 'DEN', 7, 2016), ('Justin Patton', 1.3066666666666669, 'CHI', 16, 2017), ('Zhaire Smith', 1.3066666666666669, 'PHO', 16, 2018), ('Shane Larkin', 1.32, 'ATL', 18, 2013), ('Juancho Hernangomez', 1.325, 'DEN', 15, 2016), ('James Young', 1.3316666666666668, 'BOS', 17, 2014), ('D.J. Wilson', 1.3316666666666668, 'MIL', 17, 2017), ('Royce White', 1.3333333333333333, 'HOU', 16, 2012), ('Guerschon Yabusele', 1.3333333333333333, 'BOS', 16, 2016), ('Josh Okogie', 1.3333333333333333, 'MIN', 20, 2018), ('Isaiah Stewart', 1.3333333333333333, 'POR', 16, 2020), ('Bradley Beal', 1.335, 'WAS', 3, 2012), ('Joel Embiid', 1.3599999999999999, 'PHI', 3, 2014), ('Jarell Martin', 1.375, 'MEM', 25, 2015), ('Trey Lyles', 1.3800000000000001, 'UTA', 12, 2015), ('Luka Doncic', 1.3900000000000001, 'ATL', 3, 2018), ('Precious Achiuwa', 1.4, 'MIA', 20, 2020), ('Henry Ellenson', 1.4100000000000001, 'DET', 18, 2016), ('Tyler Zeller', 1.4166666666666667, 'DAL', 17, 2012), ('Harrison Barnes', 1.4466666666666665, 'GSW', 7, 2012), ('Elfrid Payton', 1.45, 'PHI', 10, 2014), ('Sergey Karasev', 1.4566666666666666, 'CLE', 19, 2013), ('Keon Johnson', 1.47, 'NYK', 21, 2021), ('Kelly Oubre Jr.', 1.475, 'ATL', 15, 2015), ('Kentavious Caldwell-Pope', 1.48, 'DET', 8, 2013), ('Luka Samanic', 1.4883333333333333, 'SAS', 19, 2019), ('Trae Young', 1.4916666666666667, 'DAL', 5, 2018), ('Dario Saric', 1.5, 'ORL', 12, 2014), ('Chandler Hutchison', 1.5033333333333332, 'CHI', 22, 2018), ('Alperen Sengun', 1.52, 'OKC', 16, 2021), ('Kai Jones', 1.52, 'NYK', 19, 2021), ('T.J. Leaf', 1.53, 'IND', 18, 2017), ('Malachi Richardson', 1.5766666666666667, 'CHO', 22, 2016), ('Josh Green', 1.5899999999999999, 'DAL', 18, 2020), ('Bruno Caboclo', 1.6, 'TOR', 20, 2014), ('Harry Giles', 1.6, 'POR', 20, 2017), ('R.J. Hampton', 1.6, 'MIL', 24, 2020), ('Frank Jackson', 1.6016666666666668, 'CHO', 31, 2017), ("DeAndre' Bembry", 1.6099999999999999, 'ATL', 21, 2016), ('Cameron Johnson', 1.6133333333333335, 'MIN', 11, 2019), ('Goga Bitadze', 1.62, 'IND', 18, 2019), ('Tony Wroten', 1.625, 'MEM', 25, 2012), ('Chuma Okeke', 1.6266666666666665, 'ORL', 16, 2019), ('Tony Snell', 1.6333333333333333, 'CHI', 20, 2013), ('Jalen Johnson', 1.6333333333333333, 'ATL', 20, 2021), ('Luke Kennard', 1.64, 'DET', 12, 2017), ('Darius Bazley', 1.6483333333333332, 'UTA', 23, 2019), ('Sam Dekker', 1.65, 'HOU', 18, 2015), ('Tyler Herro', 1.6683333333333334, 'MIA', 13, 2019), ('Trey Murphy III', 1.6716666666666669, 'MEM', 17, 2021), ('Cameron Payne', 1.7033333333333334, 'OKC', 14, 2015), ('Mitch McGary', 1.715, 'OKC', 21, 2014), ('P.J. Hairston', 1.7333333333333334, 'MIA', 26, 2014), ('Jerian Grant', 1.7416666666666667, 'WAS', 19, 2015), ('Jared Cunningham', 1.7600000000000002, 'CLE', 24, 2012), ('Wes Iwundu', 1.7600000000000002, 'ORL', 33, 2017), ('Miles Bridges', 1.7600000000000002, 'LAC', 12, 2018), ('Josh Christopher', 1.7600000000000002, 'HOU', 24, 2021), ('Aaron Holiday', 1.7633333333333332, 'IND', 23, 2018), ('Jakob Poeltl', 1.77, 'TOR', 9, 2016), ('Fab Melo', 1.7966666666666669, 'BOS', 22, 2012), ('Zeke Nnaji', 1.7966666666666669, 'DEN', 22, 2020), ('Solomon Hill', 1.8016666666666667, 'IND', 23, 2013), ('Leandro Bolmaro', 1.8016666666666667, 'NYK', 23, 2020), ('Jeff Taylor', 1.8083333333333333, 'CHO', 31, 2012), ('Theo Maledon', 1.8133333333333335, 'PHI', 34, 2020), ('Ante Zizic', 1.8399999999999999, 'BOS', 23, 2016), ('Lucas Nogueira', 1.84, 'BOS', 16, 2013), ('Julius Randle', 1.855, 'LAL', 7, 2014), ('Caleb Swanigan', 1.8633333333333333, 'POR', 26, 2017), ('Jaden McDaniels', 1.8666666666666667, 'LAL', 28, 2020), ('Isaiah Jackson', 1.8699999999999999, 'LAL', 22, 2021), ('Anzejs Pasecniks', 1.875, 'ORL', 25, 2017), ('Justin Anderson', 1.8900000000000001, 'DAL', 21, 2015), ('Jordan Adams', 1.9066666666666667, 'MEM', 22, 2014), ("Johnny O'Bryant", 1.9200000000000002, 'MIL', 36, 2014), ('Marquis Teague', 1.9333333333333333, 'CHI', 29, 2012), ('Michael Porter Jr.', 1.936666666666667, 'DEN', 14, 2018), ('John Jenkins', 1.9549999999999998, 'ATL', 23, 2012), ('John Henson', 1.9600000000000002, 'MIL', 14, 2012), ('Tyler Lydon', 1.9600000000000002, 'UTA', 24, 2017), ('Jacob Evans', 1.9600000000000002, 'GSW', 28, 2018), ('Cam Thomas', 1.9800000000000002, 'BRK', 27, 2021), ('Ty Jerome', 2.0, 'PHI', 24, 2019), ('Nassir Little', 2.041666666666667, 'POR', 25, 2019), ('Perry Jones', 2.0533333333333337, 'OKC', 28, 2012), ('Donte DiVincenzo', 2.0683333333333334, 'MIL', 17, 2018), ('Usman Garuba', 2.07, 'HOU', 23, 2021), ('Brice Johnson', 2.0833333333333335, 'LAC', 25, 2016), ('Grant Williams', 2.0900000000000003, 'BOS', 22, 2019), ('Elie Okobo', 2.118333333333333, 'PHO', 31, 2018), ('Archie Goodwin', 2.126666666666667, 'OKC', 29, 2013), ('Semi Ojeleye', 2.158333333333333, 'BOS', 37, 2017), ('T.J. Warren', 2.1700000000000004, 'PHO', 14, 2014), ('Cedi Osman', 2.1700000000000004, 'MIN', 31, 2015), ('Kevin Huerter', 2.185, 'ATL', 19, 2018), ('Anfernee Simons', 2.2, 'POR', 24, 2018), ('Arnett Moultrie', 2.205, 'MIA', 27, 2012), ('Mfiondu Kabengele', 2.205, 'BRK', 27, 2019), ('Tyler Ulis', 2.21, 'PHO', 34, 2016), ('Dylan Windler', 2.21, 'CLE', 26, 2019), ('Saddiq Bey', 2.216666666666667, 'BRK', 19, 2020), ('Josh Huestis', 2.223333333333333, 'OKC', 29, 2014), ('Dzanan Musa', 2.223333333333333, 'BRK', 29, 2018), ('Mikal Bridges', 2.2333333333333334, 'PHI', 10, 2018), ('C.J. Wilcox', 2.24, 'LAC', 28, 2014), ('Skal Labissiere', 2.24, 'PHO', 28, 2016), ('Gary Harris', 2.2483333333333335, 'CHI', 19, 2014), ('Moritz Wagner', 2.25, 'LAL', 25, 2018), ('Kevin Porter Jr.', 2.25, 'MIL', 30, 2019), ('Miles Plumlee', 2.2533333333333334, 'IND', 26, 2012), ('Furkan Korkmaz', 2.2533333333333334, 'PHI', 26, 2016), ('Maurice Harkless', 2.275, 'PHI', 15, 2012), ('Quentin Grimes', 2.2916666666666665, 'LAC', 25, 2021), ('Dennis Schroder', 2.295, 'ATL', 17, 2013), ('Udoka Azubuike', 2.295, 'UTA', 27, 2020), ('Landry Shamet', 2.2966666666666664, 'PHI', 26, 2018), ('Tyrese Haliburton', 2.32, 'SAC', 12, 2020), ('R.J. Hunter', 2.3333333333333335, 'BOS', 28, 2015), ('Jaden Springer', 2.3333333333333335, 'PHI', 28, 2021), ('KZ Okpala', 2.3466666666666667, 'PHO', 32, 2019), ('Nemanja Nedovic', 2.35, 'PHO', 30, 2013), ('Chris McCullough', 2.3683333333333336, 'BRK', 29, 2015), ("Day'Ron Sharpe", 2.3683333333333336, 'PHO', 29, 2021), ('Malik Beasley', 2.375, 'DEN', 19, 2016), ('Cleanthony Early', 2.3800000000000003, 'NYK', 34, 2014), ('Malachi Flynn', 2.4166666666666665, 'TOR', 29, 2020), ('Grayson Allen', 2.45, 'UTA', 21, 2018), ('K.J. McDaniels', 2.453333333333333, 'PHI', 32, 2014), ('Carsen Edwards', 2.475, 'PHI', 33, 2019), ('Anthony Brown', 2.4933333333333336, 'LAL', 34, 2015), ('Festus Ezeli', 2.5, 'GSW', 30, 2012), ('Davon Reed', 2.506666666666667, 'PHO', 32, 2017), ('Isaiah Whitehead', 2.5200000000000005, 'UTA', 42, 2016), ('Tyrese Maxey', 2.5200000000000005, 'PHI', 21, 2020), ('Damien Inglis', 2.5316666666666667, 'MIL', 31, 2014), ('Isaiah Todd', 2.5316666666666667, 'MIL', 31, 2021), ('Isaiah Canaan', 2.55, 'HOU', 34, 2013), ('Bones Hyland', 2.5566666666666666, 'DEN', 26, 2021), ('Vernon Carey Jr.', 2.56, 'CHO', 32, 2020), ('Melvin Frazier', 2.566666666666667, 'ORL', 35, 2018), ('Jordan Poole', 2.566666666666667, 'GSW', 28, 2019), ('Terrence Jones', 2.5799999999999996, 'HOU', 18, 2012), ('Jeremy Lamb', 2.58, 'HOU', 12, 2012), ('Deyonta Davis', 2.5833333333333335, 'BOS', 31, 2016), ('Tyrell Terry', 2.5833333333333335, 'DAL', 31, 2020), ('Myles Turner', 2.585, 'IND', 11, 2015), ('Jordan Mickey', 2.585, 'BOS', 33, 2015), ('Omari Spellman', 2.6, 'ATL', 30, 2018), ('Bruno Fernando', 2.6066666666666665, 'PHI', 34, 2019), ('Daniel Oturu', 2.64, 'MIN', 33, 2020), ('Santi Aldama', 2.65, 'UTA', 30, 2021), ('Shai Gilgeous-Alexander', 2.658333333333333, 'CHO', 11, 2018), ('Doron Lamb', 2.6599999999999997, 'MIL', 42, 2012), ('Frank Mason III', 2.6633333333333336, 'SAC', 34, 2017), ('Jared Sullinger', 2.6950000000000003, 'BOS', 21, 2012), ('Vit Krejci', 2.7133333333333334, 'WAS', 37, 2020), ('Alex Abrines', 2.7199999999999998, 'OKC', 32, 2013), ('Payton Pritchard', 2.7299999999999995, 'BOS', 26, 2020), ('Didi Louzada', 2.7416666666666667, 'ATL', 35, 2019), ('Bernard James', 2.75, 'CLE', 33, 2012), ('Carrick Felix', 2.75, 'CLE', 33, 2013), ('Jason Preston', 2.75, 'ORL', 33, 2021), ('Ray McCallum', 2.76, 'SAC', 36, 2013), ('Rodney Hood', 2.76, 'UTA', 23, 2014), ('Caris LeVert', 2.7666666666666666, 'IND', 20, 2016), ('Jeremiah Robinson-Earl', 2.7733333333333334, 'NYK', 32, 2021), ('Darrun Hilliard', 2.786666666666667, 'DET', 38, 2015), ('Patrick McCaw', 2.786666666666667, 'MIL', 38, 2016), ('Jawun Evans', 2.795, 'PHI', 39, 2017), ('Isaac Bonga', 2.795, 'PHI', 39, 2018), ('Rondae Hollis-Jefferson', 2.7983333333333333, 'POR', 23, 2015), ('Glen Rice Jr.', 2.8, 'PHI', 35, 2013), ('Shabazz Napier', 2.8, 'CHO', 24, 2014), ('Matisse Thybulle', 2.8, 'BOS', 20, 2019), ('Tony Bradley', 2.8466666666666662, 'LAL', 28, 2017), ('Quincy Miller', 2.85, 'DEN', 38, 2012), ('Tyshawn Taylor', 2.87, 'POR', 41, 2012), ('Rakeem Christmas', 2.88, 'MIN', 36, 2015), ('Miles McBride', 2.88, 'OKC', 36, 2021), ('Paul Zipser', 2.8800000000000003, 'CHI', 48, 2016), ('Damian Jones', 2.9, 'GSW', 30, 2016), ('Cheick Diallo', 2.915, 'LAC', 33, 2016), ('Elijah Hughes', 2.925, 'NOP', 39, 2020), ('Orlando Johnson', 2.94, 'SAC', 36, 2012), ('Admiral Schofield', 2.94, 'PHI', 42, 2019), ('Tyler Bey', 2.94, 'PHI', 36, 2020), ('Keldon Johnson', 2.948333333333333, 'SAS', 29, 2019), ('Deividas Sirvydis', 2.96, 'DAL', 37, 2019), ('JT Thor', 2.96, 'DET', 37, 2021), ('Jarnell Stokes', 2.975, 'UTA', 35, 2014), ('Ivan Rabb', 2.975, 'ORL', 35, 2017), ('CJ Elleby', 2.99, 'POR', 46, 2020), ('Immanuel Quickley', 3.0, 'OKC', 25, 2020), ('Damyean Dotson', 3.0066666666666664, 'NYK', 44, 2017), ('Quincy Acy', 3.021666666666667, 'TOR', 37, 2012), ('Chinanu Onuaku', 3.021666666666667, 'HOU', 37, 2016), ('Nate Wolters', 3.04, 'WAS', 38, 2013), ('Allen Crabbe', 3.0483333333333333, 'CLE', 31, 2013), ('Jonah Bolden', 3.06, 'PHI', 36, 2017), ('Rodions Kurucs', 3.066666666666667, 'BRK', 40, 2018), ('Tony Mitchell', 3.0833333333333335, 'DET', 37, 2013), ('Jusuf Nurkic', 3.0933333333333333, 'CHI', 16, 2014), ('Khyri Thomas', 3.1033333333333335, 'PHI', 38, 2018), ('Tyler Dorsey', 3.143333333333333, 'ATL', 41, 2017), ('Joe Young', 3.1533333333333338, 'IND', 43, 2015), ('Andre Roberson', 3.163333333333333, 'MIN', 26, 2013), ('Reggie Bullock', 3.1666666666666665, 'LAC', 25, 2013), ('Ayo Dosunmu', 3.1666666666666665, 'CHI', 38, 2021), ('Alen Smailagic', 3.1850000000000005, 'NOP', 39, 2019), ('Neemias Queta', 3.1850000000000005, 'SAC', 39, 2021), ('Justin James', 3.2, 'SAC', 40, 2019), ('Zach LaVine', 3.2066666666666666, 'MIN', 13, 2014), ('Jordan Nwora', 3.225, 'MIL', 45, 2020), ('Greg Brown III', 3.225, 'NOP', 43, 2021), ('Andrew Harrison', 3.226666666666667, 'PHO', 44, 2015), ('Kessler Edwards', 3.226666666666667, 'BRK', 44, 2021), ('Evan Fournier', 3.2666666666666666, 'DEN', 20, 2012), ('Grant Jerrett', 3.2666666666666666, 'POR', 40, 2013), ('Diamond Stone', 3.2666666666666666, 'NOP', 40, 2016), ('Robert Woodard II', 3.2666666666666666, 'MEM', 40, 2020), ('Jamaal Franklin', 3.28, 'MEM', 41, 2013), ('Stephen Zimmerman', 3.28, 'ORL', 41, 2016), ('Nick Johnson', 3.29, 'HOU', 42, 2014), ('Saben Lee', 3.2933333333333334, 'UTA', 38, 2020), ('Ricky Ledo', 3.2966666666666664, 'MIL', 43, 2013), ('Domantas Sabonis', 3.3, 'ORL', 11, 2016), ('Jevon Carter', 3.3066666666666666, 'MEM', 32, 2018), ('Steven Adams', 3.3200000000000003, 'OKC', 12, 2013), ('Jared Butler', 3.3333333333333335, 'NOP', 40, 2021), ('Eric Paschall', 3.3483333333333336, 'GSW', 41, 2019), ('Joe Wieskamp', 3.3483333333333336, 'SAS', 41, 2021), ('Markel Brown', 3.373333333333333, 'MIN', 44, 2014), ('Bobby Portis', 3.373333333333333, 'CHI', 22, 2015), ('Hamidou Diallo', 3.375, 'BRK', 45, 2018), ('Kelly Olynyk', 3.38, 'DAL', 13, 2013), ('Andre Drummond', 3.4200000000000004, 'DET', 9, 2012), ('Cody Martin', 3.4200000000000004, 'CHO', 36, 2019), ('Pierre Jackson', 3.43, 'PHI', 42, 2013), ('Nick Richards', 3.43, 'NOP', 42, 2020), ('Zhou Qi', 3.44, 'HOU', 43, 2016), ("Jahmi'us Ramsey", 3.44, 'SAC', 43, 2020), ('Svi Mykhailiuk', 3.4466666666666668, 'LAL', 47, 2018), ('Ignas Brazdeikis', 3.4466666666666668, 'SAC', 47, 2019), ('Nic Claxton', 3.461666666666667, 'BRK', 31, 2019), ('CJ McCollum', 3.4833333333333334, 'POR', 10, 2013), ('Xavier Tillman Sr.', 3.5, 'SAC', 35, 2020), ('Herbert Jones', 3.5, 'NOP', 35, 2021), ('Isaiah Livers', 3.5, 'DET', 42, 2021), ('Kyle Kuzma', 3.51, 'BRK', 27, 2017), ('Kim English', 3.52, 'DET', 44, 2012), ('Terry Rozier', 3.52, 'BOS', 16, 2015), ('Darius Miller', 3.5266666666666664, 'NOP', 46, 2012), ('Edy Tavares', 3.5833333333333335, 'ATL', 43, 2014), ('Marko Simonovic', 3.5933333333333337, 'CHI', 44, 2020), ('Robert Sacre', 3.6, 'LAL', 60, 2012), ('Ryan Kelly', 3.6, 'LAL', 48, 2013), ('Glenn Robinson III', 3.6, 'MIN', 40, 2014), ('Tyrone Wallace', 3.6, 'UTA', 60, 2016), ('Sindarius Thornwell', 3.6, 'MIL', 48, 2017), ('Brandon Clarke', 3.605, 'OKC', 21, 2019), ('Devin Booker', 3.618333333333333, 'PHO', 13, 2015), ('Erick Green', 3.6799999999999997, 'UTA', 46, 2013), ('Lamar Patterson', 3.6799999999999997, 'MIL', 48, 2014), ('A.J. Hammons', 3.6799999999999997, 'DAL', 46, 2016), ('Talen Horton-Tucker', 3.6799999999999997, 'ORL', 46, 2019), ('Tre Jones', 3.69, 'SAS', 41, 2020), ('Sterling Brown', 3.756666666666667, 'PHI', 46, 2017), ('Kevin Murphy', 3.76, 'UTA', 47, 2012), ('Jake Layman', 3.76, 'ORL', 47, 2016), ('Demetrius Jackson', 3.8249999999999997, 'BOS', 45, 2016), ('Isaiah Roby', 3.8249999999999997, 'DET', 45, 2019), ('Thanasis Antetokounmpo', 3.825, 'NYK', 51, 2014), ('OG Anunoby', 3.8333333333333335, 'TOR', 23, 2017), ('Dalano Banton', 3.8333333333333335, 'TOR', 46, 2021), ('Russ Smith', 3.8383333333333334, 'PHI', 47, 2014), ('Cameron Bairstow', 3.8383333333333334, 'CHI', 49, 2014), ('Kostas Papanikolaou', 3.8399999999999994, 'NYK', 48, 2012), ('Keita Bates-Diop', 3.8399999999999994, 'MIN', 48, 2018), ('Nico Mannion', 3.8399999999999994, 'GSW', 48, 2020), ('Semaj Christon', 3.85, 'MIA', 55, 2014), ('Jordan Bell', 3.863333333333333, 'CHI', 38, 2017), ('Lorenzo Brown', 3.9, 'MIN', 52, 2013), ('Ike Anigbogu', 3.9166666666666665, 'IND', 47, 2017), ('David Johnson', 3.9166666666666665, 'TOR', 47, 2021), ('Quinndary Weatherspoon', 3.92, 'SAS', 49, 2019), ('Sharife Cooper', 3.9200000000000004, 'ATL', 48, 2021), ('Jaylen Nowell', 3.941666666666667, 'MIN', 43, 2019), ('Tomas Satoransky', 3.9466666666666668, 'WAS', 32, 2012), ('Tim Hardaway Jr.', 3.9600000000000004, 'NYK', 24, 2013), ('Edmond Sumner', 3.9866666666666664, 'NOP', 52, 2017), ('John Collins', 3.99, 'ATL', 19, 2017), ('Brandon Boston Jr.', 3.995, 'MEM', 51, 2021), ('Erik Murphy', 4.001666666666667, 'CHI', 49, 2013), ('Michael Gbinije', 4.001666666666667, 'DET', 49, 2016), ('Isaiah Joe', 4.001666666666667, 'PHI', 49, 2020), ('Mike Scott', 4.013333333333333, 'ATL', 43, 2012), ('Aaron Wiggins', 4.033333333333334, 'OKC', 55, 2021), ('Jalen McDaniels', 4.073333333333333, 'CHO', 52, 2019), ('Dakari Johnson', 4.08, 'OKC', 48, 2015), ('Vlatko Cancar', 4.083333333333333, 'DEN', 49, 2017), ('Chimezie Metu', 4.083333333333333, 'SAS', 49, 2018), ('Alize Johnson', 4.083333333333334, 'IND', 50, 2018), ('Jeff Withey', 4.095, 'POR', 39, 2013), ('Bol Bol', 4.1066666666666665, 'MIA', 44, 2019), ('Bam Adebayo', 4.106666666666667, 'MIA', 14, 2017), ('Justin Hamilton', 4.125, 'PHI', 45, 2012), ('Kay Felder', 4.14, 'ATL', 54, 2016), ('Cassius Stanley', 4.14, 'IND', 54, 2020), ('Ognjen Kuzmic', 4.16, 'GSW', 52, 2012), ('Kris Joseph', 4.165, 'BOS', 51, 2012), ('Ben Bentil', 4.165, 'BOS', 51, 2016), ('Tremont Waters', 4.165, 'BOS', 51, 2019), ('Gary Trent Jr.', 4.193333333333333, 'SAC', 37, 2018), ('Kevon Looney', 4.2, 'GSW', 30, 2015), ('Tornike Shengelia', 4.23, 'PHI', 54, 2012), ('Furkan Aldemir', 4.239999999999999, 'LAC', 53, 2012), ('Tyus Jones', 4.239999999999999, 'CLE', 24, 2015), ('Luka Garza', 4.246666666666667, 'DET', 52, 2021), ('Jarrell Brantley', 4.249999999999999, 'IND', 50, 2019), ('Devyn Marble', 4.293333333333333, 'DEN', 56, 2014), ('Gorgui Dieng', 4.305000000000001, 'UTA', 21, 2013), ('Kyle Guy', 4.308333333333334, 'NYK', 55, 2019), ('Jay Scrubb', 4.308333333333334, 'BRK', 55, 2020), ('Petr Cornelie', 4.328333333333334, 'DEN', 53, 2016), ('Devon Hall', 4.328333333333334, 'OKC', 53, 2018), ('Justin Wright-Foreman', 4.328333333333334, 'UTA', 53, 2019), ('Cassius Winston', 4.328333333333334, 'OKC', 53, 2020), ('Joel Bolomboy', 4.333333333333333, 'UTA', 52, 2016), ('Vince Edwards', 4.333333333333333, 'UTA', 52, 2018), ('Willy Hernangomez', 4.375, 'PHI', 35, 2015), ('Marial Shayok', 4.41, 'PHI', 54, 2019), ('Skylar Mays', 4.416666666666667, 'ATL', 50, 2020), ('Donovan Mitchell', 4.42, 'DEN', 13, 2017), ('Robbie Hummel', 4.446666666666666, 'MIN', 58, 2012), ('Abdel Nader', 4.446666666666666, 'BOS', 58, 2016), ('Josh Hart', 4.45, 'UTA', 30, 2017), ('Desmond Bane', 4.45, 'BOS', 30, 2020), ('Raul Neto', 4.465000000000001, 'ATL', 47, 2013), ('Reggie Perry', 4.465000000000001, 'LAC', 57, 2020), ("Devonte' Graham", 4.4766666666666675, 'ATL', 34, 2018), ('Peyton Siva', 4.48, 'DET', 56, 2013), ('Ray Spalding', 4.48, 'PHI', 56, 2018), ('Darius Johnson-Odom', 4.491666666666666, 'DAL', 55, 2012), ('Joffrey Lauvergne', 4.491666666666666, 'MEM', 55, 2013), ('Alec Peters', 4.5, 'PHO', 54, 2017), ('Kadeem Allen', 4.504999999999999, 'BOS', 53, 2017), ('Jordan Bone', 4.56, 'NOP', 57, 2019), ('Daniel Hamilton', 4.573333333333334, 'DEN', 56, 2016), ('Marcus Paige', 4.583333333333333, 'BRK', 55, 2016), ('Nigel Williams-Goss', 4.583333333333333, 'UTA', 55, 2017), ('Arnoldas Kulboka', 4.583333333333333, 'CHO', 55, 2018), ('Sandro Mamukelashvili', 4.59, 'IND', 54, 2021), ('Branden Dawson', 4.666666666666667, 'NOP', 56, 2015), ('Jabari Bird', 4.666666666666667, 'BOS', 56, 2017), ('Grant Riller', 4.666666666666667, 'CHO', 56, 2020), ('Scottie Lewis', 4.666666666666667, 'CHO', 56, 2021), ('Delon Wright', 4.7, 'TOR', 20, 2015), ('Georgios Kalaitzakis', 4.7, 'IND', 60, 2021), ('Jaron Blossomgame', 4.72, 'SAS', 59, 2017), ('Miye Oni', 4.736666666666667, 'GSW', 58, 2019), ('Kevin Hervey', 4.75, 'OKC', 57, 2018), ('Daniel Gafford', 4.75, 'CHI', 38, 2019), ('Bogdan Bogdanovic', 4.77, 'PHO', 27, 2014), ('Shake Milton', 4.77, 'DAL', 54, 2018), ('Charles Bassey', 4.7700000000000005, 'PHI', 53, 2021), ('Cory Jefferson', 4.8, 'SAS', 60, 2014), ('Kostas Antetokounmpo', 4.8, 'PHI', 60, 2018), ('George King', 4.818333333333333, 'PHO', 59, 2018), ('Dewan Hernandez', 4.818333333333333, 'TOR', 59, 2019), ('Jordan McRae', 4.833333333333333, 'SAS', 58, 2014), ('Thomas Welsh', 4.833333333333333, 'DEN', 58, 2018), ('Joe Harris', 4.840000000000001, 'CLE', 33, 2014), ('Bruce Brown', 4.9, 'DET', 42, 2018), ('James Ennis III', 4.916666666666667, 'ATL', 50, 2013), ('Kenyon Martin Jr.', 4.94, 'SAC', 52, 2020), ('Jarred Vanderbilt', 4.988333333333333, 'ORL', 41, 2018), ('Damian Lillard', 4.989999999999999, 'POR', 6, 2012), ('Sam Merrill', 5.0, 'NOP', 60, 2020), ('Jalen Harris', 5.015, 'TOR', 59, 2020), ('Jericho Sims', 5.026666666666667, 'NYK', 58, 2021), ('Robert Williams', 5.085, 'BOS', 27, 2018), ('Ivica Zubac', 5.173333333333333, 'LAL', 32, 2016), ('Paul Reed', 5.220000000000001, 'PHI', 58, 2020), ('Jarrett Allen', 5.243333333333334, 'BRK', 22, 2017), ('Georges Niang', 5.25, 'IND', 50, 2016), ('Derrick White', 5.316666666666666, 'SAS', 29, 2017), ('Jalen Brunson', 5.334999999999999, 'DAL', 33, 2018), ('Terance Mann', 5.36, 'LAC', 48, 2019), ('Isaiah Hartenstein', 5.375, 'HOU', 43, 2017), ('Thomas Bryant', 5.8100000000000005, 'UTA', 42, 2017), ('Larry Nance Jr.', 5.895, 'LAL', 27, 2015), ('Pat Connaughton', 6.013333333333334, 'BRK', 41, 2015), ('Richaun Holmes', 6.043333333333334, 'PHI', 37, 2015), ('Mason Plumlee', 6.489999999999999, 'BRK', 22, 2013), ('Mike Muscala', 6.526666666666667, 'DAL', 44, 2013), ('Josh Richardson', 6.6, 'MIA', 40, 2015), ('Dejounte Murray', 6.718333333333334, 'SAS', 29, 2016), ("De'Anthony Melton", 6.746666666666667, 'HOU', 46, 2018), ('Mitchell Robinson', 6.9, 'NYK', 36, 2018), ('Norman Powell', 7.359999999999999, 'MIL', 46, 2015), ('Spencer Dinwiddie', 7.6, 'DET', 38, 2014), ('Jerami Grant', 7.6049999999999995, 'PHI', 39, 2014), ('Kyle Anderson', 7.7, 'SAS', 30, 2014), ('Clint Capela', 7.708333333333333, 'HOU', 25, 2014), ('Pascal Siakam', 7.829999999999999, 'TOR', 27, 2016), ('Will Barton', 7.933333333333334, 'POR', 40, 2012), ('Monte Morris', 7.99, 'DEN', 51, 2017), ('Malcolm Brogdon', 8.16, 'MIL', 36, 2016), ("Kyle O'Quinn", 8.166666666666666, 'ORL', 49, 2012), ('Jordan Clarkson', 8.586666666666666, 'WAS', 46, 2014), ('Jae Crowder', 9.01, 'CLE', 34, 2012), ('Montrezl Harrell', 9.120000000000001, 'HOU', 32, 2015), ('Dwight Powell', 9.75, 'CHO', 45, 2014), ('Giannis Antetokounmpo', 12.525, 'MIL', 15, 2013), ('Khris Middleton', 12.545, 'DET', 39, 2012), ('Rudy Gobert', 14.940000000000001, 'DEN', 27, 2013), ('Draymond Green', 16.683333333333334, 'GSW', 35, 2012), ('Nikola Jokic', 35.39666666666666, 'DEN', 41, 2014)]
    


```python
raw_sorted_by_rating = sorted(rawtuples, key=lambda tup: tup[1])
print(raw_sorted_by_rating)
```

    [('Austin Rivers', 0.5, 'NOP', 10, 2012), ('Dillon Brooks', 1.2999999999999998, 'HOU', 45, 2017), ('Ben McLemore', 1.6, 'SAC', 7, 2013), ('Josh Jackson', 1.9, 'PHO', 4, 2017), ('Dwayne Bacon', 1.9, 'NOP', 40, 2017), ('Timothe Luwawu-Cabarrot', 2.3, 'PHI', 24, 2016), ('Kevin Knox', 2.3, 'NYK', 9, 2018), ('Frank Ntilikina', 2.4, 'NYK', 8, 2017), ('Emmanuel Mudiay', 2.8, 'DEN', 7, 2015), ('Terrance Ferguson', 2.9, 'OKC', 21, 2017), ('Dragan Bender', 3.1, 'PHO', 4, 2016), ('Frank Jackson', 3.1, 'CHO', 31, 2017), ("De'Andre Hunter", 3.1, 'LAL', 4, 2019), ("Johnny O'Bryant", 3.2, 'MIL', 36, 2014), ('Wes Iwundu', 3.2, 'ORL', 33, 2017), ('Sekou Doumbouya', 3.2, 'DET', 15, 2019), ('Theo Maledon', 3.2, 'PHI', 34, 2020), ('Nik Stauskas', 3.3, 'SAC', 8, 2014), ('Stanley Johnson', 3.3, 'DET', 8, 2015), ('Jarell Martin', 3.3, 'MEM', 25, 2015), ('Isaac Okoro', 3.3, 'CLE', 5, 2020), ('Killian Hayes', 3.3, 'DET', 7, 2020), ('Thomas Robinson', 3.4, 'SAC', 5, 2012), ('Andrew Nicholson', 3.4, 'ORL', 19, 2012), ('Jarrett Culver', 3.4, 'PHO', 6, 2019), ('Jeff Taylor', 3.5, 'CHO', 31, 2012), ('Dante Exum', 3.5, 'UTA', 5, 2014), ('Semi Ojeleye', 3.5, 'BOS', 37, 2017), ('Robert Sacre', 3.6, 'LAL', 60, 2012), ('Adreian Payne', 3.6, 'ATL', 15, 2014), ('Isaiah Whitehead', 3.6, 'UTA', 42, 2016), ('Paul Zipser', 3.6, 'CHI', 48, 2016), ('Tyrone Wallace', 3.6, 'UTA', 60, 2016), ('Anthony Bennett', 3.7, 'CLE', 1, 2013), ('Doron Lamb', 3.8, 'MIL', 42, 2012), ('Mario Hezonja', 3.8, 'ORL', 5, 2015), ('Rashad Vaughn', 3.8, 'MIL', 17, 2015), ('Jalen Suggs', 3.8, 'ORL', 5, 2021), ('Tre Mann', 3.8, 'OKC', 18, 2021), ('Kendall Marshall', 3.9, 'PHO', 13, 2012), ('Tony Wroten', 3.9, 'MEM', 25, 2012), ('Tyler Ulis', 3.9, 'PHO', 34, 2016), ('Justin Jackson', 3.9, 'POR', 15, 2017), ('Jerome Robinson', 3.9, 'LAC', 13, 2018), ('Lonnie Walker IV', 3.9, 'SAS', 18, 2018), ('Aleksej Pokusevski', 3.9, 'MIN', 17, 2020), ('CJ Elleby', 3.9, 'POR', 46, 2020), ('Davion Mitchell', 3.9, 'SAC', 9, 2021), ('Marquis Teague', 4.0, 'CHI', 29, 2012), ('P.J. Hairston', 4.0, 'MIA', 26, 2014), ('Josh Okogie', 4.0, 'MIN', 20, 2018), ('Rui Hachimura', 4.0, 'WAS', 9, 2019), ('Cam Reddish', 4.0, 'ATL', 10, 2019), ('R.J. Hampton', 4.0, 'MIL', 24, 2020), ('Jaden McDaniels', 4.0, 'LAL', 28, 2020), ('Damyean Dotson', 4.1, 'NYK', 44, 2017), ('Chandler Hutchison', 4.1, 'CHI', 22, 2018), ('Elie Okobo', 4.1, 'PHO', 31, 2018), ('Tyshawn Taylor', 4.2, 'POR', 41, 2012), ('Tyler Ennis', 4.2, 'PHO', 18, 2014), ('Cleanthony Early', 4.2, 'NYK', 34, 2014), ('Semaj Christon', 4.2, 'MIA', 55, 2014), ('Cedi Osman', 4.2, 'MIN', 31, 2015), ('Collin Sexton', 4.2, 'CLE', 8, 2018), ('Jacob Evans', 4.2, 'GSW', 28, 2018), ('Admiral Schofield', 4.2, 'PHI', 42, 2019), ('Precious Achiuwa', 4.2, 'MIA', 20, 2020), ('James Bouknight', 4.2, 'CHO', 11, 2021), ('Joshua Primo', 4.2, 'SAS', 12, 2021), ('Keon Johnson', 4.2, 'NYK', 21, 2021), ('Noah Vonleh', 4.3, 'CHO', 9, 2014), ('Malachi Richardson', 4.3, 'CHO', 22, 2016), ('Caleb Swanigan', 4.3, 'POR', 26, 2017), ('Jawun Evans', 4.3, 'PHI', 39, 2017), ('Isaac Bonga', 4.3, 'PHI', 39, 2018), ('Coby White', 4.3, 'CHI', 7, 2019), ('Darius Bazley', 4.3, 'UTA', 23, 2019), ('James Wiseman', 4.3, 'GSW', 2, 2020), ('Aaron Nesmith', 4.3, 'BOS', 14, 2020), ('Jordan Nwora', 4.3, 'MIL', 45, 2020), ('Jared Cunningham', 4.4, 'CLE', 24, 2012), ('Perry Jones', 4.4, 'OKC', 28, 2012), ('Shane Larkin', 4.4, 'ATL', 18, 2013), ('Archie Goodwin', 4.4, 'OKC', 29, 2013), ('Anthony Brown', 4.4, 'LAL', 34, 2015), ('Darrun Hilliard', 4.4, 'DET', 38, 2015), ('Joe Young', 4.4, 'IND', 43, 2015), ('Andrew Harrison', 4.4, 'PHO', 44, 2015), ('Patrick McCaw', 4.4, 'MIL', 38, 2016), ('Melvin Frazier', 4.4, 'ORL', 35, 2018), ('Svi Mykhailiuk', 4.4, 'LAL', 47, 2018), ('KZ Okpala', 4.4, 'PHO', 32, 2019), ('Ignas Brazdeikis', 4.4, 'SAC', 47, 2019), ('Vit Krejci', 4.4, 'WAS', 37, 2020), ('Josh Christopher', 4.4, 'HOU', 24, 2021), ('Cam Thomas', 4.4, 'BRK', 27, 2021), ('Kessler Edwards', 4.4, 'BRK', 44, 2021), ('Aaron Wiggins', 4.4, 'OKC', 55, 2021), ('Quincy Miller', 4.5, 'DEN', 38, 2012), ('Isaiah Canaan', 4.5, 'HOU', 34, 2013), ('Ryan Kelly', 4.5, 'LAL', 48, 2013), ('Lorenzo Brown', 4.5, 'MIN', 52, 2013), ('Thanasis Antetokounmpo', 4.5, 'NYK', 51, 2014), ('Marquese Chriss', 4.5, 'SAC', 8, 2016), ('Wade Baldwin', 4.5, 'MEM', 17, 2016), ('Anzejs Pasecniks', 4.5, 'ORL', 25, 2017), ('Sindarius Thornwell', 4.5, 'MIL', 48, 2017), ('Hamidou Diallo', 4.5, 'BRK', 45, 2018), ('Kevin Porter Jr.', 4.5, 'MIL', 30, 2019), ('Carsen Edwards', 4.5, 'PHI', 33, 2019), ('Kira Lewis Jr.', 4.5, 'NOP', 13, 2020), ('Elijah Hughes', 4.5, 'NOP', 39, 2020), ('Jalen Green', 4.5, 'HOU', 2, 2021), ('Ziaire Williams', 4.5, 'NOP', 10, 2021), ('Greg Brown III', 4.5, 'NOP', 43, 2021), ('Dion Waiters', 4.6, 'CLE', 4, 2012), ('Darius Miller', 4.6, 'NOP', 46, 2012), ('Robbie Hummel', 4.6, 'MIN', 58, 2012), ('Sergey Karasev', 4.6, 'CLE', 19, 2013), ('Ray McCallum', 4.6, 'SAC', 36, 2013), ('Ricky Ledo', 4.6, 'MIL', 43, 2013), ('Josh Huestis', 4.6, 'OKC', 29, 2014), ('K.J. McDaniels', 4.6, 'PHI', 32, 2014), ('Markel Brown', 4.6, 'MIN', 44, 2014), ('Lamar Patterson', 4.6, 'MIL', 48, 2014), ('Devyn Marble', 4.6, 'DEN', 56, 2014), ("DeAndre' Bembry", 4.6, 'ATL', 21, 2016), ('Kay Felder', 4.6, 'ATL', 54, 2016), ('Abdel Nader', 4.6, 'BOS', 58, 2016), ('Tyler Dorsey', 4.6, 'ATL', 41, 2017), ('Edmond Sumner', 4.6, 'NOP', 52, 2017), ('Aaron Holiday', 4.6, 'IND', 23, 2018), ('Dzanan Musa', 4.6, 'BRK', 29, 2018), ('Rodions Kurucs', 4.6, 'BRK', 40, 2018), ('Romeo Langford', 4.6, 'BOS', 14, 2019), ('Nickeil Alexander-Walker', 4.6, 'BRK', 17, 2019), ('Bruno Fernando', 4.6, 'PHI', 34, 2019), ('Deni Avdija', 4.6, 'WAS', 9, 2020), ('Cassius Stanley', 4.6, 'IND', 54, 2020), ('Tornike Shengelia', 4.7, 'PHI', 54, 2012), ('Solomon Hill', 4.7, 'IND', 23, 2013), ('Nemanja Nedovic', 4.7, 'PHO', 30, 2013), ('James Young', 4.7, 'BOS', 17, 2014), ('Nick Johnson', 4.7, 'HOU', 42, 2014), ('Cameron Bairstow', 4.7, 'CHI', 49, 2014), ('Jordan Mickey', 4.7, 'BOS', 33, 2015), ('Henry Ellenson', 4.7, 'DET', 18, 2016), ('D.J. Wilson', 4.7, 'MIL', 17, 2017), ('Davon Reed', 4.7, 'PHO', 32, 2017), ('Frank Mason III', 4.7, 'SAC', 34, 2017), ('RJ Barrett', 4.7, 'NYK', 3, 2019), ('Luka Samanic', 4.7, 'SAS', 19, 2019), ('Didi Louzada', 4.7, 'ATL', 35, 2019), ('Jalen McDaniels', 4.7, 'CHO', 52, 2019), ('Kyle Guy', 4.7, 'NYK', 55, 2019), ('Leandro Bolmaro', 4.7, 'NYK', 23, 2020), ('Jay Scrubb', 4.7, 'BRK', 55, 2020), ('Reggie Perry', 4.7, 'LAC', 57, 2020), ('Brandon Boston Jr.', 4.7, 'MEM', 51, 2021), ('Georgios Kalaitzakis', 4.7, 'IND', 60, 2021), ('Kim English', 4.8, 'DET', 44, 2012), ('Kevin Murphy', 4.8, 'UTA', 47, 2012), ('Kostas Papanikolaou', 4.8, 'NYK', 48, 2012), ('Ognjen Kuzmic', 4.8, 'GSW', 52, 2012), ('Furkan Aldemir', 4.8, 'LAC', 53, 2012), ('Glen Rice Jr.', 4.8, 'PHI', 35, 2013), ('Nate Wolters', 4.8, 'WAS', 38, 2013), ('Jamaal Franklin', 4.8, 'MEM', 41, 2013), ('Erick Green', 4.8, 'UTA', 46, 2013), ('Peyton Siva', 4.8, 'DET', 56, 2013), ('Bruno Caboclo', 4.8, 'TOR', 20, 2014), ('C.J. Wilcox', 4.8, 'LAC', 28, 2014), ('Cory Jefferson', 4.8, 'SAS', 60, 2014), ('Justise Winslow', 4.8, 'MIA', 10, 2015), ('Rakeem Christmas', 4.8, 'MIN', 36, 2015), ('Kris Dunn', 4.8, 'MIN', 5, 2016), ('Georgios Papagiannis', 4.8, 'PHO', 13, 2016), ('Ante Zizic', 4.8, 'BOS', 23, 2016), ('Skal Labissiere', 4.8, 'PHO', 28, 2016), ('Stephen Zimmerman', 4.8, 'ORL', 41, 2016), ('Zhou Qi', 4.8, 'HOU', 43, 2016), ('A.J. Hammons', 4.8, 'DAL', 46, 2016), ('Jake Layman', 4.8, 'ORL', 47, 2016), ('Dennis Smith Jr.', 4.8, 'DAL', 9, 2017), ('Zach Collins', 4.8, 'SAC', 10, 2017), ('Harry Giles', 4.8, 'POR', 20, 2017), ('Jaron Blossomgame', 4.8, 'SAS', 59, 2017), ('Troy Brown Jr.', 4.8, 'WAS', 15, 2018), ('Keita Bates-Diop', 4.8, 'MIN', 48, 2018), ('Ray Spalding', 4.8, 'PHI', 56, 2018), ('Kostas Antetokounmpo', 4.8, 'PHI', 60, 2018), ('Deividas Sirvydis', 4.8, 'DAL', 37, 2019), ('Justin James', 4.8, 'SAC', 40, 2019), ('Talen Horton-Tucker', 4.8, 'ORL', 46, 2019), ('Quinndary Weatherspoon', 4.8, 'SAS', 49, 2019), ('Jordan Bone', 4.8, 'NOP', 57, 2019), ('Vernon Carey Jr.', 4.8, 'CHO', 32, 2020), ('Daniel Oturu', 4.8, 'MIN', 33, 2020), ("Jahmi'us Ramsey", 4.8, 'SAC', 43, 2020), ('Nico Mannion', 4.8, 'GSW', 48, 2020), ('Chris Duarte', 4.8, 'IND', 13, 2021), ('Moses Moody', 4.8, 'GSW', 14, 2021), ('Kai Jones', 4.8, 'NYK', 19, 2021), ('Miles McBride', 4.8, 'OKC', 36, 2021), ('JT Thor', 4.8, 'DET', 37, 2021), ('Fab Melo', 4.9, 'BOS', 22, 2012), ('Arnett Moultrie', 4.9, 'MIA', 27, 2012), ('Orlando Johnson', 4.9, 'SAC', 36, 2012), ('Quincy Acy', 4.9, 'TOR', 37, 2012), ('Kris Joseph', 4.9, 'BOS', 51, 2012), ('Darius Johnson-Odom', 4.9, 'DAL', 55, 2012), ('Tony Snell', 4.9, 'CHI', 20, 2013), ('Grant Jerrett', 4.9, 'POR', 40, 2013), ('Pierre Jackson', 4.9, 'PHI', 42, 2013), ('Erik Murphy', 4.9, 'CHI', 49, 2013), ('Joffrey Lauvergne', 4.9, 'MEM', 55, 2013), ('Mitch McGary', 4.9, 'OKC', 21, 2014), ('Damien Inglis', 4.9, 'MIL', 31, 2014), ('Russ Smith', 4.9, 'PHI', 47, 2014), ('Chris McCullough', 4.9, 'BRK', 29, 2015), ('Thon Maker', 4.9, 'MIL', 10, 2016), ('Chinanu Onuaku', 4.9, 'HOU', 37, 2016), ('Diamond Stone', 4.9, 'NOP', 40, 2016), ('Michael Gbinije', 4.9, 'DET', 49, 2016), ('Ben Bentil', 4.9, 'BOS', 51, 2016), ('Petr Cornelie', 4.9, 'DEN', 53, 2016), ('Daniel Hamilton', 4.9, 'DEN', 56, 2016), ('Justin Patton', 4.9, 'CHI', 16, 2017), ('Tyler Lydon', 4.9, 'UTA', 24, 2017), ('Sterling Brown', 4.9, 'PHI', 46, 2017), ('Zhaire Smith', 4.9, 'PHO', 16, 2018), ('Khyri Thomas', 4.9, 'PHI', 38, 2018), ('Alize Johnson', 4.9, 'IND', 50, 2018), ('Devon Hall', 4.9, 'OKC', 53, 2018), ('George King', 4.9, 'PHO', 59, 2018), ('Nassir Little', 4.9, 'POR', 25, 2019), ('Mfiondu Kabengele', 4.9, 'BRK', 27, 2019), ('Alen Smailagic', 4.9, 'NOP', 39, 2019), ('Eric Paschall', 4.9, 'GSW', 41, 2019), ('Tremont Waters', 4.9, 'BOS', 51, 2019), ('Justin Wright-Foreman', 4.9, 'UTA', 53, 2019), ('Marial Shayok', 4.9, 'PHI', 54, 2019), ('Miye Oni', 4.9, 'GSW', 58, 2019), ('Dewan Hernandez', 4.9, 'TOR', 59, 2019), ('Patrick Williams', 4.9, 'CHI', 4, 2020), ('Zeke Nnaji', 4.9, 'DEN', 22, 2020), ('Tyler Bey', 4.9, 'PHI', 36, 2020), ('Robert Woodard II', 4.9, 'MEM', 40, 2020), ('Nick Richards', 4.9, 'NOP', 42, 2020), ('Marko Simonovic', 4.9, 'CHI', 44, 2020), ('Isaiah Joe', 4.9, 'PHI', 49, 2020), ('Cassius Winston', 4.9, 'OKC', 53, 2020), ('Jonathan Kuminga', 4.9, 'GSW', 7, 2021), ('Corey Kispert', 4.9, 'WAS', 15, 2021), ('Jalen Johnson', 4.9, 'ATL', 20, 2021), ("Day'Ron Sharpe", 4.9, 'PHO', 29, 2021), ('Isaiah Todd', 4.9, 'MIL', 31, 2021), ('Neemias Queta', 4.9, 'SAC', 39, 2021), ('Joe Wieskamp', 4.9, 'SAS', 41, 2021), ('Sharife Cooper', 4.9, 'ATL', 48, 2021), ('Luka Garza', 4.9, 'DET', 52, 2021), ('Royce White', 5.0, 'HOU', 16, 2012), ('Tyler Zeller', 5.0, 'DAL', 17, 2012), ('Festus Ezeli', 5.0, 'GSW', 30, 2012), ('Bernard James', 5.0, 'CLE', 33, 2012), ('Shabazz Muhammad', 5.0, 'UTA', 14, 2013), ('Carrick Felix', 5.0, 'CLE', 33, 2013), ('Tony Mitchell', 5.0, 'DET', 37, 2013), ('Edy Tavares', 5.0, 'ATL', 43, 2014), ('Jordan McRae', 5.0, 'SAS', 58, 2014), ('Jahlil Okafor', 5.0, 'PHI', 3, 2015), ('R.J. Hunter', 5.0, 'BOS', 28, 2015), ('Branden Dawson', 5.0, 'NOP', 56, 2015), ('Guerschon Yabusele', 5.0, 'BOS', 16, 2016), ('Brice Johnson', 5.0, 'LAC', 25, 2016), ('Deyonta Davis', 5.0, 'BOS', 31, 2016), ('Joel Bolomboy', 5.0, 'UTA', 52, 2016), ('Marcus Paige', 5.0, 'BRK', 55, 2016), ('Markelle Fultz', 5.0, 'PHI', 1, 2017), ('Ike Anigbogu', 5.0, 'IND', 47, 2017), ('Vlatko Cancar', 5.0, 'DEN', 49, 2017), ('Alec Peters', 5.0, 'PHO', 54, 2017), ('Nigel Williams-Goss', 5.0, 'UTA', 55, 2017), ('Jabari Bird', 5.0, 'BOS', 56, 2017), ('Marvin Bagley III', 5.0, 'SAC', 2, 2018), ('Chimezie Metu', 5.0, 'SAS', 49, 2018), ('Vince Edwards', 5.0, 'UTA', 52, 2018), ('Arnoldas Kulboka', 5.0, 'CHO', 55, 2018), ('Kevin Hervey', 5.0, 'OKC', 57, 2018), ('Thomas Welsh', 5.0, 'DEN', 58, 2018), ('Ty Jerome', 5.0, 'PHI', 24, 2019), ('Isaiah Stewart', 5.0, 'POR', 16, 2020), ('Malachi Flynn', 5.0, 'TOR', 29, 2020), ('Tyrell Terry', 5.0, 'DAL', 31, 2020), ('Grant Riller', 5.0, 'CHO', 56, 2020), ('Sam Merrill', 5.0, 'NOP', 60, 2020), ('Jaden Springer', 5.0, 'PHI', 28, 2021), ('Jason Preston', 5.0, 'ORL', 33, 2021), ('Ayo Dosunmu', 5.0, 'CHI', 38, 2021), ('Jared Butler', 5.0, 'NOP', 40, 2021), ('Isaiah Livers', 5.0, 'DET', 42, 2021), ('Dalano Banton', 5.0, 'TOR', 46, 2021), ('David Johnson', 5.0, 'TOR', 47, 2021), ('Scottie Lewis', 5.0, 'CHO', 56, 2021), ('John Jenkins', 5.1, 'ATL', 23, 2012), ('Alex Abrines', 5.1, 'OKC', 32, 2013), ('Jarnell Stokes', 5.1, 'UTA', 35, 2014), ('Dakari Johnson', 5.1, 'OKC', 48, 2015), ('Demetrius Jackson', 5.1, 'BOS', 45, 2016), ('T.J. Leaf', 5.1, 'IND', 18, 2017), ('Ivan Rabb', 5.1, 'ORL', 35, 2017), ('Jonah Bolden', 5.1, 'PHI', 36, 2017), ('Kadeem Allen', 5.1, 'BOS', 53, 2017), ('Dylan Windler', 5.1, 'CLE', 26, 2019), ('Isaiah Roby', 5.1, 'DET', 45, 2019), ('Jarrell Brantley', 5.1, 'IND', 50, 2019), ('Jalen Smith', 5.1, 'PHO', 10, 2020), ('Udoka Azubuike', 5.1, 'UTA', 27, 2020), ('Jalen Harris', 5.1, 'TOR', 59, 2020), ('Isaiah Jackson', 5.1, 'LAL', 22, 2021), ('Sandro Mamukelashvili', 5.1, 'IND', 54, 2021), ('Miles Plumlee', 5.2, 'IND', 26, 2012), ('Alex Len', 5.2, 'PHO', 5, 2013), ('Jordan Adams', 5.2, 'MEM', 22, 2014), ('Denzel Valentine', 5.2, 'CHI', 14, 2016), ('Furkan Korkmaz', 5.2, 'PHI', 26, 2016), ('Omari Spellman', 5.2, 'ATL', 30, 2018), ('Cole Anthony', 5.2, 'ORL', 15, 2020), ('Saben Lee', 5.2, 'UTA', 38, 2020), ('Jeremiah Robinson-Earl', 5.2, 'NYK', 32, 2021), ('Jericho Sims', 5.2, 'NYK', 58, 2021), ('Doug McDermott', 5.3, 'DEN', 11, 2014), ('Juancho Hernangomez', 5.3, 'DEN', 15, 2016), ('Cheick Diallo', 5.3, 'LAC', 33, 2016), ('Landry Shamet', 5.3, 'PHI', 26, 2018), ('Shake Milton', 5.3, 'DAL', 54, 2018), ('Josh Green', 5.3, 'DAL', 18, 2020), ('Skylar Mays', 5.3, 'ATL', 50, 2020), ('Cade Cunningham', 5.3, 'DET', 1, 2021), ('Santi Aldama', 5.3, 'UTA', 30, 2021), ('Glenn Robinson III', 5.4, 'MIN', 40, 2014), ('Justin Anderson', 5.4, 'DAL', 21, 2015), ('Taurean Prince', 5.4, 'UTA', 12, 2016), ('Moritz Wagner', 5.4, 'LAL', 25, 2018), ('Goga Bitadze', 5.4, 'IND', 18, 2019), ('Tre Jones', 5.4, 'SAS', 41, 2020), ('Paul Reed', 5.4, 'PHI', 58, 2020), ('Usman Garuba', 5.4, 'HOU', 23, 2021), ('Charles Bassey', 5.4, 'PHI', 53, 2021), ('Justin Hamilton', 5.5, 'PHI', 45, 2012), ('Sam Dekker', 5.5, 'HOU', 18, 2015), ('Jerian Grant', 5.5, 'WAS', 19, 2015), ('Anfernee Simons', 5.5, 'POR', 24, 2018), ('Jordan Poole', 5.5, 'GSW', 28, 2019), ('Jaylen Nowell', 5.5, 'MIN', 43, 2019), ('Josh Giddey', 5.5, 'OKC', 6, 2021), ('Quentin Grimes', 5.5, 'LAC', 25, 2021), ('Michael Kidd-Gilchrist', 5.6, 'CHO', 2, 2012), ('Mike Scott', 5.6, 'ATL', 43, 2012), ('Malik Monk', 5.6, 'CHO', 11, 2017), ('Bol Bol', 5.6, 'MIA', 44, 2019), ('Raul Neto', 5.7, 'ATL', 47, 2013), ('Grant Williams', 5.7, 'BOS', 22, 2019), ('Cody Martin', 5.7, 'CHO', 36, 2019), ('Kenyon Martin Jr.', 5.7, 'SAC', 52, 2020), ('Alperen Sengun', 5.7, 'OKC', 16, 2021), ('Damian Jones', 5.8, 'GSW', 30, 2016), ('Allen Crabbe', 5.9, 'CLE', 31, 2013), ('James Ennis III', 5.9, 'ATL', 50, 2013), ('Kelly Oubre Jr.', 5.9, 'ATL', 15, 2015), ('Trey Murphy III', 5.9, 'MEM', 17, 2021), ('Bones Hyland', 5.9, 'DEN', 26, 2021), ('Onyeka Okongwu', 6.0, 'ATL', 6, 2020), ('Xavier Tillman Sr.', 6.0, 'SAC', 35, 2020), ('Herbert Jones', 6.0, 'NOP', 35, 2021), ('Meyers Leonard', 6.1, 'POR', 11, 2012), ('Tony Bradley', 6.1, 'LAL', 28, 2017), ('Jordan Bell', 6.1, 'CHI', 38, 2017), ('Chuma Okeke', 6.1, 'ORL', 16, 2019), ('Keldon Johnson', 6.1, 'SAS', 29, 2019), ('Jevon Carter', 6.2, 'MEM', 32, 2018), ('Franz Wagner', 6.2, 'ORL', 8, 2021), ('Jeff Withey', 6.3, 'POR', 39, 2013), ('Georges Niang', 6.3, 'IND', 50, 2016), ('Payton Pritchard', 6.3, 'BOS', 26, 2020), ('P.J. Washington', 6.5, 'CHO', 12, 2019), ('Devin Vassell', 6.5, 'SAS', 11, 2020), ('Obi Toppin', 6.6, 'NYK', 8, 2020), ('Trey Burke', 6.7, 'MIN', 9, 2013), ('Jaxson Hayes', 6.7, 'ATL', 8, 2019), ('Nic Claxton', 6.7, 'BRK', 31, 2019), ('Terance Mann', 6.7, 'LAC', 48, 2019), ('Gary Trent Jr.', 6.8, 'SAC', 37, 2018), ('Michael Carter-Williams', 6.9, 'PHI', 11, 2013), ('Lucas Nogueira', 6.9, 'BOS', 16, 2013), ('Trey Lyles', 6.9, 'UTA', 12, 2015), ('Kevin Huerter', 6.9, 'ATL', 19, 2018), ('Darius Garland', 6.9, 'CLE', 5, 2019), ('Shabazz Napier', 7.0, 'CHO', 24, 2014), ('Jonathan Isaac', 7.0, 'ORL', 6, 2017), ('Grayson Allen', 7.0, 'UTA', 21, 2018), ('Bruce Brown', 7.0, 'DET', 42, 2018), ('Saddiq Bey', 7.0, 'BRK', 19, 2020), ('Gary Harris', 7.1, 'CHI', 19, 2014), ('Rodney Hood', 7.2, 'UTA', 23, 2014), ('Wendell Carter Jr.', 7.2, 'CHI', 7, 2018), ('Anthony Edwards', 7.2, 'MIN', 1, 2020), ('Tyrese Maxey', 7.2, 'PHI', 21, 2020), ('Immanuel Quickley', 7.2, 'OKC', 25, 2020), ('Andre Roberson', 7.3, 'MIN', 26, 2013), ('Cameron Payne', 7.3, 'OKC', 14, 2015), ('Rondae Hollis-Jefferson', 7.3, 'POR', 23, 2015), ('Donte DiVincenzo', 7.3, 'MIL', 17, 2018), ('Jarred Vanderbilt', 7.3, 'ORL', 41, 2018), ('Scottie Barnes', 7.3, 'TOR', 4, 2021), ('Tomas Satoransky', 7.4, 'WAS', 32, 2012), ('Jabari Parker', 7.5, 'MIL', 2, 2014), ('Dario Saric', 7.5, 'ORL', 12, 2014), ('Willy Hernangomez', 7.5, 'PHI', 35, 2015), ('Malik Beasley', 7.5, 'DEN', 19, 2016), ('Isaiah Hartenstein', 7.5, 'HOU', 43, 2017), ('Daniel Gafford', 7.5, 'CHI', 38, 2019), ('Evan Mobley', 7.5, 'CLE', 3, 2021), ('Reggie Bullock', 7.6, 'LAC', 25, 2013), ('Mo Bamba', 7.6, 'ORL', 6, 2018), ('Jared Sullinger', 7.7, 'BOS', 21, 2012), ('Tyler Herro', 7.7, 'MIA', 13, 2019), ('Kyle Kuzma', 7.8, 'BRK', 27, 2017), ("Devonte' Graham", 7.9, 'ATL', 34, 2018), ('Dennis Schroder', 8.1, 'ATL', 17, 2013), ('Luke Kennard', 8.2, 'DET', 12, 2017), ('Andrew Wiggins', 8.3, 'CLE', 1, 2014), ('Caris LeVert', 8.3, 'IND', 20, 2016), ('Thomas Bryant', 8.3, 'UTA', 42, 2017), ('Jaren Jackson Jr.', 8.3, 'MEM', 4, 2018), ('Michael Porter Jr.', 8.3, 'DEN', 14, 2018), ('John Henson', 8.4, 'MIL', 14, 2012), ('Frank Kaminsky', 8.4, 'CHO', 9, 2015), ('Kevon Looney', 8.4, 'GSW', 30, 2015), ('Matisse Thybulle', 8.4, 'BOS', 20, 2019), ('Terrence Jones', 8.6, 'HOU', 18, 2012), ('Elfrid Payton', 8.7, 'PHI', 10, 2014), ('Joe Harris', 8.8, 'CLE', 33, 2014), ('Pat Connaughton', 8.8, 'BRK', 41, 2015), ('Miles Bridges', 8.8, 'LAC', 12, 2018), ("De'Anthony Melton", 8.8, 'HOU', 46, 2018), ('Cameron Johnson', 8.8, 'MIN', 11, 2019), ('Mike Muscala', 8.9, 'DAL', 44, 2013), ('Josh Hart', 8.9, 'UTA', 30, 2017), ('Desmond Bane', 8.9, 'BOS', 30, 2020), ('Cody Zeller', 9.0, 'CHO', 4, 2013), ('Maurice Harkless', 9.1, 'PHI', 15, 2012), ('Bobby Portis', 9.2, 'CHI', 22, 2015), ('Terrence Ross', 9.3, 'TOR', 8, 2012), ('T.J. Warren', 9.3, 'PHO', 14, 2014), ('Willie Cauley-Stein', 9.4, 'SAC', 6, 2015), ('Monte Morris', 9.4, 'DEN', 51, 2017), ('Norman Powell', 9.6, 'MIL', 46, 2015), ('Ivica Zubac', 9.7, 'LAL', 32, 2016), ('Jalen Brunson', 9.7, 'DAL', 33, 2018), ('Evan Fournier', 9.8, 'DEN', 20, 2012), ('Richaun Holmes', 9.8, 'PHI', 37, 2015), ('LaMelo Ball', 9.8, 'CHO', 3, 2020), ('Tim Hardaway Jr.', 9.9, 'NYK', 24, 2013), ('Josh Richardson', 9.9, 'MIA', 40, 2015), ("Kyle O'Quinn", 10.0, 'ORL', 49, 2012), ('OG Anunoby', 10.0, 'TOR', 23, 2017), ('Lauri Markkanen', 10.2, 'MIN', 7, 2017), ('Brandon Clarke', 10.3, 'OKC', 21, 2019), ('Bogdan Bogdanovic', 10.6, 'PHO', 27, 2014), ('Tyus Jones', 10.6, 'CLE', 24, 2015), ('Brandon Ingram', 10.7, 'LAL', 2, 2016), ('Derrick White', 11.0, 'SAS', 29, 2017), ('Kentavious Caldwell-Pope', 11.1, 'DET', 8, 2013), ('Jordan Clarkson', 11.2, 'WAS', 46, 2014), ('Jamal Murray', 11.2, 'DEN', 7, 2016), ('Zion Williamson', 11.2, 'NOP', 1, 2019), ('Lonzo Ball', 11.3, 'LAL', 2, 2017), ('Robert Williams', 11.3, 'BOS', 27, 2018), ("De'Aaron Fox", 11.4, 'SAC', 5, 2017), ('Deandre Ayton', 11.5, 'PHO', 1, 2018), ('Mitchell Robinson', 11.5, 'NYK', 36, 2018), ('Jusuf Nurkic', 11.6, 'CHI', 16, 2014), ('Tyrese Haliburton', 11.6, 'SAC', 12, 2020), ('Jerami Grant', 11.7, 'PHI', 39, 2014), ('Jakob Poeltl', 11.8, 'TOR', 9, 2016), ('Will Barton', 11.9, 'POR', 40, 2012), ('Spencer Dinwiddie', 12.0, 'DET', 38, 2014), ('Jaylen Brown', 12.1, 'BOS', 3, 2016), ('Gorgui Dieng', 12.3, 'UTA', 21, 2013), ('Harrison Barnes', 12.4, 'GSW', 7, 2012), ('Marcus Smart', 12.4, 'BOS', 6, 2014), ('Ja Morant', 12.4, 'MEM', 2, 2019), ('Nerlens Noel', 12.5, 'NOP', 6, 2013), ('John Collins', 12.6, 'ATL', 19, 2017), ('Buddy Hield', 12.8, 'NOP', 6, 2016), ('Jeremy Lamb', 12.9, 'HOU', 12, 2012), ('Dwight Powell', 13.0, 'CHO', 45, 2014), ('Aaron Gordon', 13.1, 'ORL', 4, 2014), ('Larry Nance Jr.', 13.1, 'LAL', 27, 2015), ('Terry Rozier', 13.2, 'BOS', 16, 2015), ('Mikal Bridges', 13.4, 'PHI', 10, 2018), ("D'Angelo Russell", 13.5, 'LAL', 2, 2015), ('Malcolm Brogdon', 13.6, 'MIL', 36, 2016), ('Dejounte Murray', 13.9, 'SAS', 29, 2016), ('Myles Turner', 14.1, 'IND', 11, 2015), ('Delon Wright', 14.1, 'TOR', 20, 2015), ('Jarrett Allen', 14.3, 'BRK', 22, 2017), ('Shai Gilgeous-Alexander', 14.5, 'CHO', 11, 2018), ('Zach LaVine', 14.8, 'MIN', 13, 2014), ('Kyle Anderson', 15.4, 'SAS', 30, 2014), ('Kelly Olynyk', 15.6, 'DAL', 13, 2013), ('Kristaps Porzingis', 15.8, 'NYK', 4, 2015), ('Jae Crowder', 15.9, 'CLE', 34, 2012), ('Julius Randle', 15.9, 'LAL', 7, 2014), ('Victor Oladipo', 16.0, 'ORL', 2, 2013), ('Steven Adams', 16.6, 'OKC', 12, 2013), ('Devin Booker', 16.7, 'PHO', 13, 2015), ('Montrezl Harrell', 17.1, 'HOU', 32, 2015), ('Pascal Siakam', 17.4, 'TOR', 27, 2016), ('Otto Porter Jr.', 17.6, 'WAS', 3, 2013), ('Bam Adebayo', 17.6, 'MIA', 14, 2017), ('Mason Plumlee', 17.7, 'BRK', 22, 2013), ('Trae Young', 17.9, 'DAL', 5, 2018), ('Domantas Sabonis', 18.0, 'ORL', 11, 2016), ('Clint Capela', 18.5, 'HOU', 25, 2014), ('Ben Simmons', 18.9, 'PHI', 1, 2016), ('Khris Middleton', 19.3, 'DET', 39, 2012), ('Donovan Mitchell', 20.4, 'DEN', 13, 2017), ('CJ McCollum', 20.9, 'POR', 10, 2013), ('Jayson Tatum', 21.6, 'BOS', 3, 2017), ('Andre Drummond', 22.8, 'DET', 9, 2012), ('Bradley Beal', 26.7, 'WAS', 3, 2012), ('Joel Embiid', 27.2, 'PHI', 3, 2014), ('Luka Doncic', 27.8, 'ATL', 3, 2018), ('Draymond Green', 28.6, 'GSW', 35, 2012), ('Rudy Gobert', 33.2, 'DEN', 27, 2013), ('Karl-Anthony Towns', 34.2, 'MIN', 1, 2015), ('Anthony Davis', 49.3, 'NOP', 1, 2012), ('Damian Lillard', 49.9, 'POR', 6, 2012), ('Giannis Antetokounmpo', 50.1, 'MIL', 15, 2013), ('Nikola Jokic', 51.8, 'DEN', 41, 2014)]
    


```python
num = 0
worst_teams = []
worst_ratings = []
for value in sorted_by_average:
    if num <=9:
        worst_teams.append(value[0])
        worst_ratings.append(value[1])
    num += 1

plt.bar(worst_teams, worst_ratings, color = ['orange', 'purple', 'firebrick', 'blue', 'darkblue', 'darkblue', 'red', 'yellow', 'red', 'blue'])
plt.xlabel('Team')
plt.ylabel('Rating')
plt.title('NBA Teams Which Have Drafted Worst Since 2012')
```




    Text(0.5, 1.0, 'NBA Teams Which Have Drafted Worst Since 2012')




    
![png](output_15_1.png)
    



```python
num = 0
best_teams = []
best_ratings = []
for value in reversed(sorted_by_average):
    if num <=9:
        best_teams.append(value[0])
        best_ratings.append(value[1])
    num += 1

plt.bar(best_teams, best_ratings, color = ['deepskyblue', 'gray', 'yellow', 'black', 'red', 'red', 'blue', 'darkgreen', 'royalblue', 'yellow'])
plt.xlabel('Team')
plt.ylabel('Rating')
plt.title('NBA Teams Which Have Drafted Best Since 2012')
```




    Text(0.5, 1.0, 'NBA Teams Which Have Drafted Best Since 2012')




    
![png](output_16_1.png)
    



```python
num = 0
best_picks = []
best_pickratings = []
for value in reversed(sorted_by_rating):
    if num <=9:
        best_picks.append(value[0])
        best_pickratings.append(value[1])
    num += 1

plt.bar(best_picks, best_pickratings, color = ['deepskyblue', 'royalblue', 'deepskyblue', 'blue', 'darkgreen', 'royalblue', 'red', 'firebrick', 'red', 'blue'])
plt.xlabel('Player')
plt.ylabel('Rating')
plt.title('Best Draft Picks Since 2012')
plt.xticks(rotation=90) 
```




    ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
     [Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, '')])




    
![png](output_17_1.png)
    



```python
num = 0
worst_picks = []
worst_pickratings = []
for value in sorted_by_rating:
    if num <=9:
        worst_picks.append(value[0])
        worst_pickratings.append(value[1])
    num += 1

plt.bar(worst_picks, worst_pickratings, color = ['firebrick', 'darkblue', 'blue', 'blue', 'darkblue', 'orange', 'firebrick', 'royalblue', 'red', 'purple'])
plt.xlabel('Player')
plt.ylabel('Rating')
plt.title('Worst Draft Picks Since 2012')
plt.xticks(rotation=90) 
```




    ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
     [Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, ''),
      Text(0, 0, '')])




    
![png](output_18_1.png)
    



```python

```
